﻿[CmdletBinding()]
param(
    [ValidateSet('GA', 'Preview')]
    [string]$Environment = 'GA',

    [ValidateSet('All', 'Word', 'Excel', 'Outlook')]
    [string[]]$AddIns = @('All'),

    [ValidateRange(1, 3600)]
    [int]$TimeoutSeconds = 300,

    [switch]$SkipClickOnceCacheCleanup,

    [switch]$KeepOfficeAppsOpen,

    [switch]$ClearAllOfficeResiliencyData
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:LogPath = Join-Path $env:TEMP 'RedInkAddins-Reset-Reinstall.log'

function Write-Log {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$timestamp] $Message"
    Write-Host $line
    Add-Content -Path $script:LogPath -Value $line
}

function Write-Section {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Text
    )

    Write-Host ''
    Write-Log "===== $Text ====="
}

function Get-PropertyValue {
    param(
        [Parameter(Mandatory = $false)]
        [AllowNull()]
        [psobject]$Properties,

        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    if ($null -eq $Properties) {
        return $null
    }

    $property = $Properties.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $null
    }

    return $property.Value
}

function Get-VstoInstallerPath {
    $runtimeRegistryPaths = @(
        'HKLM:\SOFTWARE\Microsoft\VSTO Runtime Setup\v4',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VSTO Runtime Setup\v4'
    )

    foreach ($registryPath in $runtimeRegistryPaths) {
        if (-not (Test-Path $registryPath)) {
            continue
        }

        $properties = Get-ItemProperty -Path $registryPath -ErrorAction SilentlyContinue
        $installerPath = Get-PropertyValue -Properties $properties -Name 'InstallerPath'

        if ([string]::IsNullOrWhiteSpace([string]$installerPath)) {
            continue
        }

        $installerPathString = [string]$installerPath

        if (Test-Path $installerPathString -PathType Leaf) {
            return $installerPathString
        }

        if (Test-Path $installerPathString -PathType Container) {
            $installerExecutable = Join-Path $installerPathString 'VSTOInstaller.exe'
            if (Test-Path $installerExecutable -PathType Leaf) {
                return $installerExecutable
            }
        }
    }

    $candidatePaths = New-Object System.Collections.Generic.List[string]

    $commonProgramFiles = [System.Environment]::GetEnvironmentVariable('CommonProgramFiles')
    if (-not [string]::IsNullOrWhiteSpace($commonProgramFiles)) {
        $candidatePaths.Add((Join-Path $commonProgramFiles 'Microsoft Shared\VSTO\10.0\VSTOInstaller.exe'))
    }

    $commonProgramFilesX86 = [System.Environment]::GetEnvironmentVariable('CommonProgramFiles(x86)')
    if (-not [string]::IsNullOrWhiteSpace($commonProgramFilesX86)) {
        $candidatePaths.Add((Join-Path $commonProgramFilesX86 'Microsoft Shared\VSTO\10.0\VSTOInstaller.exe'))
    }

    foreach ($path in $candidatePaths) {
        if (Test-Path $path) {
            return $path
        }
    }

    throw 'VSTOInstaller.exe was not found. Install Microsoft Visual Studio Tools for Office Runtime first.'
}

function Get-OfficeVersion {
    foreach ($version in @('17.0', '16.0', '15.0', '14.0')) {
        if (Test-Path "HKCU:\Software\Microsoft\Office\$version\Common") {
            return $version
        }
    }

    return '16.0'
}

function Get-AddInCatalog {
    return @{
        Word = @{
            OfficeHost = 'Word'
            ProcessName = 'winword'
            ProgId = 'Red Ink for Word'
            FriendlyName = 'Red Ink for Word'
            Urls = @{
                GA = 'https://redink.ai/apps/ga/word/Red%20Ink%20for%20Word.vsto'
                Preview = 'https://redink.ai/apps/preview/word/Red%20Ink%20for%20Word.vsto'
            }
        }
        Excel = @{
            OfficeHost = 'Excel'
            ProcessName = 'excel'
            ProgId = 'Red Ink for Excel'
            FriendlyName = 'Red Ink for Excel'
            Urls = @{
                GA = 'https://redink.ai/apps/ga/excel/Red%20Ink%20for%20Excel.vsto'
                Preview = 'https://redink.ai/apps/preview/excel/Red%20Ink%20for%20Excel.vsto'
            }
        }
        Outlook = @{
            OfficeHost = 'Outlook'
            ProcessName = 'outlook'
            ProgId = 'Red Ink for Outlook'
            FriendlyName = 'Red Ink for Outlook'
            Urls = @{
                GA = 'https://redink.ai/apps/ga/outlook/Red%20Ink%20for%20Outlook.vsto'
                Preview = 'https://redink.ai/apps/preview/outlook/Red%20Ink%20for%20Outlook.vsto'
            }
        }
    }
}

function Get-SelectedAddIns {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Catalog,

        [Parameter(Mandatory = $true)]
        [string[]]$RequestedAddIns
    )

    if ($RequestedAddIns -contains 'All') {
        return @($Catalog.Word, $Catalog.Excel, $Catalog.Outlook)
    }

    $selected = New-Object System.Collections.Generic.List[object]

    foreach ($name in $RequestedAddIns) {
        $selected.Add($Catalog[$name])
    }

    return $selected.ToArray()
}

function Get-AddInRegistryPath {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    return "HKCU:\Software\Microsoft\Office\$($AddIn.OfficeHost)\Addins\$($AddIn.ProgId)"
}

function Get-AddInProperties {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    $path = Get-AddInRegistryPath -AddIn $AddIn
    if (-not (Test-Path $path)) {
        return $null
    }

    return Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
}

function Test-AddInInstalled {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    $properties = Get-AddInProperties -AddIn $AddIn
    $manifest = Get-PropertyValue -Properties $properties -Name 'Manifest'

    return (-not [string]::IsNullOrWhiteSpace([string]$manifest))
}

function Stop-OfficeApps {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$SelectedAddIns
    )

    if ($KeepOfficeAppsOpen) {
        Write-Log 'Skipping Office process shutdown because -KeepOfficeAppsOpen was specified.'
        return
    }

    Write-Section 'Stopping selected Office applications'

    foreach ($addIn in $SelectedAddIns) {
        $processName = [string]$addIn.ProcessName

        Get-Process -Name $processName -ErrorAction SilentlyContinue |
            Stop-Process -Force -ErrorAction SilentlyContinue

        Write-Log "Stopped process if running: $processName"
    }
}

function Remove-RegistryTreeIfExists {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (Test-Path $Path) {
        Remove-Item -Path $Path -Recurse -Force -ErrorAction SilentlyContinue
        Write-Log "Removed registry path: $Path"
    }
}

function Clear-OfficeResiliency {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$SelectedAddIns
    )

    Write-Section 'Cleaning Office resiliency entries'

    foreach ($version in @('17.0', '16.0', '15.0', '14.0')) {
        foreach ($addIn in $SelectedAddIns) {
            $officeHost = [string]$addIn.OfficeHost
            $base = "HKCU:\Software\Microsoft\Office\$version\$officeHost\Resiliency"
            $doNotDisablePath = "$base\DoNotDisableAddinList"

            if (Test-Path $doNotDisablePath) {
                Remove-ItemProperty `
                    -Path $doNotDisablePath `
                    -Name ([string]$addIn.ProgId) `
                    -Force `
                    -ErrorAction SilentlyContinue
            }

            if ($ClearAllOfficeResiliencyData) {
                Remove-RegistryTreeIfExists -Path "$base\DisabledItems"
                Remove-RegistryTreeIfExists -Path "$base\CrashingAddinList"
                Remove-RegistryTreeIfExists -Path "$base\StartupItems"
            }
        }
    }

    if ($ClearAllOfficeResiliencyData) {
        Write-Log 'All selected Office hosts had their shared resiliency data cleared. This can affect other add-ins in those hosts.'
    }
    else {
        Write-Log 'Shared Office resiliency data was preserved. Use -ClearAllOfficeResiliencyData only when a disabled-item block must also be cleared.'
    }
}

function Invoke-VstoUninstallIfPossible {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    $properties = Get-AddInProperties -AddIn $AddIn
    if ($null -eq $properties) {
        Write-Log "No add-in registry key found for $($AddIn.ProgId). Skipping VSTO uninstall."
        return
    }

    $manifest = Get-PropertyValue -Properties $properties -Name 'Manifest'
    if ([string]::IsNullOrWhiteSpace([string]$manifest)) {
        Write-Log "No manifest is available for $($AddIn.ProgId). Skipping VSTO uninstall and removing the incomplete registration."
        return
    }

    $manifestForUninstall = ([string]$manifest).Replace('|vstolocal', '')
    $installer = Get-VstoInstallerPath

    Write-Log "Running VSTO silent uninstall for $($AddIn.ProgId): $manifestForUninstall"

    $process = Start-Process `
        -FilePath $installer `
        -ArgumentList @('/uninstall', $manifestForUninstall, '/silent') `
        -Wait `
        -PassThru `
        -WindowStyle Hidden

    Write-Log "VSTO uninstall exit code for $($AddIn.ProgId): $($process.ExitCode)"
}

function Remove-RedInkAddInKeys {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$SelectedAddIns
    )

    Write-Section 'Removing Red Ink add-in registry keys'

    foreach ($addIn in $SelectedAddIns) {
        $path = Get-AddInRegistryPath -AddIn $addIn
        Remove-RegistryTreeIfExists -Path $path
    }
}

function Clear-ClickOnceCache {
    if ($SkipClickOnceCacheCleanup) {
        Write-Log 'Skipping ClickOnce cache cleanup because -SkipClickOnceCacheCleanup was specified.'
        return
    }

    Write-Section 'Clearing ClickOnce cache'
    Write-Log 'The ClickOnce online application cache is user-wide and can contain applications other than Red Ink.'

    try {
        Start-Process `
            -FilePath 'rundll32.exe' `
            -ArgumentList @('dfshim', 'CleanOnlineAppCache') `
            -Wait `
            -WindowStyle Hidden

        Write-Log 'ClickOnce online application cache cleanup completed.'
    }
    catch {
        Write-Log "ClickOnce cache cleanup warning: $($_.Exception.Message)"
    }
}

function Wait-ForAddInRegistration {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn,

        [Parameter(Mandatory = $true)]
        [int]$SecondsToWait
    )

    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    do {
        if (Test-AddInInstalled -AddIn $AddIn) {
            Write-Log "Complete registration detected for $($AddIn.ProgId)."
            return $true
        }

        Start-Sleep -Seconds 3
    }
    while ($stopwatch.Elapsed.TotalSeconds -lt $SecondsToWait)

    return $false
}

function Install-AddInSilent {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    Write-Section "Installing $($AddIn.FriendlyName)"

    $installer = Get-VstoInstallerPath
    $url = [string]$AddIn.Urls[$Environment]

    Write-Log "VSTOInstaller: $installer"
    Write-Log "Manifest URL: $url"

    $process = Start-Process `
        -FilePath $installer `
        -ArgumentList @('/install', $url, '/silent') `
        -Wait `
        -PassThru `
        -WindowStyle Hidden

    Write-Log "VSTO install exit code for $($AddIn.ProgId): $($process.ExitCode)"

    if ($process.ExitCode -ne 0) {
        throw "Silent VSTO install failed for $($AddIn.ProgId) with exit code $($process.ExitCode)."
    }

    if (-not (Wait-ForAddInRegistration -AddIn $AddIn -SecondsToWait $TimeoutSeconds)) {
        throw "The VSTO installer completed, but a complete registry registration was not detected for $($AddIn.ProgId) within $TimeoutSeconds seconds."
    }
}

function Configure-AddInRegistry {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    Write-Section "Configuring $($AddIn.FriendlyName)"

    $path = Get-AddInRegistryPath -AddIn $AddIn
    $properties = Get-AddInProperties -AddIn $AddIn
    $manifest = Get-PropertyValue -Properties $properties -Name 'Manifest'

    if ([string]::IsNullOrWhiteSpace([string]$manifest)) {
        throw "Manifest is missing for $($AddIn.ProgId). The VSTO installer-generated registration will not be replaced manually."
    }

    New-ItemProperty -Path $path -Name 'LoadBehavior' -Value 3 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $path -Name 'RedInkEnvironment' -Value $Environment -PropertyType String -Force | Out-Null

    $officeVersion = Get-OfficeVersion
    $doNotDisablePath = "HKCU:\Software\Microsoft\Office\$officeVersion\$($AddIn.OfficeHost)\Resiliency\DoNotDisableAddinList"
    New-Item -Path $doNotDisablePath -Force | Out-Null
    New-ItemProperty -Path $doNotDisablePath -Name ([string]$AddIn.ProgId) -Value 1 -PropertyType DWord -Force | Out-Null

    Write-Log "Preserved the VSTO installer-generated manifest and applied the deployment marker and load settings."
}

function Validate-AddIn {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$AddIn
    )

    Write-Section "Validating $($AddIn.ProgId)"

    $path = Get-AddInRegistryPath -AddIn $AddIn

    if (-not (Test-Path $path)) {
        throw "Registry key missing after install: $path"
    }

    $properties = Get-ItemProperty -Path $path -ErrorAction Stop
    $friendlyName = Get-PropertyValue -Properties $properties -Name 'FriendlyName'
    $description = Get-PropertyValue -Properties $properties -Name 'Description'
    $manifest = Get-PropertyValue -Properties $properties -Name 'Manifest'
    $loadBehavior = Get-PropertyValue -Properties $properties -Name 'LoadBehavior'
    $marker = Get-PropertyValue -Properties $properties -Name 'RedInkEnvironment'

    Write-Host "FriendlyName      : $friendlyName"
    Write-Host "Description       : $description"
    Write-Host "Manifest          : $manifest"
    Write-Host "LoadBehavior      : $loadBehavior"
    Write-Host "RedInkEnvironment : $marker"

    if ([string]::IsNullOrWhiteSpace([string]$manifest)) {
        throw "Manifest is missing for $($AddIn.ProgId)."
    }

    if ($null -eq $loadBehavior -or [int]$loadBehavior -ne 3) {
        throw "LoadBehavior is not 3 for $($AddIn.ProgId). Current value: $loadBehavior"
    }

    if ([string]$marker -ne $Environment) {
        throw "The deployment channel marker is not $Environment for $($AddIn.ProgId). Current value: $marker"
    }
}

Write-Log "Reset and reinstall started. Environment=$Environment AddIns=$($AddIns -join ',')"
Write-Log "Log file: $script:LogPath"

$catalog = Get-AddInCatalog
$selectedAddIns = Get-SelectedAddIns -Catalog $catalog -RequestedAddIns $AddIns

Stop-OfficeApps -SelectedAddIns $selectedAddIns
Clear-OfficeResiliency -SelectedAddIns $selectedAddIns

foreach ($addIn in $selectedAddIns) {
    Invoke-VstoUninstallIfPossible -AddIn $addIn
}

Remove-RedInkAddInKeys -SelectedAddIns $selectedAddIns
Clear-ClickOnceCache

foreach ($addIn in $selectedAddIns) {
    Install-AddInSilent -AddIn $addIn
    Configure-AddInRegistry -AddIn $addIn
    Validate-AddIn -AddIn $addIn
}

Write-Section 'Finished'
Write-Log 'Reset and reinstall finished successfully.'
Write-Host ''
Write-Host 'Start Word, Excel and Outlook manually and verify File > Options > Add-ins.'
exit 0

# AutoPilot Benutzerordner – sichere Einmalmigration für V15

## Zweck

Dieses Paket migriert bestehende AutoPilot-Benutzerdateien aus dem bisherigen Ordnerschema in den neuen sicheren V15-Namespace.

Das Skript arbeitet standardmäßig ausschließlich unter:

```text
%APPDATA%\Microsoft\Outlook\autopilot_users
```

Beispiel vorher:

```text
autopilot_users\
    elias_muehlemann_at_vischer_com\
        home\
            memory.txt
```

Beispiel nachher:

```text
autopilot_users\
    .identity_v2\
        elias_muehlemann_at_vischer_com__<24 SHA-256-Hexzeichen>\
            .owner_email
            home\
                memory.txt
```

**Der bisherige Legacy-Ordner wird vom Skript niemals gelöscht.**

---

## Wichtig: Scheduler ist davon nicht betroffen

Dieses Skript verändert:

- keine Scheduler-JSON,
- keine Schedules,
- keine Scheduler-Task-IDs,
- keine `schedule_tasks\<task-id>\workspace`-Ordner.

Wenn vorhandene Scheduler-Einträge bereits ein korrektes `CreatedBy` mit der Eigentümer-E-Mail-Adresse besitzen, ist wegen dieser Benutzerordner-Migration dort nichts anzupassen.

---

## Das Skript entspricht der aktuellen V15-Ordnerlogik

Es verwendet dieselben Identitätsregeln wie der aktuelle V15-Isolation-Patch:

1. E-Mail-Adresse: `Trim()` + Kleinschreibung.
2. Lesbarer Ordnerpräfix:
   - Buchstaben und Zahlen bleiben erhalten,
   - `-` bleibt erhalten,
   - `@` wird `_at_`,
   - jedes andere Zeichen wird `_`,
   - führende und nachfolgende `_` werden entfernt.
3. Der lesbare Präfix wird auf maximal **96 Zeichen** gekürzt.
4. Über die normalisierte E-Mail wird SHA-256 (UTF-8) gebildet.
5. Davon werden die ersten **24 kleingeschriebenen Hexzeichen** verwendet.
6. Zielname:

```text
<präfix>__<24-hex-hash>
```

7. Im Ziel wird `.owner_email` mit der normalisierten echten E-Mail-Adresse angelegt.

---

## Variante A – Migration mit Benutzerliste

Bei der ursprünglichen Variante wird dem Skript eine authoritative Liste der echten Benutzer-E-Mail-Adressen übergeben.

Diese Variante ist sinnvoll, wenn die echten E-Mail-Adressen unabhängig von den vorhandenen Legacy-Ordnernamen bekannt sind und bewusst geprüft werden sollen.

Beispiel:

```text
users.txt
```

mit:

```text
elias.muehlemann@vischer.com
max.mustermann@vischer.com
anna.beispiel@vischer.com
```

Aufruf:

```powershell
.\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt
```

---

## Variante B – Migration aller vorhandenen Benutzerverzeichnisse

Die zweite Variante benötigt **keine Benutzerliste**.

Das Skript:

```text
Migrate-AutoPilotUsers-AllFolders.ps1
```

liest alle vorhandenen Legacy-Benutzerverzeichnisse direkt unter

```text
%APPDATA%\Microsoft\Outlook\autopilot_users
```

ein.

Aus dem Ordnernamen wird die E-Mail-Adresse rekonstruiert.

Beispiel:

```text
adrian_doerig_at_vischer_com
```

wird zu:

```text
adrian.doerig@vischer.com
```

Dabei gilt:

- `_at_` wird zu `@`
- alle übrigen `_` werden zu `.`
- `.identity_v2` wird nicht als Legacy-Benutzerordner verarbeitet
- ungeeignete oder nicht eindeutig rückkonvertierbare Ordnernamen werden nicht stillschweigend migriert, sondern als Fehler behandelt
- die rekonstruierte E-Mail-Adresse wird nochmals in das Legacy-Ordnerschema zurückkonvertiert; nur wenn dabei exakt derselbe Legacy-Ordnername entsteht, wird die Zuordnung akzeptiert

Diese Variante setzt damit voraus, dass die vorhandenen Legacy-Ordner tatsächlich nach diesem Schema aufgebaut sind.

---

## Voraussetzungen

- Windows PowerShell 5.1 oder PowerShell 7
- Schreibzugriff auf `%APPDATA%\Microsoft\Outlook\autopilot_users`
- für Variante A: eine authoritative Benutzerliste mit den echten E-Mail-Adressen
- für Variante B: Legacy-Ordnernamen im erwarteten Schema, z. B. `adrian_doerig_at_vischer_com`
- empfohlen: Outlook für die eigentliche Migration schließen

---

# 1. PowerShell-Sicherheitsrichtlinie prüfen

Windows kann das Ausführen lokaler PowerShell-Skripte blockieren, insbesondere wenn für die aktuelle Umgebung eine restriktive `ExecutionPolicy` gilt.

Ein typischer Fehler lautet sinngemäß:

```text
Die Datei kann nicht geladen werden.
Die Datei ist nicht digital signiert.
Sie können dieses Skript im aktuellen System nicht ausführen.
```

Das ist in diesem Fall kein Fehler des Migrationsskripts, sondern eine PowerShell-Sicherheitsrichtlinie.

## Empfohlene temporäre Freigabe

Für die Migration sollte die Richtlinie nur für das **aktuelle PowerShell-Fenster** gelockert werden:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Danach kann das Skript normal gestartet werden.

Diese Änderung gilt ausschließlich für den aktuellen PowerShell-Prozess. Sobald das PowerShell-Fenster geschlossen wird, ist sie wieder aufgehoben.

Die systemweite oder benutzerweite `ExecutionPolicy` wird damit nicht dauerhaft geändert.

## Alternative: einmaliger Start mit Bypass

Statt die Richtlinie im geöffneten PowerShell-Fenster zu ändern, kann das Skript auch einmalig so gestartet werden:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\Migrate-AutoPilotUsers-AllFolders.ps1"
```

Für einen Dry-Run:

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\Migrate-AutoPilotUsers-AllFolders.ps1" -WhatIf
```

## Wichtig

`ExecutionPolicy Bypass` bedeutet, dass PowerShell die übliche Richtlinienprüfung für diesen Prozess nicht erzwingt.

Deshalb:

- nur Skripte aus einer vertrauenswürdigen Quelle ausführen
- das Skript vor dem produktiven Lauf prüfen
- möglichst `-Scope Process` statt einer dauerhaften Änderung verwenden
- keine globale `Unrestricted`- oder `Bypass`-Konfiguration setzen, wenn dies nicht ausdrücklich administrativ erforderlich ist

---

# 2. ZUERST Dry-Run

PowerShell im Ordner des Skripts öffnen.

Falls erforderlich:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

## Variante A – mit Benutzerliste

```powershell
.\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt -WhatIf
```

## Variante B – alle vorhandenen Verzeichnisse

```powershell
.\Migrate-AutoPilotUsers-AllFolders.ps1 -WhatIf
```

Der Dry-Run kopiert keine Benutzerdaten.

Er zeigt, was bei der Migration passieren würde.

Wichtige Statuswerte können – je nach Skriptvariante – unter anderem sein:

| Status | Bedeutung |
|---|---|
| `WHATIF` | würde migriert |
| `NO_SOURCE` | kein passender Quellbestand vorhanden |
| `ALREADY_MIGRATED` | bereits migriert und vollständig verifiziert |
| `V2_ONLY` | nur der neue V15-Ordner existiert und Owner stimmt |
| `AMBIGUOUS` | Zuordnung ist nicht eindeutig; keine Migration |
| `ERROR` | manuelle Prüfung erforderlich |

Vor dem echten Lauf sollten insbesondere **keine `AMBIGUOUS`- und keine `ERROR`-Fälle** vorhanden sein.

---

# 3. CSV-Report prüfen

Jeder Lauf schreibt unter

```text
%APPDATA%\Microsoft\Outlook\autopilot_users
```

einen Report wie:

```text
migration_report_20260819-091500.csv
```

Der Report enthält unter anderem:

- echte bzw. rekonstruierte E-Mail-Adresse,
- bisherigen Legacy-Ordnernamen,
- neuen V15-Ordnernamen,
- Quellpfad,
- Zielpfad,
- Status,
- Verifikation,
- Fehlermeldung/Hinweis.

Den Report beispielsweise in Excel öffnen und insbesondere `AMBIGUOUS`-/`ERROR`-Einträge prüfen.

---

# 4. Backup

Das Skript löscht die Legacy-Ordner zwar nicht. Vor einer produktiven Migration ist ein Backup trotzdem sinnvoll.

Beispiel:

```powershell
$src = Join-Path $env:APPDATA 'Microsoft\Outlook\autopilot_users'
Copy-Item $src "$src-backup-$(Get-Date -Format yyyyMMdd-HHmmss)" -Recurse
```

Bei großen Datenmengen kann selbstverständlich das vorhandene Backup-System verwendet werden.

---

# 5. Migration ausführen

Outlook möglichst schließen.

## Variante A – mit Benutzerliste

```powershell
.\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt
```

## Variante B – alle vorhandenen Verzeichnisse

```powershell
.\Migrate-AutoPilotUsers-AllFolders.ps1
```

Für jeden eindeutig zuordenbaren Benutzer:

1. wird der Legacy-Ordner gefunden,
2. wird der V15-Zielname exakt berechnet,
3. wird der Inhalt in `.identity_v2` kopiert,
4. wird `.owner_email` geschrieben,
5. werden Quelldateien und Zieldateien anhand von Größe und SHA-256 vollständig verglichen.

Der alte Ordner bleibt bestehen.

---

# 6. Migration anschließend zwingend verifizieren

Nach dem Kopierlauf:

## Variante A

```powershell
.\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt -VerifyOnly
```

## Variante B

```powershell
.\Migrate-AutoPilotUsers-AllFolders.ps1 -VerifyOnly
```

Erwarteter Status bei einer normalen erfolgreichen Migration:

```text
ALREADY_MIGRATED
```

Das bedeutet:

- `.owner_email` stimmt,
- alle Quelldateien existieren im Ziel,
- keine unerwarteten Nutzdateien sind hinzugekommen,
- Dateigrößen stimmen,
- SHA-256 stimmt für jede Datei.

`VerifyOnly` liefert einen Fehlercode zurück, wenn noch ein vorhandener Legacy-Ordner nicht migriert ist oder ein Sicherheits-/Verifikationsfehler besteht.

---

# 7. Stichprobe im Explorer

Öffnen:

```text
%APPDATA%\Microsoft\Outlook\autopilot_users\.identity_v2
```

Für einen Benutzer sollte beispielsweise vorhanden sein:

```text
elias_muehlemann_at_vischer_com__<24-hexzeichen>\
    .owner_email
    home\
        memory.txt
```

`.owner_email` öffnen.

Dort muss die echte normalisierte Adresse stehen:

```text
elias.muehlemann@vischer.com
```

Bei Variante B muss dies genau der Adresse entsprechen, die aus dem Legacy-Ordnernamen rekonstruiert wurde.

Stichprobenweise auch `home` und `memory.txt` prüfen.

---

# 8. Funktionstest mit AutoPilot

Nach erfolgreichem `-VerifyOnly`:

1. Outlook wieder starten.
2. AutoPilot mit Benutzer A testen.
3. Prüfen, ob Memory und gespeicherte Dateien von A verfügbar sind.
4. AutoPilot mit Benutzer B testen.
5. Prüfen, ob B nur seine eigenen Daten sieht.
6. Prüfen, dass A anschließend weiterhin nur A-Daten erhält.

Die Legacy-Ordner zunächst behalten.

Erst nach einer Beobachtungs-/Backup-Phase können sie separat archiviert werden. Dieses Skript löscht sie absichtlich nicht.

---

## Wiederholbarkeit

Beide Skriptvarianten können erneut ausgeführt werden.

Wenn ein Ziel bereits vorhanden ist, wird geprüft:

- `.owner_email`,
- alle Dateien,
- Dateigrößen,
- SHA-256.

Stimmt alles, lautet der Status:

```text
ALREADY_MIGRATED
```

Es muss dann nichts erneut kopiert werden.

---

## Abweichende Dateien im Ziel

Existiert eine gleichnamige Datei im neuen Ziel bereits mit anderem Inhalt, bricht das Skript standardmäßig ab.

Nur nach manueller Prüfung gibt es die explizite Option.

### Variante A

```powershell
.\Migrate-AutoPilotUsers.ps1 `
    -EmailListPath .\users.txt `
    -OverwriteDestinationFiles
```

### Variante B

```powershell
.\Migrate-AutoPilotUsers-AllFolders.ps1 `
    -OverwriteDestinationFiles
```

Für eine normale Erstmigration sollte diese Option **nicht erforderlich** sein.

---

## Sicherheitsunterschied zwischen Variante A und Variante B

### Variante A

Die E-Mail-Adresse stammt aus einer separaten authoritative Benutzerliste.

Der Legacy-Ordnername selbst wird damit nicht als Eigentumsnachweis verwendet.

### Variante B

Die E-Mail-Adresse wird aus dem vorhandenen Legacy-Ordnernamen rekonstruiert.

Beispiel:

```text
adrian_doerig_at_vischer_com
```

ergibt:

```text
adrian.doerig@vischer.com
```

Diese Variante ist deshalb nur dann geeignet, wenn bekannt ist, dass die Legacy-Ordnernamen zuverlässig nach diesem Schema erzeugt wurden.

Die zusätzliche Rückprüfung des rekonstruierten Namens verhindert offensichtliche Fehlinterpretationen, ersetzt aber keine externe authoritative Identitätsquelle.

Wenn höchstmögliche Identitätssicherheit gefordert ist, ist Variante A vorzuziehen.

---

## Rückfallmöglichkeit

Weil die alten Benutzerordner nicht gelöscht werden, besteht eine einfache Sicherheitsreserve:

- Neuer V15-Bestand befindet sich unter `.identity_v2`.
- Alter Bestand bleibt unverändert daneben.
- Ein fehlgeschlagener oder nicht verifizierter Benutzer kann separat untersucht werden.

Bitte die alten Ordner nicht löschen, bevor der V15-Betrieb mit mehreren Benutzern erfolgreich getestet wurde.

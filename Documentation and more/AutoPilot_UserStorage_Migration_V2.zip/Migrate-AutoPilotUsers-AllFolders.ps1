﻿<#
.SYNOPSIS
Safely migrates all existing legacy AutoPilot user folders to the V15 .identity_v2 namespace.

.DESCRIPTION
Default working root:
  %APPDATA%\Microsoft\Outlook\autopilot_users

No user/e-mail list is required.
The script enumerates all immediate subdirectories below the root (except .identity_v2)
and derives the e-mail address from the legacy folder name.

Expected legacy naming convention:
  adrian_doerig_at_vischer_com  ->  adrian.doerig@vischer.com

Conversion rule:
  - exactly one "_at_" separates local part and domain
  - all remaining "_" characters become "."
  - the resulting e-mail is normalized with Trim + ToLowerInvariant

The V15 destination identity rules remain unchanged:
  - letters/digits/hyphen stay unchanged
  - @ becomes "_at_"
  - every other character becomes "_"
  - display prefix: maximum 96 characters
  - identity suffix: first 24 lowercase hexadecimal characters of SHA-256(UTF-8 normalized e-mail)
  - destination:
      .identity_v2\<display-prefix>__<24-char-hash>\
  - owner marker:
      .owner_email

IMPORTANT
The legacy folder name is now deliberately used as the source for the e-mail identity.
This is safe only if the existing folder names reliably follow the stated naming convention.
Folders that cannot be converted unambiguously are reported as ERROR and are not migrated.

The legacy source folder is NEVER deleted by this script.

EXAMPLES
Dry run:
  .\Migrate-AutoPilotUsers-FromFolders.ps1 -WhatIf

Migration:
  .\Migrate-AutoPilotUsers-FromFolders.ps1

Verification:
  .\Migrate-AutoPilotUsers-FromFolders.ps1 -VerifyOnly
#>

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $false)]
    [string]$RootPath = (Join-Path $env:APPDATA 'Microsoft\Outlook\autopilot_users'),

    [Parameter(Mandatory = $false)]
    [switch]$VerifyOnly,

    [Parameter(Mandatory = $false)]
    [switch]$OverwriteDestinationFiles
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$IdentitySubdirectory = '.identity_v2'
$OwnerFileName = '.owner_email'
$IdentityHashHexLength = 24
$IdentityDisplayPrefixMaxLength = 96

function Normalize-Email {
    param([Parameter(Mandatory = $true)][string]$Email)

    $value = $Email.Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw 'Empty e-mail address is not allowed.'
    }

    # Structural sanity check only. The supplied list remains authoritative.
    if ($value -notmatch '^[^@\s]+@[^@\s]+$') {
        throw "Invalid e-mail address: '$Email'"
    }

    return $value
}

function ConvertFrom-LegacyFolderNameToEmail {
    param([Parameter(Mandatory = $true)][string]$LegacyFolderName)

    $parts = @($LegacyFolderName -split '_at_', 0, 'IgnoreCase')

    if ($parts.Count -ne 2) {
        throw "Legacy folder name must contain exactly one '_at_': '$LegacyFolderName'"
    }

    $localPart = $parts[0].Replace('_', '.')
    $domainPart = $parts[1].Replace('_', '.')

    if ([string]::IsNullOrWhiteSpace($localPart) -or [string]::IsNullOrWhiteSpace($domainPart)) {
        throw "Legacy folder name cannot be converted to an e-mail address: '$LegacyFolderName'"
    }

    return Normalize-Email -Email ($localPart + '@' + $domainPart)
}

function ConvertTo-V15SafeEmailPrefix {
    param([Parameter(Mandatory = $true)][string]$NormalizedEmail)

    $sb = New-Object System.Text.StringBuilder

    foreach ($c in $NormalizedEmail.ToCharArray()) {
        if ([char]::IsLetterOrDigit($c) -or $c -eq '-') {
            [void]$sb.Append($c)
        }
        elseif ($c -eq '@') {
            [void]$sb.Append('_at_')
        }
        else {
            [void]$sb.Append('_')
        }
    }

    $result = $sb.ToString().Trim('_')

    if ($result.Length -eq 0) {
        $result = '_unknown_'
    }

    return $result
}

function Get-V15Sha256Hex {
    param([Parameter(Mandatory = $true)][string]$NormalizedEmail)

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($NormalizedEmail)
    $sha = [System.Security.Cryptography.SHA256]::Create()

    try {
        $hash = $sha.ComputeHash($bytes)
        $sb = New-Object System.Text.StringBuilder ($hash.Length * 2)
        foreach ($b in $hash) {
            [void]$sb.Append($b.ToString('x2', [System.Globalization.CultureInfo]::InvariantCulture))
        }
        return $sb.ToString()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-V15CanonicalFolderName {
    param([Parameter(Mandatory = $true)][string]$NormalizedEmail)

    $displayPrefix = ConvertTo-V15SafeEmailPrefix -NormalizedEmail $NormalizedEmail
    if ($displayPrefix.Length -gt $IdentityDisplayPrefixMaxLength) {
        $displayPrefix = $displayPrefix.Substring(0, $IdentityDisplayPrefixMaxLength)
    }

    $hashHex = Get-V15Sha256Hex -NormalizedEmail $NormalizedEmail
    $hashPart = $hashHex
    if ($hashPart.Length -gt $IdentityHashHexLength) {
        $hashPart = $hashPart.Substring(0, $IdentityHashHexLength)
    }

    return $displayPrefix + '__' + $hashPart
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-RelativeFileMap {
    param([Parameter(Mandatory = $true)][string]$BasePath)

    $result = @{}

    if (-not (Test-Path -LiteralPath $BasePath -PathType Container)) {
        return $result
    }

    $base = [System.IO.Path]::GetFullPath($BasePath).TrimEnd('\') + '\'

    foreach ($file in (Get-ChildItem -LiteralPath $BasePath -Recurse -File -Force)) {
        $full = [System.IO.Path]::GetFullPath($file.FullName)
        $relative = $full.Substring($base.Length)
        $result[$relative] = $file.FullName
    }

    return $result
}

function Test-MigratedTree {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationPath
    )

    $sourceMap = Get-RelativeFileMap -BasePath $SourcePath
    $destinationRaw = Get-RelativeFileMap -BasePath $DestinationPath
    $destinationMap = @{}

    foreach ($relative in $destinationRaw.Keys) {
        if ($relative -ieq $OwnerFileName) {
            continue
        }
        $destinationMap[$relative] = $destinationRaw[$relative]
    }

    $errors = New-Object 'System.Collections.Generic.List[string]'

    foreach ($relative in $sourceMap.Keys) {
        if (-not $destinationMap.ContainsKey($relative)) {
            $errors.Add("Missing destination file: $relative")
            continue
        }

        $sourceInfo = Get-Item -LiteralPath $sourceMap[$relative]
        $destinationInfo = Get-Item -LiteralPath $destinationMap[$relative]

        if ($sourceInfo.Length -ne $destinationInfo.Length) {
            $errors.Add("Size differs: $relative")
            continue
        }

        $sourceHash = Get-FileSha256 -Path $sourceMap[$relative]
        $destinationHash = Get-FileSha256 -Path $destinationMap[$relative]

        if ($sourceHash -cne $destinationHash) {
            $errors.Add("SHA-256 differs: $relative")
        }
    }

    foreach ($relative in $destinationMap.Keys) {
        if (-not $sourceMap.ContainsKey($relative)) {
            $errors.Add("Unexpected destination file: $relative")
        }
    }

    # Important: do NOT use `return ,$errors` here.
    # The unary comma wraps the List[string] as one single pipeline object.
    # The caller uses @(...), so even an empty error list would then have Count = 1
    # and stringify as "System.Collections.Generic.List`1[System.String]".
    # Returning the list normally lets PowerShell enumerate its string entries;
    # an empty list therefore produces zero results as intended.
    return $errors
}

function Copy-LegacyTree {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationPath,
        [Parameter(Mandatory = $true)][bool]$AllowOverwrite
    )

    if (-not (Test-Path -LiteralPath $DestinationPath -PathType Container)) {
        New-Item -ItemType Directory -Path $DestinationPath -Force | Out-Null
    }

    foreach ($item in (Get-ChildItem -LiteralPath $SourcePath -Force)) {
        $target = Join-Path $DestinationPath $item.Name

        if ($item.PSIsContainer) {
            Copy-LegacyTree -SourcePath $item.FullName -DestinationPath $target -AllowOverwrite $AllowOverwrite
            continue
        }

        if (Test-Path -LiteralPath $target -PathType Leaf) {
            $sourceHash = Get-FileSha256 -Path $item.FullName
            $destinationHash = Get-FileSha256 -Path $target

            if ($sourceHash -ceq $destinationHash) {
                continue
            }

            if (-not $AllowOverwrite) {
                throw "Destination file exists with different content: '$target'. Review manually before using -OverwriteDestinationFiles."
            }
        }

        Copy-Item -LiteralPath $item.FullName -Destination $target -Force:$AllowOverwrite
    }
}

$RootPath = [System.IO.Path]::GetFullPath($RootPath)

if (-not (Test-Path -LiteralPath $RootPath -PathType Container)) {
    throw "AutoPilot user root does not exist: '$RootPath'"
}

$IdentityV2Path = Join-Path $RootPath $IdentitySubdirectory
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$reportPath = Join-Path $RootPath "migration_report_$timestamp.csv"

$legacyDirectories = @(
    Get-ChildItem -LiteralPath $RootPath -Directory -Force |
        Where-Object { $_.Name -ine $IdentitySubdirectory } |
        Sort-Object -Property Name
)

if ($legacyDirectories.Count -eq 0) {
    throw "No legacy user directories found below '$RootPath'."
}

$items = New-Object 'System.Collections.Generic.List[object]'
$discoveryErrors = New-Object 'System.Collections.Generic.List[object]'

foreach ($directory in $legacyDirectories) {
    try {
        $email = ConvertFrom-LegacyFolderNameToEmail -LegacyFolderName $directory.Name

        # Round-trip check: the derived e-mail must reproduce the exact legacy folder name.
        $expectedLegacyName = ConvertTo-V15SafeEmailPrefix -NormalizedEmail $email
        if ($expectedLegacyName -cne $directory.Name) {
            throw "Legacy folder name does not round-trip to the derived e-mail '$email': '$($directory.Name)'"
        }

        $canonicalName = Get-V15CanonicalFolderName -NormalizedEmail $email

        $items.Add(
            [pscustomobject]@{
                Email = $email
                LegacyName = $directory.Name
                CanonicalName = $canonicalName
                LegacyPath = $directory.FullName
                DestinationPath = Join-Path $IdentityV2Path $canonicalName
            }
        )
    }
    catch {
        $discoveryErrors.Add(
            [pscustomobject]@{
                Email = ''
                LegacyFolder = $directory.Name
                CanonicalFolder = ''
                LegacyPath = $directory.FullName
                DestinationPath = ''
                Status = 'ERROR'
                Verified = $false
                Message = $_.Exception.Message
            }
        )
    }
}

# Detect duplicate identities derived from different legacy folders.
$collisionGroups = @(
    $items |
        Group-Object -Property Email |
        Where-Object { $_.Count -gt 1 }
)

$collidingEmails = @{}
foreach ($group in $collisionGroups) {
    $collidingEmails[$group.Name] = $true
}

$modeName = 'MIGRATE'
if ($VerifyOnly) {
    $modeName = 'VERIFY ONLY'
}
elseif ($WhatIfPreference) {
    $modeName = 'WHATIF / DRY RUN'
}

Write-Host ''
Write-Host 'AutoPilot user-storage migration'
Write-Host "Root: $RootPath"
Write-Host "Legacy directories found: $($legacyDirectories.Count)"
Write-Host "Convertible directories: $($items.Count)"
Write-Host "Invalid directory names: $($discoveryErrors.Count)"
Write-Host "Derived e-mail collisions: $($collisionGroups.Count)"
Write-Host "Mode: $modeName"
Write-Host ''

if (-not $VerifyOnly -and -not (Test-Path -LiteralPath $IdentityV2Path -PathType Container)) {
    if ($PSCmdlet.ShouldProcess($IdentityV2Path, 'Create V15 .identity_v2 namespace')) {
        New-Item -ItemType Directory -Path $IdentityV2Path -Force | Out-Null
    }
}

$report = New-Object 'System.Collections.Generic.List[object]'
foreach ($discoveryError in $discoveryErrors) {
    $report.Add($discoveryError)
    Write-Host "[!!] $($discoveryError.LegacyFolder) -> ERROR"
    Write-Host "     $($discoveryError.Message)"
}

foreach ($item in $items) {
    $status = ''
    $message = ''
    $verified = $false

    try {
        if ($collidingEmails.ContainsKey($item.Email)) {
            $status = 'AMBIGUOUS'
            $message = 'Multiple legacy folders resolve to the same e-mail address. Nothing changed.'
            throw [System.InvalidOperationException]::new($message)
        }

        $sourceExists = Test-Path -LiteralPath $item.LegacyPath -PathType Container
        $destinationExists = Test-Path -LiteralPath $item.DestinationPath -PathType Container
        $ownerPath = Join-Path $item.DestinationPath $OwnerFileName

        if (-not $sourceExists -and -not $destinationExists) {
            $status = 'NO_SOURCE'
            $message = 'No legacy folder and no V15 identity folder found.'
        }
        elseif ($destinationExists) {
            $ownerExists = Test-Path -LiteralPath $ownerPath -PathType Leaf

            if (-not $ownerExists) {
                if (-not $sourceExists) {
                    throw "Destination exists but '$OwnerFileName' is missing, and no legacy source exists for safe verification: '$($item.DestinationPath)'"
                }

                $verificationErrors = @(Test-MigratedTree -SourcePath $item.LegacyPath -DestinationPath $item.DestinationPath)
                if ($verificationErrors.Count -gt 0) {
                    throw ('Destination is missing owner marker and does not exactly match legacy source; marker was NOT created: ' + ($verificationErrors -join '; '))
                }

                if ($VerifyOnly) {
                    $status = 'MISSING_OWNER_MARKER'
                    $message = "Destination file tree matches legacy source exactly, but '$OwnerFileName' is missing. Run without -VerifyOnly to repair it safely."
                }
                else {
                    $repairAction = "Create missing '$OwnerFileName' after complete size/SHA-256 verification"

                    if ($PSCmdlet.ShouldProcess($ownerPath, $repairAction)) {
                        $utf8NoBom = New-Object System.Text.UTF8Encoding -ArgumentList $false
                        [System.IO.File]::WriteAllText($ownerPath, ($item.Email + [Environment]::NewLine), $utf8NoBom)

                        $owner = Normalize-Email -Email (Get-Content -LiteralPath $ownerPath -Raw)
                        if ($owner -cne $item.Email) {
                            Remove-Item -LiteralPath $ownerPath -Force -ErrorAction SilentlyContinue
                            throw "Repaired owner-marker verification failed for '$($item.DestinationPath)'."
                        }

                        $verificationErrors = @(Test-MigratedTree -SourcePath $item.LegacyPath -DestinationPath $item.DestinationPath)
                        if ($verificationErrors.Count -gt 0) {
                            Remove-Item -LiteralPath $ownerPath -Force -ErrorAction SilentlyContinue
                            throw ('Post-repair verification failed; owner marker was removed again: ' + ($verificationErrors -join '; '))
                        }

                        $status = 'REPAIRED_OWNER_MARKER'
                        $verified = $true
                        $message = "Existing destination matched legacy source exactly by size and SHA-256; missing '$OwnerFileName' was created and verified."
                    }
                    else {
                        $status = 'WHATIF_REPAIR_OWNER_MARKER'
                        $message = "Destination matches legacy source exactly; would create missing '$OwnerFileName'."
                    }
                }
            }
            else {
                $owner = Normalize-Email -Email (Get-Content -LiteralPath $ownerPath -Raw)

                if ($owner -cne $item.Email) {
                    throw "Destination owner mismatch. Expected '$($item.Email)', found '$owner'."
                }

                if ($sourceExists) {
                    $verificationErrors = @(Test-MigratedTree -SourcePath $item.LegacyPath -DestinationPath $item.DestinationPath)
                    if ($verificationErrors.Count -gt 0) {
                        throw ('Existing destination does not match legacy source: ' + ($verificationErrors -join '; '))
                    }

                    $status = 'ALREADY_MIGRATED'
                    $verified = $true
                    $message = 'Owner marker matches and complete file tree verifies by size and SHA-256.'
                }
                else {
                    $status = 'V2_ONLY'
                    $verified = $true
                    $message = 'Only the V15 identity folder exists; owner marker matches.'
                }
            }
        }
        elseif ($VerifyOnly) {
            $status = 'NOT_MIGRATED'
            $message = 'Legacy folder exists but the V15 identity folder does not.'
        }
        else {
            if ($PSCmdlet.ShouldProcess($item.LegacyPath, "Copy to '$($item.DestinationPath)' and create '$OwnerFileName'")) {
                New-Item -ItemType Directory -Path $item.DestinationPath -Force | Out-Null

                Copy-LegacyTree `
                    -SourcePath $item.LegacyPath `
                    -DestinationPath $item.DestinationPath `
                    -AllowOverwrite ([bool]$OverwriteDestinationFiles)

                [System.IO.File]::WriteAllText(
                    $ownerPath,
                    $item.Email + [Environment]::NewLine,
                    (New-Object System.Text.UTF8Encoding($false))
                )

                $owner = Normalize-Email -Email (Get-Content -LiteralPath $ownerPath -Raw)
                if ($owner -cne $item.Email) {
                    throw "Owner-marker verification failed for '$($item.DestinationPath)'."
                }

                $verificationErrors = @(Test-MigratedTree -SourcePath $item.LegacyPath -DestinationPath $item.DestinationPath)
                if ($verificationErrors.Count -gt 0) {
                    throw ('Post-copy verification failed: ' + ($verificationErrors -join '; '))
                }

                $status = 'MIGRATED'
                $verified = $true
                $message = 'Copied successfully; owner marker, file sizes and SHA-256 all verified.'
            }
            else {
                $status = 'WHATIF'
                $message = 'Would migrate this unique legacy folder.'
            }
        }
    }
    catch {
        if (-not $status) {
            $status = 'ERROR'
        }

        if (-not $message) {
            $message = $_.Exception.Message
        }
    }

    $report.Add(
        [pscustomobject]@{
            Email = $item.Email
            LegacyFolder = $item.LegacyName
            CanonicalFolder = $item.CanonicalName
            LegacyPath = $item.LegacyPath
            DestinationPath = $item.DestinationPath
            Status = $status
            Verified = $verified
            Message = $message
        }
    )

    $symbol = '[!!]'
    if ($status -in @('MIGRATED', 'ALREADY_MIGRATED', 'V2_ONLY', 'REPAIRED_OWNER_MARKER')) {
        $symbol = '[OK]'
    }
    elseif ($status -in @('WHATIF', 'WHATIF_REPAIR_OWNER_MARKER', 'NOT_MIGRATED', 'NO_SOURCE', 'MISSING_OWNER_MARKER')) {
        $symbol = '[--]'
    }

    Write-Host "$symbol $($item.Email) -> $status"
    if ($message) {
        Write-Host "     $message"
    }
}

$report | Export-Csv -LiteralPath $reportPath -NoTypeInformation -Encoding UTF8

Write-Host ''
Write-Host 'Report written to:'
Write-Host "  $reportPath"
Write-Host ''

$bad = @($report | Where-Object { $_.Status -in @('AMBIGUOUS', 'ERROR') })
$notMigrated = @($report | Where-Object { $_.Status -in @('NOT_MIGRATED', 'MISSING_OWNER_MARKER') })

if ($bad.Count -gt 0) {
    Write-Warning "$($bad.Count) user(s) require manual review. No ambiguous mapping was migrated."
    exit 2
}

if ($VerifyOnly -and $notMigrated.Count -gt 0) {
    Write-Warning "$($notMigrated.Count) user(s) still have a legacy folder without a V15 identity migration."
    exit 3
}

Write-Host 'Completed without migration errors.'
exit 0

﻿<#
.SYNOPSIS
Safely migrates legacy AutoPilot user storage folders to the V15 .identity_v2 namespace.

.DESCRIPTION
Default working root:
  %APPDATA%\Microsoft\Outlook\autopilot_users

This script implements the same user-folder identity rules as the current V15 isolation patch:
  - Normalize e-mail: Trim + ToLowerInvariant
  - Legacy/display sanitizer:
      letters/digits/hyphen stay unchanged
      @ becomes "_at_"
      every other character becomes "_"
      leading/trailing "_" are removed
  - display prefix: maximum 96 characters
  - identity suffix: first 24 lowercase hexadecimal characters of SHA-256(UTF-8 normalized e-mail)
  - destination:
      .identity_v2\<display-prefix>__<24-char-hash>\
  - owner marker:
      .owner_email

SECURITY
The old folder name is NOT accepted as sole proof of ownership.
An authoritative e-mail list is required. Before copying anything, the script checks whether
multiple supplied e-mail addresses map to the same legacy folder name. Ambiguous mappings
are never migrated.

The legacy source folder is NEVER deleted by this script.

EXAMPLES
Dry run:
  .\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt -WhatIf

Migration:
  .\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt

Verification:
  .\Migrate-AutoPilotUsers.ps1 -EmailListPath .\users.txt -VerifyOnly
#>

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$EmailListPath,

    [Parameter(Mandatory = $false)]
    [string]$RootPath = (Join-Path $env:APPDATA 'Microsoft\Outlook\autopilot_users'),

    [Parameter(Mandatory = $false)]
    [switch]$VerifyOnly,

    [Parameter(Mandatory = $false)]
    [switch]$OverwriteDestinationFiles
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$IdentitySubdirectory = '.identity_v2'
$OwnerFileName = '.owner_email'
$IdentityHashHexLength = 24
$IdentityDisplayPrefixMaxLength = 96

function Normalize-Email {
    param([Parameter(Mandatory = $true)][string]$Email)

    $value = $Email.Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw 'Empty e-mail address is not allowed.'
    }

    # Structural sanity check only. The supplied list remains authoritative.
    if ($value -notmatch '^[^@\s]+@[^@\s]+$') {
        throw "Invalid e-mail address: '$Email'"
    }

    return $value
}

function ConvertTo-V15SafeEmailPrefix {
    param([Parameter(Mandatory = $true)][string]$NormalizedEmail)

    $sb = New-Object System.Text.StringBuilder

    foreach ($c in $NormalizedEmail.ToCharArray()) {
        if ([char]::IsLetterOrDigit($c) -or $c -eq '-') {
            [void]$sb.Append($c)
        }
        elseif ($c -eq '@') {
            [void]$sb.Append('_at_')
        }
        else {
            [void]$sb.Append('_')
        }
    }

    $result = $sb.ToString().Trim('_')

    if ($result.Length -eq 0) {
        $result = '_unknown_'
    }

    return $result
}

function Get-V15Sha256Hex {
    param([Parameter(Mandatory = $true)][string]$NormalizedEmail)

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($NormalizedEmail)
    $sha = [System.Security.Cryptography.SHA256]::Create()

    try {
        $hash = $sha.ComputeHash($bytes)
        $sb = New-Object System.Text.StringBuilder ($hash.Length * 2)
        foreach ($b in $hash) {
            [void]$sb.Append($b.ToString('x2', [System.Globalization.CultureInfo]::InvariantCulture))
        }
        return $sb.ToString()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-V15CanonicalFolderName {
    param([Parameter(Mandatory = $true)][string]$NormalizedEmail)

    $displayPrefix = ConvertTo-V15SafeEmailPrefix -NormalizedEmail $NormalizedEmail
    if ($displayPrefix.Length -gt $IdentityDisplayPrefixMaxLength) {
        $displayPrefix = $displayPrefix.Substring(0, $IdentityDisplayPrefixMaxLength)
    }

    $hashHex = Get-V15Sha256Hex -NormalizedEmail $NormalizedEmail
    $hashPart = $hashHex
    if ($hashPart.Length -gt $IdentityHashHexLength) {
        $hashPart = $hashPart.Substring(0, $IdentityHashHexLength)
    }

    return $displayPrefix + '__' + $hashPart
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-RelativeFileMap {
    param([Parameter(Mandatory = $true)][string]$BasePath)

    $result = @{}

    if (-not (Test-Path -LiteralPath $BasePath -PathType Container)) {
        return $result
    }

    $base = [System.IO.Path]::GetFullPath($BasePath).TrimEnd('\') + '\'

    foreach ($file in (Get-ChildItem -LiteralPath $BasePath -Recurse -File -Force)) {
        $full = [System.IO.Path]::GetFullPath($file.FullName)
        $relative = $full.Substring($base.Length)
        $result[$relative] = $file.FullName
    }

    return $result
}

function Test-MigratedTree {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationPath
    )

    $sourceMap = Get-RelativeFileMap -BasePath $SourcePath
    $destinationRaw = Get-RelativeFileMap -BasePath $DestinationPath
    $destinationMap = @{}

    foreach ($relative in $destinationRaw.Keys) {
        if ($relative -ieq $OwnerFileName) {
            continue
        }
        $destinationMap[$relative] = $destinationRaw[$relative]
    }

    $errors = New-Object 'System.Collections.Generic.List[string]'

    foreach ($relative in $sourceMap.Keys) {
        if (-not $destinationMap.ContainsKey($relative)) {
            $errors.Add("Missing destination file: $relative")
            continue
        }

        $sourceInfo = Get-Item -LiteralPath $sourceMap[$relative]
        $destinationInfo = Get-Item -LiteralPath $destinationMap[$relative]

        if ($sourceInfo.Length -ne $destinationInfo.Length) {
            $errors.Add("Size differs: $relative")
            continue
        }

        $sourceHash = Get-FileSha256 -Path $sourceMap[$relative]
        $destinationHash = Get-FileSha256 -Path $destinationMap[$relative]

        if ($sourceHash -cne $destinationHash) {
            $errors.Add("SHA-256 differs: $relative")
        }
    }

    foreach ($relative in $destinationMap.Keys) {
        if (-not $sourceMap.ContainsKey($relative)) {
            $errors.Add("Unexpected destination file: $relative")
        }
    }

    return ,$errors
}

function Copy-LegacyTree {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationPath,
        [Parameter(Mandatory = $true)][bool]$AllowOverwrite
    )

    if (-not (Test-Path -LiteralPath $DestinationPath -PathType Container)) {
        New-Item -ItemType Directory -Path $DestinationPath -Force | Out-Null
    }

    foreach ($item in (Get-ChildItem -LiteralPath $SourcePath -Force)) {
        $target = Join-Path $DestinationPath $item.Name

        if ($item.PSIsContainer) {
            Copy-LegacyTree -SourcePath $item.FullName -DestinationPath $target -AllowOverwrite $AllowOverwrite
            continue
        }

        if (Test-Path -LiteralPath $target -PathType Leaf) {
            $sourceHash = Get-FileSha256 -Path $item.FullName
            $destinationHash = Get-FileSha256 -Path $target

            if ($sourceHash -ceq $destinationHash) {
                continue
            }

            if (-not $AllowOverwrite) {
                throw "Destination file exists with different content: '$target'. Review manually before using -OverwriteDestinationFiles."
            }
        }

        Copy-Item -LiteralPath $item.FullName -Destination $target -Force:$AllowOverwrite
    }
}

if (-not (Test-Path -LiteralPath $EmailListPath -PathType Leaf)) {
    throw "E-mail list not found: '$EmailListPath'"
}

$RootPath = [System.IO.Path]::GetFullPath($RootPath)

if (-not (Test-Path -LiteralPath $RootPath -PathType Container)) {
    throw "AutoPilot user root does not exist: '$RootPath'"
}

$IdentityV2Path = Join-Path $RootPath $IdentitySubdirectory
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$reportPath = Join-Path $RootPath "migration_report_$timestamp.csv"

$emails = @(
    Get-Content -LiteralPath $EmailListPath |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') } |
        ForEach-Object { Normalize-Email -Email $_ } |
        Sort-Object -Unique
)

if ($emails.Count -eq 0) {
    throw "No e-mail addresses found in '$EmailListPath'."
}

$items = @(
    foreach ($email in $emails) {
        $legacyName = ConvertTo-V15SafeEmailPrefix -NormalizedEmail $email
        $canonicalName = Get-V15CanonicalFolderName -NormalizedEmail $email

        [pscustomobject]@{
            Email = $email
            LegacyName = $legacyName
            CanonicalName = $canonicalName
            LegacyPath = Join-Path $RootPath $legacyName
            DestinationPath = Join-Path $IdentityV2Path $canonicalName
        }
    }
)

# Security-critical: check all supplied identities before any migration.
$collisionGroups = @(
    $items |
        Group-Object -Property LegacyName |
        Where-Object { $_.Count -gt 1 }
)

$collidingLegacyNames = @{}
foreach ($group in $collisionGroups) {
    $collidingLegacyNames[$group.Name] = $true
}

$modeName = 'MIGRATE'
if ($VerifyOnly) {
    $modeName = 'VERIFY ONLY'
}
elseif ($WhatIfPreference) {
    $modeName = 'WHATIF / DRY RUN'
}

Write-Host ''
Write-Host 'AutoPilot user-storage migration'
Write-Host "Root: $RootPath"
Write-Host "Users supplied: $($items.Count)"
Write-Host "Legacy-name collisions in supplied list: $($collisionGroups.Count)"
Write-Host "Mode: $modeName"
Write-Host ''

if (-not $VerifyOnly -and -not (Test-Path -LiteralPath $IdentityV2Path -PathType Container)) {
    if ($PSCmdlet.ShouldProcess($IdentityV2Path, 'Create V15 .identity_v2 namespace')) {
        New-Item -ItemType Directory -Path $IdentityV2Path -Force | Out-Null
    }
}

$report = New-Object 'System.Collections.Generic.List[object]'

foreach ($item in $items) {
    $status = ''
    $message = ''
    $verified = $false

    try {
        if ($collidingLegacyNames.ContainsKey($item.LegacyName)) {
            $status = 'AMBIGUOUS'
            $message = 'Multiple supplied e-mail addresses map to the same legacy folder. Nothing changed.'
            throw [System.InvalidOperationException]::new($message)
        }

        $sourceExists = Test-Path -LiteralPath $item.LegacyPath -PathType Container
        $destinationExists = Test-Path -LiteralPath $item.DestinationPath -PathType Container
        $ownerPath = Join-Path $item.DestinationPath $OwnerFileName

        if (-not $sourceExists -and -not $destinationExists) {
            $status = 'NO_SOURCE'
            $message = 'No legacy folder and no V15 identity folder found.'
        }
        elseif ($destinationExists) {
            if (-not (Test-Path -LiteralPath $ownerPath -PathType Leaf)) {
                throw "Destination exists but '$OwnerFileName' is missing: '$($item.DestinationPath)'"
            }

            $owner = Normalize-Email -Email (Get-Content -LiteralPath $ownerPath -Raw)

            if ($owner -cne $item.Email) {
                throw "Destination owner mismatch. Expected '$($item.Email)', found '$owner'."
            }

            if ($sourceExists) {
                $verificationErrors = @(Test-MigratedTree -SourcePath $item.LegacyPath -DestinationPath $item.DestinationPath)
                if ($verificationErrors.Count -gt 0) {
                    throw ('Existing destination does not match legacy source: ' + ($verificationErrors -join '; '))
                }

                $status = 'ALREADY_MIGRATED'
                $verified = $true
                $message = 'Owner marker matches and complete file tree verifies by size and SHA-256.'
            }
            else {
                $status = 'V2_ONLY'
                $verified = $true
                $message = 'Only the V15 identity folder exists; owner marker matches.'
            }
        }
        elseif ($VerifyOnly) {
            $status = 'NOT_MIGRATED'
            $message = 'Legacy folder exists but the V15 identity folder does not.'
        }
        else {
            if ($PSCmdlet.ShouldProcess($item.LegacyPath, "Copy to '$($item.DestinationPath)' and create '$OwnerFileName'")) {
                New-Item -ItemType Directory -Path $item.DestinationPath -Force | Out-Null

                Copy-LegacyTree `
                    -SourcePath $item.LegacyPath `
                    -DestinationPath $item.DestinationPath `
                    -AllowOverwrite ([bool]$OverwriteDestinationFiles)

                [System.IO.File]::WriteAllText(
                    $ownerPath,
                    $item.Email + [Environment]::NewLine,
                    (New-Object System.Text.UTF8Encoding($false))
                )

                $owner = Normalize-Email -Email (Get-Content -LiteralPath $ownerPath -Raw)
                if ($owner -cne $item.Email) {
                    throw "Owner-marker verification failed for '$($item.DestinationPath)'."
                }

                $verificationErrors = @(Test-MigratedTree -SourcePath $item.LegacyPath -DestinationPath $item.DestinationPath)
                if ($verificationErrors.Count -gt 0) {
                    throw ('Post-copy verification failed: ' + ($verificationErrors -join '; '))
                }

                $status = 'MIGRATED'
                $verified = $true
                $message = 'Copied successfully; owner marker, file sizes and SHA-256 all verified.'
            }
            else {
                $status = 'WHATIF'
                $message = 'Would migrate this unique legacy folder.'
            }
        }
    }
    catch {
        if (-not $status) {
            $status = 'ERROR'
        }

        if (-not $message) {
            $message = $_.Exception.Message
        }
    }

    $report.Add(
        [pscustomobject]@{
            Email = $item.Email
            LegacyFolder = $item.LegacyName
            CanonicalFolder = $item.CanonicalName
            LegacyPath = $item.LegacyPath
            DestinationPath = $item.DestinationPath
            Status = $status
            Verified = $verified
            Message = $message
        }
    )

    $symbol = '[!!]'
    if ($status -in @('MIGRATED', 'ALREADY_MIGRATED', 'V2_ONLY')) {
        $symbol = '[OK]'
    }
    elseif ($status -in @('WHATIF', 'NOT_MIGRATED', 'NO_SOURCE')) {
        $symbol = '[--]'
    }

    Write-Host "$symbol $($item.Email) -> $status"
    if ($message) {
        Write-Host "     $message"
    }
}

$report | Export-Csv -LiteralPath $reportPath -NoTypeInformation -Encoding UTF8

Write-Host ''
Write-Host 'Report written to:'
Write-Host "  $reportPath"
Write-Host ''

$bad = @($report | Where-Object { $_.Status -in @('AMBIGUOUS', 'ERROR') })
$notMigrated = @($report | Where-Object { $_.Status -eq 'NOT_MIGRATED' })

if ($bad.Count -gt 0) {
    Write-Warning "$($bad.Count) user(s) require manual review. No ambiguous mapping was migrated."
    exit 2
}

if ($VerifyOnly -and $notMigrated.Count -gt 0) {
    Write-Warning "$($notMigrated.Count) user(s) still have a legacy folder without a V15 identity migration."
    exit 3
}

Write-Host 'Completed without migration errors.'
exit 0

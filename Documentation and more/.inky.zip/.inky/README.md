# Red Ink Knowledge Worker Foundation

This `.inky` package is a generic foundation for professional knowledge work in law firms, advisory teams, compliance functions, finance, operations, research, and other document- and evidence-heavy environments.

It is intentionally domain-neutral. Contract wording, legal examples, sample positions, schemas, and other examples are never treated as controlling instructions unless the user or an authoritative source explicitly makes them controlling.

## Package structure

- `Inky.md` — project-wide instructions for interactive Word and Outlook Local Chat/Agent runs, including tool routing, source grounding, context control, file finalization, and sub-agent delegation.
- `Inky_for_AutoPilot.md` — unattended AutoPilot variant with stricter assumptions, delegation, context-budget, and file-output rules.
- `Red_Ink_Tool_List.md` — reference list of Red Ink tools/capabilities. Actual availability in a run is determined by the advertised runtime tool surface.
- `PATTERN_LIBRARY.md` — overview of the included sample/reference skills, playbooks, intake schemas, and isolated agents, including the source-first authoring model.
- `skills/` — reusable user-facing workflows that orchestrate tools and isolated agents.
- `agents/` — bounded isolated workers that keep raw document/research output out of the parent context.
- `designs/` — approved Office design carriers and human-readable design guidance. Standalone PowerPoint `.potx`/`.pptx` files can be discovered without editing JSON.

## Core architecture

The top-level agent should remain an orchestrator: understand the user's goal, select the smallest suitable workflow, make decisions, perform required user-facing actions, and synthesize the final result.

When the runtime advertises `resolve_capability_route`, capability routing is a host-enforced first phase: compare only advertised skill/agent metadata, prefer a specifically matching workflow skill over top-level agents and ordinary tools, otherwise choose a suitable top-level agent, otherwise resolve `none`. Skill and agent bodies remain lazy. After a route is selected, that capability must be entered before unrelated substantive tooling; a selected skill then governs its own permitted tools, sources, and delegated agents.

Large or source-heavy work should be reduced before it reaches the parent context:

1. Pass stable file/attachment/workspace/source references to an isolated agent when possible.
2. For large documents, use `shared_large_document_analyzer` to return only relevant findings, anchors, coverage, and unresolved questions.
3. Research only concrete unresolved questions with `shared_bounded_researcher`; stop when evidence is sufficient.
4. Use requirement, comparison, extraction, table-row, evidence-verification, and advisor agents only for bounded tasks.
5. Keep raw source dumps, broad search results, and long tool transcripts out of the parent context.
6. For bounded Word mutations, use `shared_document_editor`; when a Word file must be returned, it finalizes the actual `.docx` with `word_save_as` after all mutations.

## Skills

- `skill-author` — interactive Word/Outlook Local Chat infrastructure for creating, revising, reviewing, converting, diagnosing, and explaining how to author Red Ink skills, agents, and recipe-backed resource packages. It carries the foundation-wide context-safety, deliverable/finality, retry, and review-authorship contracts and may use the isolated `advisor` as a second pass for consequential architecture decisions. It is included in the package but is not executable in Outlook AutoPilot.
- `guided-case-assessment` — runs one administrator-configured case assessment/checklist from its internal registry, including configured workflows such as the included Swiss AML adviser assessment; once selected, its configured intake/checklist/source policy governs the assessment before unrelated research.
- `large-document-review` — review one large source context-safely.
- `complex-research-playbook` — bounded research and synthesis.
- `playbook-review` — review a source against caller-provided criteria or one/more configured playbooks; the included reference library demonstrates DPA, NDA, general-contract, and SaaS/customer reviews.
- `document-comparison` — compare two documents or versions for a defined objective.
- `document-set-table-builder` — build structured tables from collections of sources.
- `structured-intake` — collect and normalize source-grounded facts; the included reference library demonstrates a privacy-notice facts intake without turning intake into a legal/compliance decision.
- `form-filler` — complete existing Word/Excel forms from evidence.
- `decision-brief` — produce an evidence-grounded recommendation with alternatives and risks.
- `text-statistics` — deterministic JavaScript example for words, paragraphs, characters, and reliable page counts when page information is available.


## Included pattern/reference library

The foundation includes deliberately small examples showing how reusable reference packages should be
structured. See `PATTERN_LIBRARY.md` for the complete overview.

- `guided-case-assessment/references/assessments/swiss-aml-berater/` demonstrates a source-first
  deterministic assessment with human-readable requirements, derived JSON, expert review and a fixed
  professional Word output.
- `playbook-review/references/playbooks/` contains four configured review examples and supports
  multi-playbook review while preserving criterion provenance.
- `structured-intake/references/schemas/privacy-notice-intake/` demonstrates reusable fact collection
  for a privacy notice without deciding substantive legal sufficiency.
- `skill-author/references/authoring_recipes.json` is the generic extension registry for resource-specific
  authoring conventions. The core skill-author remains agnostic; recipes describe how a particular
  reference family is created, synchronized, validated and explained to users.
- `designs/powerpoint/` demonstrates the user-friendly PowerPoint design convention: a standalone
  `.potx`/`.pptx` carrier plus an optional same-basename natural-language `.md` guide. The included
  VISCHER and fictional Northstar samples show both guided and sample-slide-assisted layout discovery.

Subject-matter experts should normally work with the human-readable source files. The JSON files are
implementation artifacts generated/synchronized by Red Ink. Maintainer-only HTML comments in samples
may contain distribution disclaimers; runtime skills must not expose them in ordinary interaction.


### Office design resources

For PowerPoint, ordinary users do not need to edit `designs.json`. Place an approved `.potx` or
`.pptx` in `designs/powerpoint/`; optionally add a same-basename Markdown file explaining in natural
language when its actual custom layouts should be used. Without guidance, the host inspects the real
masters/layouts/placeholders/sample slides and may use one bounded LLM mapping step. It does not rely
on numeric layout positions or organization-specific hard-coded heuristics. See `designs/README.md`.

### Orchestrator compatibility conventions

- Skills may use `ask_user` only when it is actually advertised and the run is interactive. Outlook AutoPilot must return/send the necessary clarification instead of calling `ask_user`.
- Sub-agents never ask the end user. The parent orchestrator/skill owns clarification and passes a bounded task.
- Every `agent_<name>` call must include a stable `subagent_task_id` and `expected_artifacts`; analysis-only calls use an empty artifact list.
- Agent frontmatter distinguishes hard `allowed-tools` dependencies from opportunistic `optional-tools`. Missing optional tools must not block an otherwise runnable agent.
- `python_execute` is installation-dependent and must not be assumed by skills or agents as a standard capability.

## Agents

- `advisor` — independent second-pass reasoning without research.
- `shared_large_document_analyzer` — reduce one large source to relevant findings and anchors.
- `shared_bounded_researcher` — answer one focused research question in an isolated context, with a strict research budget and explicit evidence/source links.
- `shared_case_criterion_checker` — evaluate exactly one configured case-assessment criterion against supplied facts/reference excerpts.
- `shared_document_requirement_checker` — assess one criterion against one source.
- `shared_document_comparator` — compare two sources for one bounded objective.
- `shared_document_table_row_worker` — extract one caller-defined row from one source.
- `shared_structured_extractor` — extract caller-defined fields with provenance.
- `shared_evidence_verifier` — verify a bounded set of claims against evidence.
- `shared_document_editor` — apply bounded Word comments/edits with exact-anchor recovery, retry limits, and a final `word_save_as` step.

## Operating principles

- Source before inference. Never fabricate missing facts.
- Use the strongest relevant source and preserve traceable anchors when correctness matters.
- Stop research when additional retrieval is unlikely to materially change the answer.
- Treat large documents as a context-management problem before analysis begins.
- Prefer isolated agents for bounded heavy phases, even when no skill is used.
- Do not pre-extract a large document into the parent merely to pass it to an agent.
- Keep skills generic and treat examples as examples.
- Use specialized artifact/action tools when the requested deliverable requires them.
- A path in prose, JSON, or a plan is not proof that a requested file was produced.
- For file-required tasks, actually create/save/export the real final file in the host-provided working/session/staging location before returning `complete`.
- For returned Word files, use `word_save_as` after the last mutation as the normal finalizing step.
- Do not claim attachment, sending, delivery, registration, or receipt unless the host explicitly confirms it. The host/orchestrator owns artifact validation and Outlook attachment delivery.
- If a requested file cannot genuinely be produced, return `blocked`, not a soft `complete`.
- Do not loop on failed Word anchors: refresh current text, retry narrowly at most twice, then report the unresolved operation.
- For newly created comments, tracked changes, markup, and comparable review metadata, default the review author/reviewer identity to `Inky` unless the user explicitly specifies another name. Preserve pre-existing authorship.

## Host deliverable contract

The prompt layer and the host layer have deliberately separate responsibilities.

- Agents and skills create or finalize a real file in the host-provided session/working/staging area and return the actual path/reference from the successful file-producing tool call.
- The host maintains the structured `RegisteredDeliverableArtifacts` state. Its relevant finality field is `IsFinalDeliverable`; delivery scheduling is not a model-visible registry state.
- Agents and skills must not invent, set, or gate on `IsFinalDeliverable` themselves. They produce the real file; the host decides whether the tool result is promoted into the final-deliverable registry state.
- In Outlook AutoPilot, final deliverables are currently promoted by the host into `_chatAgentForcedDeliverables`; `CollectResultAttachments` consumes that bridge when assembling reply attachments. This is a host implementation detail, not an agent responsibility.
- In Word, output collection follows the separate `WordCollectAndCopyOutputs` staging flow. Word does not require the Outlook forced-delivery bridge.
- A future host cleanup may let Outlook consume `RegisteredDeliverableArtifacts` directly. Prompt guidance must not depend on whether that bridge exists.

The invariant for prompts is therefore simple: **produce the actual final file; never simulate registry or delivery state.**

## Runtime note

`Red_Ink_Tool_List.md` describes the broader capability catalogue. A specific Word, Outlook Local Chat, or AutoPilot run may expose only a subset. The advertised tool surface for the current run is authoritative.

## File-output invariant

The prompt layer is responsible for causing a real final file to be created or saved. The host layer is responsible for validating eligible artifacts, enforcing any host-side completion gate, and attaching/delivering Outlook files. Do not simulate host state in prompts or agent JSON.


## Hard edit circuit breaker

For non-trivial Word mutation, route the edit phase through `shared_document_editor`. A logical edit/comment gets one initial attempt and at most two recovery attempts. After that it is unresolved for the run; neither the editor nor the parent may reopen the same anchor. This prevents tool-hint-driven retry loops and context blow-ups.

### AutoPilot conversation-file continuity

Conversation-file retention across AutoPilot messages is controlled by the host/system configuration, not by Inky prompt rules. Files surfaced with `[RETAINED FROM EARLIER MESSAGE IN THIS CONVERSATION]` remain valid conversation inputs and must not be suppressed merely because they originated in an earlier message. Disabling retention belongs in host configuration rather than `Inky.md` / `Inky_for_AutoPilot.md`.

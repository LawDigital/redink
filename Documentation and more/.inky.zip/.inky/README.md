# Red Ink Knowledge Worker Foundation

This `.inky` package is a generic foundation for professional knowledge work in law firms, advisory teams, compliance functions, finance, operations, research, and other document- and evidence-heavy environments.

It is intentionally domain-neutral. Contract wording, legal examples, sample positions, schemas, and other examples are never treated as controlling instructions unless the user or an authoritative source explicitly makes them controlling.

## Package structure

- `Inky.md` — project-wide instructions for interactive Word and Outlook Local Chat/Agent runs, including tool routing, source grounding, context control, file finalization, and sub-agent delegation.
- `Inky_for_AutoPilot.md` — unattended AutoPilot variant with stricter assumptions, delegation, context-budget, and file-output rules.
- `Red_Ink_Tool_List.md` — reference list of Red Ink tools/capabilities. Actual availability in a run is determined by the advertised runtime tool surface.
- `skills/` — reusable user-facing workflows that orchestrate tools and isolated agents.
- `agents/` — bounded isolated workers that keep raw document/research output out of the parent context.

## Core architecture

The top-level agent should remain an orchestrator: understand the user's goal, select the smallest suitable workflow, make decisions, perform required user-facing actions, and synthesize the final result.

Large or source-heavy work should be reduced before it reaches the parent context:

1. Pass stable file/attachment/workspace/source references to an isolated agent when possible.
2. For large documents, use `shared_large_document_analyzer` to return only relevant findings, anchors, coverage, and unresolved questions.
3. Research only concrete unresolved questions with `shared_bounded_researcher`; stop when evidence is sufficient.
4. Use requirement, comparison, extraction, table-row, evidence-verification, and advisor agents only for bounded tasks.
5. Keep raw source dumps, broad search results, and long tool transcripts out of the parent context.
6. For bounded Word mutations, use `shared_document_editor`; when a Word file must be returned, it finalizes the actual `.docx` with `word_save_as` after all mutations.

## Skills

- `skill-author` — interactive Word/Outlook Local Chat infrastructure for creating, revising, reviewing, converting, and diagnosing Red Ink skills and agents. It carries the foundation-wide context-safety, deliverable/finality, retry, and review-authorship contracts and may use the isolated `advisor` as a second pass for consequential architecture decisions. It is included in the package but is not executable in Outlook AutoPilot.
- `large-document-review` — review one large source context-safely.
- `complex-research-playbook` — bounded research and synthesis.
- `playbook-review` — review a source against caller-provided criteria.
- `document-comparison` — compare two documents or versions for a defined objective.
- `document-set-table-builder` — build structured tables from collections of sources.
- `structured-intake` — collect and normalize source-grounded facts.
- `form-filler` — complete existing Word/Excel forms from evidence.
- `decision-brief` — produce an evidence-grounded recommendation with alternatives and risks.
- `text-statistics` — deterministic JavaScript example for words, paragraphs, characters, and reliable page counts when page information is available.

## Agents

- `advisor` — independent second-pass reasoning without research.
- `shared_large_document_analyzer` — reduce one large source to relevant findings and anchors.
- `shared_bounded_researcher` — answer one focused research question with a strict research budget.
- `shared_document_requirement_checker` — assess one criterion against one source.
- `shared_document_comparator` — compare two sources for one bounded objective.
- `shared_document_table_row_worker` — extract one caller-defined row from one source.
- `shared_structured_extractor` — extract caller-defined fields with provenance.
- `shared_evidence_verifier` — verify a bounded set of claims against evidence.
- `shared_document_editor` — apply bounded Word comments/edits with exact-anchor recovery, retry limits, and a final `word_save_as` step.

## Operating principles

- Source before inference. Never fabricate missing facts.
- Use the strongest relevant source and preserve traceable anchors when correctness matters.
- Stop research when additional retrieval is unlikely to materially change the answer.
- Treat large documents as a context-management problem before analysis begins.
- Prefer isolated agents for bounded heavy phases, even when no skill is used.
- Do not pre-extract a large document into the parent merely to pass it to an agent.
- Keep skills generic and treat examples as examples.
- Use specialized artifact/action tools when the requested deliverable requires them.
- A path in prose, JSON, or a plan is not proof that a requested file was produced.
- For file-required tasks, actually create/save/export the real final file in the host-provided working/session/staging location before returning `complete`.
- For returned Word files, use `word_save_as` after the last mutation as the normal finalizing step.
- Do not claim attachment, sending, delivery, registration, or receipt unless the host explicitly confirms it. The host/orchestrator owns artifact validation and Outlook attachment delivery.
- If a requested file cannot genuinely be produced, return `blocked`, not a soft `complete`.
- Do not loop on failed Word anchors: refresh current text, retry narrowly at most twice, then report the unresolved operation.
- For newly created comments, tracked changes, markup, and comparable review metadata, default the review author/reviewer identity to `Inky` unless the user explicitly specifies another name. Preserve pre-existing authorship.

## Host deliverable contract

The prompt layer and the host layer have deliberately separate responsibilities.

- Agents and skills create or finalize a real file in the host-provided session/working/staging area and return the actual path/reference from the successful file-producing tool call.
- The host maintains the structured `RegisteredDeliverableArtifacts` state. Its relevant finality field is `IsFinalDeliverable`; delivery scheduling is not a model-visible registry state.
- Agents and skills must not invent, set, or gate on `IsFinalDeliverable` themselves. They produce the real file; the host decides whether the tool result is promoted into the final-deliverable registry state.
- In Outlook AutoPilot, final deliverables are currently promoted by the host into `_chatAgentForcedDeliverables`; `CollectResultAttachments` consumes that bridge when assembling reply attachments. This is a host implementation detail, not an agent responsibility.
- In Word, output collection follows the separate `WordCollectAndCopyOutputs` staging flow. Word does not require the Outlook forced-delivery bridge.
- A future host cleanup may let Outlook consume `RegisteredDeliverableArtifacts` directly. Prompt guidance must not depend on whether that bridge exists.

The invariant for prompts is therefore simple: **produce the actual final file; never simulate registry or delivery state.**

## Runtime note

`Red_Ink_Tool_List.md` describes the broader capability catalogue. A specific Word, Outlook Local Chat, or AutoPilot run may expose only a subset. The advertised tool surface for the current run is authoritative.

## File-output invariant

The prompt layer is responsible for causing a real final file to be created or saved. The host layer is responsible for validating eligible artifacts, enforcing any host-side completion gate, and attaching/delivering Outlook files. Do not simulate host state in prompts or agent JSON.


## Hard edit circuit breaker

For non-trivial Word mutation, route the edit phase through `shared_document_editor`. A logical edit/comment gets one initial attempt and at most two recovery attempts. After that it is unresolved for the run; neither the editor nor the parent may reopen the same anchor. This prevents tool-hint-driven retry loops and context blow-ups.

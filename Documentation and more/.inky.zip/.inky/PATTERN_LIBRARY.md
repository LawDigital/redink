# Red Ink Pattern Library — Skills, Reference Packages, Designs, and Agents

This resource set combines a generic knowledge-worker foundation with deliberately included **reference patterns**. Patterns are not automatically controlling legal, compliance, or negotiation standards. They demonstrate how human-readable expert rules, technical implementation, and isolated agents work together.

## 1. Reference libraries

| Skill | Pattern | Purpose |
| --- | --- | --- |
| `guided-case-assessment` | `swiss-aml-berater` | Multi-step deterministic case assessment with a human-readable substantive master, derived JSON, expert review, and fixed professional Word report. |
| `playbook-review` | `dpa-customer` | DPA review from the customer/controller perspective. |
| `playbook-review` | `nda-balanced` | Balanced NDA/confidentiality review. |
| `playbook-review` | `general-contract-quick-review` | Small general commercial contract quick check. |
| `playbook-review` | `saas-customer` | SaaS/cloud agreement review from the customer perspective. |
| `structured-intake` | `privacy-notice-intake` | Fact intake for preparing/updating a privacy notice without deciding substantive legal sufficiency. |

## 2. Office design samples

| Design sample | Files | Purpose |
| --- | --- | --- |
| VISCHER reduced presentation | `designs/powerpoint/VISCHER_Reduced_Presentation.potx` + same-basename `.md` | Demonstrates a real multi-layout corporate carrier with human-readable layout guidance. |
| Northstar Advisory (fictional) | `designs/powerpoint/Northstar_Advisory_Sample.pptx` + same-basename `.md` | Neutral blue consulting-style example with cover, content, two-column, visual-canvas and closing layouts plus illustrative sample slides. |
| VISCHER memo | `designs/word/VISCHER_Memo_English.dotx` + same-basename `.md` | Demonstrates deterministic speaking slots plus an exact native body-style contract (four heading levels, three bullet levels, ordinary paragraphs via `Randziffern`). |

The PowerPoint design mechanism is deliberately agnostic. The carrier itself provides the actual
master/layout graph; the optional Markdown explains organization-specific intent. If the Markdown is
absent or incomplete, the host can inspect the real placeholder geometry/types and sample slides and
use one bounded LLM layout-interpretation call. It does not use fixed layout numbers or brand-specific
hard-coded heuristics.

`designs/powerpoint/DESIGN_GUIDANCE_TEMPLATE.md` is a copy/edit starting point. Standalone PowerPoint
carriers do not require `designs.json`.

For structured Word templates, `designs/word/WORD_DESIGN_GUIDANCE_TEMPLATE.md` demonstrates the
parallel same-basename companion convention. `[[RI:SlotName]]` is only a unique visible marker; the
slot mapping list supplies location/value semantics, while an optional `## Word body styles` list maps
neutral Markdown block semantics to exact native Word paragraph styles. These Word companion contracts
use editable list/property syntax; older Markdown tables are accepted only as backward-compatible input.
Names such as `Text`, `Body`, or `MainText` remain template-specific rather than becoming global aliases
in code.

## 3. Reusable workflow skills

- `skill-author` — creates, synchronizes, reviews, and explains skills, agents, and recipe-backed resource packages, including human-readable Office design guidance. Resource-specific authoring conventions are recipes under `skills/skill-author/references/`.
- `guided-case-assessment` — runs exactly one configured assessment package.
- `playbook-review` — reviews against caller-provided or one/more configured playbooks.
- `structured-intake` — collects and normalizes facts without making a substantive assessment decision.
- `large-document-review` — reduces and reviews large sources context-safely.
- `document-comparison` — compares two sources/versions.
- `document-set-table-builder` — builds structured tables from multiple sources.
- `form-filler` — completes existing Word/Excel forms from evidence.
- `decision-brief` — creates a compact decision-oriented brief.
- `complex-research-playbook` — orchestrates bounded research.
- `text-statistics` — deterministic script-backed statistics example.

## 4. Isolated agents

- `advisor` — independent second pass for difficult decisions.
- `shared_bounded_researcher` — one bounded research question, used only for multi-question delegation, material context preservation, or explicit request; required to return evidence with source links whenever available.
- `shared_case_criterion_checker` — one assessment criterion against structured facts.
- `shared_document_requirement_checker` — one playbook/document criterion.
- `shared_document_comparator` — bounded two-source comparison.
- `shared_document_editor` — bounded Word mutations/comments with recovery and finalization.
- `shared_document_table_row_worker` — one structured table row from one source.
- `shared_evidence_verifier` — verifies a bounded set of claims against evidence.
- `shared_large_document_analyzer` — reduces one large source to relevant findings/anchors.
- `shared_structured_extractor` — extracts a caller-defined fact schema with provenance.

## 5. Authoring principle

For reference libraries, prefer:

```text
Subject-matter expert / Word / Markdown
        ↓
human-readable master source
        ↓
skill-author recipe
        ↓
technical JSON / registry artifacts
        ↓
validation / human-readable review mirror
```

Subject-matter experts should normally neither write nor understand JSON.

A useful Red Ink request is:

> Explain which copy/paste prompt and which source file I should give Red Ink to create or update this reference pattern. Do not modify anything yet.

`skill-author` should then load the matching recipe and explain the simplest Red Ink workflow.

## 6. Pattern disclaimers

Maintainer-only HTML comments in reference patterns may contain distribution/sample disclaimers. Runtime skills must preserve those comments as maintainer metadata but must not surface them in ordinary questions, results, reviews, reports, or document edits.

## 7. Runtime/orchestrator conventions

- The parent Word/Outlook orchestrator owns end-user clarification. Skills may use `ask_user` only when that tool is actually advertised and the run is interactive. AutoPilot must never depend on it.
- Sub-agents never ask the end user. Parent skills pass complete bounded tasks and required context.
- Every sub-agent call must provide `subagent_task_id` and `expected_artifacts`; use an empty artifact list for analysis-only workers.
- Agent `allowed-tools` are hard dependencies. `optional-tools` are opportunistic capabilities included only when the current host exposes them.
- `python_execute` is not a guaranteed foundation capability. Patterns must not require Python unless a future resource explicitly targets an environment where the Python helper is guaranteed. Prefer guaranteed host tools and deterministic native/script paths.

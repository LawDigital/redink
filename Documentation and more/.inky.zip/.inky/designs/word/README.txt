Place approved .dotx/.dotm templates here. A clean .dotx is recommended.
A .docx may be used as template_file, but its body is cleared before content is generated.

Place approved .xltx workbook templates here. Ordinary .xlsx files should be referenced as theme_source_file instead.
Original .xltx worksheets are removed from generated output; workbook-level theme/named styles remain available.

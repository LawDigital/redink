# Office Design Repository

This folder lets Red Ink use approved Office design carriers without relying on model knowledge about
a brand. The simplest PowerPoint workflow is intentionally human-friendly and does **not** require
JSON.

## PowerPoint — simplest setup

Place an approved `.potx` or `.pptx` directly in:

```text
designs/powerpoint/
```

For example:

```text
designs/powerpoint/My_Organization_Template.potx
```

Red Ink discovers the file as a named PowerPoint design automatically. The filename becomes the
design name/id (punctuation and spaces are handled by the normal design lookup).

### Optional natural-language guidance

When the template needs explanation, add a Markdown file with the same base name:

```text
designs/powerpoint/My_Organization_Template.potx
designs/powerpoint/My_Organization_Template.md
```

Write the Markdown in ordinary language. Explain what the template is for and when its exact
PowerPoint custom layouts should be used. There is no required JSON schema for this guidance.

See `powerpoint/README.txt` for the short operational rules and `powerpoint/DESIGN_GUIDANCE_TEMPLATE.md` for a copy/edit starting point. The two files have different jobs: README explains the folder/runtime; the template is only an authoring starter.

### When no Markdown guidance exists

Red Ink does not guess from layout numbers or hard-coded brand conventions. It inspects the actual
PowerPoint design carrier, including:

- every slide master and custom-layout name;
- the actual placeholder types and geometry;
- sample-slide text when a `.pptx` contains illustrative sample slides.

The host may use one bounded LLM interpretation call to map requested slide content to exact layouts
from that inspected template. If there is no safe match, Red Ink should use a neutral readable
fallback rather than force an unsuitable layout or lose content.

A `.pptx` can therefore be useful when a few deliberately prepared sample slides explain the design.
When a repository PPTX is used as a design carrier, its existing sample slides are removed by default
before the new deck is generated; the master/layout/theme structure remains.

## Included examples

Brand-specific examples can live in complete design sets under `.inky/design_sets/<set>/designs/`.
The ordinary `.inky/designs` tree should stay brand-neutral when the package is intended for redistribution.

## Advanced/optional `designs.json`

`designs.json` remains available for administrators who need an explicit profile with aliases,
application-specific defaults, or a design that combines Word, PowerPoint and Excel carriers under
one stable id. It is **not required** for a standalone PowerPoint template.

An explicit enabled `designs.json` entry with the same id takes precedence over an automatically
discovered carrier at the same resource level. Local resources continue to override central resources.

Common advanced fields include application defaults such as fonts/colours and `template_file` or
`theme_source_file`. Do not ask ordinary users or subject-matter experts to edit this JSON merely to
install a PowerPoint template.

## Word — structured DOCX designs and shared style policies

For new Word designs, prefer a clean `.docx` carrier under `designs/word/`. DOCX is the recommended
carrier because it is an ordinary document package and avoids template-specific startup/attachment
behavior. Legacy `.dotx` carriers may remain supported where necessary; do not choose `.dotx` for a
new design when DOCX is sufficient.

For structured designs, use visible speaking placeholders in the exact form `[[RI:SlotName]]` and map
them under the companion heading `## Word template slots`. The slot id is only a locator; `source:` is
the deterministic binding and `purpose:` tells the model what belongs there. New and edited guides
use table-free property lists.

When several Word designs share one corporate style system, keep the formatting contract in one
shared Markdown style policy rather than copying it into every template guide. Reference it from the
Word entry in `designs.json` with `style_policy_file`. The shared file may contain `## Word body styles`
for renderer-active Markdown semantics and `## Word native styles` for a validated organization-wide
style inventory. Design-specific companion files should then contain only slots and genuinely local
behavior.

The Word design catalog can also declare routing metadata such as `document_type`, `language`,
`organization`, `default_for`, and one `is_default` Word design. The model routes first by an explicitly user-requested design. Otherwise document type is the primary routing key; language and organization are considered only among matching document-type candidates, followed by the applicable configured
default. Language is part of the format match. In interactive mode, ask only if the format is truly
ambiguous and no applicable default exists; unattended AutoPilot never waits for a clarification.

See `word/README.txt` for the complete Word catalog/configuration reference and
`word/WORD_DESIGN_GUIDANCE_TEMPLATE.md` / `word/WORD_STYLE_POLICY_TEMPLATE.md` for copy/edit starters.

## Excel

Excel template carriers: `.xltx` under `designs/excel/`. Standalone carriers in the conventional
folder are discoverable. For more complex shared profiles, use `designs.json`.

## Precedence

For a named design, effective precedence is:

1. explicit user/tool-call parameters;
2. explicit advanced profile settings when present;
3. the approved Office carrier's native theme/master/layout/styles;
4. Red Ink neutral professional fallback.

For PowerPoint layout selection specifically, an exact per-slide/configured layout assignment wins;
otherwise natural-language guidance plus actual template metadata/sample slides is interpreted. No
numeric layout index or fixed organization-specific naming heuristic is controlling.

## Recommended production workflow

1. Put the approved PowerPoint `.potx`/`.pptx` in `designs/powerpoint/`.
2. Add a same-basename `.md` only where layout usage is not self-evident.
3. Keep the guide short, concrete and written for humans. Record typography invariants and a preferred neutral visual canvas when these are important.
4. Test a representative deck containing opening, normal content with multiple indentation levels, two-column content, editable visual/data slides and a closing slide.
5. Check that body text retains the carrier's native font/size hierarchy and that dense content is split rather than arbitrarily shrunk.
6. Update the guide when the approved template changes materially.

The design owner should review both the carrier and its guidance. The runtime should never invent a
brand-specific rule that is not present in the approved carrier/guidance or explicitly supplied by the user.

## Word design selection and file loading

`designs.json` is the normal control plane. A Word entry points to `template_file`, optional
`guidance_file`, and optional shared `style_policy_file`. Paths are relative to `designs/`. Only the
selected design's referenced files are used to build its Word contract. If `guidance_file` is omitted,
the selected carrier may use a same-basename `.md` companion for compatibility; shared style policies
never use filename guessing and must be referenced explicitly. Standalone Office carriers are also
discoverable as legacy loose designs; an explicit catalog entry with the same id wins. Local repository
entries override central entries with the same stable id. A failed structured design remains binding on
retry and must not silently fall back to another design.

Keep global agent instructions organization-neutral. Organization-specific names, routing metadata,
slots and style policies belong under `designs/` and in the catalog.


## Switching complete design sets

For installations that need two or more mutually exclusive design repositories, place each complete
`designs` tree below `.inky/design_sets/<set>/designs/` and select it in `.inky/design_sets/active.json`.
The selection applies to Word, PowerPoint and Excel because all three applications resolve from the same
selected design root. Only the selected tree is exposed. This makes switching deterministic without editing
global instructions. For a single-brand distribution, delete the other set and keep only the selected set in
`active.json`. If the selector is missing or invalid, the ordinary `.inky/designs` tree is the fallback and
should therefore remain brand-neutral.

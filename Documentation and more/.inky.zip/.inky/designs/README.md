# Office Design Repository

This folder lets Red Ink use approved Office design carriers without relying on model knowledge about
a brand. The simplest PowerPoint workflow is intentionally human-friendly and does **not** require
JSON.

## PowerPoint — simplest setup

Place an approved `.potx` or `.pptx` directly in:

```text
designs/powerpoint/
```

For example:

```text
designs/powerpoint/My_Organization_Template.potx
```

Red Ink discovers the file as a named PowerPoint design automatically. The filename becomes the
design name/id (punctuation and spaces are handled by the normal design lookup).

### Optional natural-language guidance

When the template needs explanation, add a Markdown file with the same base name:

```text
designs/powerpoint/My_Organization_Template.potx
designs/powerpoint/My_Organization_Template.md
```

Write the Markdown in ordinary language. Explain what the template is for and when its exact
PowerPoint custom layouts should be used. There is no required JSON schema for this guidance.

See `powerpoint/README.txt` for the short operational rules and `powerpoint/DESIGN_GUIDANCE_TEMPLATE.md` for a copy/edit starting point. The two files have different jobs: README explains the folder/runtime; the template is only an authoring starter.

### When no Markdown guidance exists

Red Ink does not guess from layout numbers or hard-coded brand conventions. It inspects the actual
PowerPoint design carrier, including:

- every slide master and custom-layout name;
- the actual placeholder types and geometry;
- sample-slide text when a `.pptx` contains illustrative sample slides.

The host may use one bounded LLM interpretation call to map requested slide content to exact layouts
from that inspected template. If there is no safe match, Red Ink should use a neutral readable
fallback rather than force an unsuitable layout or lose content.

A `.pptx` can therefore be useful when a few deliberately prepared sample slides explain the design.
When a repository PPTX is used as a design carrier, its existing sample slides are removed by default
before the new deck is generated; the master/layout/theme structure remains.

## Included examples

- `powerpoint/VISCHER_Reduced_Presentation.potx` plus
  `VISCHER_Reduced_Presentation.md` demonstrates a real multi-layout corporate template with
  template-specific human guidance.
- `powerpoint/Northstar_Advisory_Sample.pptx` plus
  `Northstar_Advisory_Sample.md` is a fictional neutral example with five purpose-built named layouts (cover, content, two-column, visual canvas and closing) plus illustrative sample slides.

These examples demonstrate the mechanism; they do not create Red Ink-wide assumptions about layout
names or organizations.

## Advanced/optional `designs.json`

`designs.json` remains available for administrators who need an explicit profile with aliases,
application-specific defaults, or a design that combines Word, PowerPoint and Excel carriers under
one stable id. It is **not required** for a standalone PowerPoint template.

An explicit enabled `designs.json` entry with the same id takes precedence over an automatically
discovered carrier at the same resource level. Local resources continue to override central resources.

Common advanced fields include application defaults such as fonts/colours and `template_file` or
`theme_source_file`. Do not ask ordinary users or subject-matter experts to edit this JSON merely to
install a PowerPoint template.

## Word and Excel

The existing advanced repository model remains supported:

- Word design carriers: `.dotx`, `.dotm`, or approved `.docx` under `designs/word/`.
- Excel template carriers: `.xltx` under `designs/excel/`.

Standalone carriers in these conventional folders are also discoverable. For more complex shared
profiles, use `designs.json`.

## Precedence

For a named design, effective precedence is:

1. explicit user/tool-call parameters;
2. explicit advanced profile settings when present;
3. the approved Office carrier's native theme/master/layout/styles;
4. Red Ink neutral professional fallback.

For PowerPoint layout selection specifically, an exact per-slide/configured layout assignment wins;
otherwise natural-language guidance plus actual template metadata/sample slides is interpreted. No
numeric layout index or fixed organization-specific naming heuristic is controlling.

## Recommended production workflow

1. Put the approved PowerPoint `.potx`/`.pptx` in `designs/powerpoint/`.
2. Add a same-basename `.md` only where layout usage is not self-evident.
3. Keep the guide short, concrete and written for humans. Record typography invariants and a preferred neutral visual canvas when these are important.
4. Test a representative deck containing opening, normal content with multiple indentation levels, two-column content, editable visual/data slides and a closing slide.
5. Check that body text retains the carrier's native font/size hierarchy and that dense content is split rather than arbitrarily shrunk.
6. Update the guide when the approved template changes materially.

The design owner should review both the carrier and its guidance. The runtime should never invent a
brand-specific rule that is not present in the approved carrier/guidance or explicitly supplied by the user.

---
name: form-filler
description: Completes an existing Word or Excel form from supplied facts and source documents while preserving structure, provenance, and unresolved fields.
allowed-tools:
  - ask_user
  - list_attachments
  - read_attachment
  - read_word_document_details
  - excel_list_live_worksheets
  - excel_read_live_range
  - excel_complete_live_workbook
  - complete_word_tables
  - agent_shared_structured_extractor
  - agent_shared_large_document_analyzer
  - word_save_as
  - report_inability
model: agentdefaultmodel
---

# Form Filler

Complete an existing Word or Excel form. Preserve the original structure unless the user explicitly requests redesign.

## Architecture
1. Identify and inspect the target form before writing.
2. Identify fields, types, instructions, dependencies, and open/incomplete items.
3. For supporting sources, use `agent_shared_structured_extractor`; for very large supporting documents use `agent_shared_large_document_analyzer` rather than loading them fully in the parent.
4. Merge supplied facts and extracted facts, preserving provenance and conflicts.
5. Fill all fields supported by the evidence. Leave genuinely unsupported required fields explicit rather than fabricating values.
6. Use the appropriate Word/Excel completion tool.
7. For a Word file that must be returned, run `word_save_as` **after** the final table/form mutation and use the actual saved path returned by that call as the final file.
8. For Excel, require the completion tool itself to produce/save the real resulting workbook in the host-provided working/session location; do not substitute a planned path or text summary.
9. If the requested final file cannot be genuinely saved, return `blocked` rather than `complete`.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

## Rules
- Template examples, placeholder text, and sample answers are never user facts.
- Distinguish stated facts, deterministic derivations, assumptions authorized by the user, and missing values.
- Do not invent professional judgments merely because a field exists; complete evaluative fields only when the user requested such evaluation and the available facts support it.
- Do not overwrite the original unless explicitly requested or the tool guarantees safe preservation.
- Produce one clearly identified final file in the host-provided session/working/staging location.
- A path in prose or intermediate tool JSON is not proof of the final file.
- Do not claim that the file was attached, sent, or delivered unless the host explicitly confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


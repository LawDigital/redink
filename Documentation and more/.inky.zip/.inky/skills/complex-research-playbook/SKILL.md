---
name: complex-research-playbook
description: Orchestrates multi-question, source-grounded research while keeping raw retrieval outside the parent context.
allowed-tools:
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - context_compact
  - js_run
  - create_word_document
  - create_pdf_from_text
model: agentdefaultmodel
---

# Complex Research Playbook

Use only when the task genuinely contains multiple separable research questions or source streams.

## Architecture
1. Define the user's actual decision or deliverable.
2. Split the task into the smallest useful set of bounded questions; normally 2-6.
3. Delegate each question to `agent_shared_bounded_researcher`.
4. Keep only compact agent results in the parent context; never repeat the research in the parent.
5. Reconcile overlaps and conflicts, then synthesize.
6. For high-stakes output or uncertain claim support, verify the final bounded claims with `agent_shared_evidence_verifier`.

## Stop rules
- Do not create questions for merely conceivable subtopics.
- Cancel a pending question if another result already resolves it.
- Stop when remaining uncertainty would not materially change the answer.
- Separate sourced facts, inference, assumptions, and recommendations.

## Output
Return a concise synthesis with the answer, key findings, source anchors, material conflicts, limitations, and next steps only when useful. Create a file only when requested or required by the workflow.

When a Word/PDF deliverable is requested, the last substantive file action must be the successful `create_word_document` or `create_pdf_from_text` call in the host-provided working/session location. Use its actual output path. Do not return `complete` for a requested file if creation failed or never occurred, and do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


---
name: complex-research-playbook
description: Performs structured multi-question research in Word and Outlook using web, local knowledge, Microsoft 365, and provided context.
allowed-tools:
  - internet_search
  - retrieve_web_content
  - web_grounding
  - selected_online_sources
  - knowledge_search
  - m365_search
  - m365_get_mail
  - m365_get_mail_thread
  - m365_get_file
  - m365_get_event
  - m365_get_chat_thread
  - m365_get_onenote_page
  - text_read
  - text_search
  - text_write
  - workspace_write
  - agent_workspace_write
  - js_run
  - skill_use
model: researchmodel
network: true
---

# Complex Research Playbook

Use this skill for structured research memos, issue maps, comparisons, regulatory briefings, market-practice checks, and internal-precedent searches.

Works in Word and Outlook using shared research tools. Use host-specific write tools only for optional report output.

## Workflow

1. Restate the research objective and scope.
2. Break the question into 2-6 focused research questions.
3. Decide source policy:
   - web/current law/current market: `web_grounding`, `internet_search`, `retrieve_web_content`;
   - internal precedent: `knowledge_search`, `m365_search`, then relevant `m365_get_*` tools;
   - supplied text files: `text_read` or `text_search`.
4. Delegate focused questions to `shared_researcher` when useful.
5. Consolidate findings, evidence, uncertainties, and recommended next steps.
6. If requested, write a Markdown report using `workspace_write` in Word or `agent_workspace_write` in Outlook.

## Research rules

- Prefer primary, official, and current sources.
- Separate facts from assumptions and inferences.
- Include dates for current or changing information.
- Identify source gaps rather than filling them with guesses.
- Do not invent source names, citations, M365 items, or URLs.

## Output

Return:

- answer summary;
- key findings;
- evidence/source table;
- uncertainties and source gaps;
- optional next steps;
- optional created report path.

---
name: complex-research-playbook
description: Orchestrates multi-question, source-grounded research while keeping raw retrieval outside the parent context.
allowed-tools:
  - ask_user
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - context_compact
  - js_run
  - create_word_document
  - create_pdf_from_text
model: agentdefaultmodel
---

# Complex Research Playbook

Use only when the task genuinely contains multiple separable research questions or source streams.

## Architecture
1. Define the user's actual decision or deliverable.
2. Split the task into the smallest useful set of bounded questions; normally 2-6.
3. Delegate each question to `agent_shared_bounded_researcher`. Pass the permitted source scope explicitly. Preserve each researcher's complete `evidence` records, especially `citation_or_id`, pinpoint and `url`; never collapse them into uncited prose or strip source links.
4. Keep only compact agent results in the parent context; never repeat the research in the parent.
5. Reconcile overlaps and conflicts, then synthesize.
6. For high-stakes output or uncertain claim support, verify the final bounded claims with `agent_shared_evidence_verifier`.

## Stop rules
- Do not create questions for merely conceivable subtopics.
- Cancel a pending question if another result already resolves it.
- Stop when remaining uncertainty would not materially change the answer.
- Separate sourced facts, inference, assumptions, and recommendations.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

## Output
Return a concise synthesis with the answer, key findings, source anchors **and clickable/source URLs where provided by the researchers**, material conflicts, limitations, and next steps only when useful. Create a file only when requested or required by the workflow.

When a Word/PDF deliverable is requested, the last substantive file action must be the successful `create_word_document` or `create_pdf_from_text` call in the host-provided working/session location. Use its actual output path. Do not return `complete` for a requested file if creation failed or never occurred, and do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


---
name: document-comparison
description: Compares two documents or versions for a defined objective using an isolated comparator and returns only material, traceable differences and similarities.
allowed-tools:
  - agent_shared_document_comparator
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - create_word_document
  - agent_shared_document_editor
model: agentdefaultmodel
---

# Document Comparison

Use when the user needs a substantive comparison of two documents, versions, proposals, policies, specifications, reports, or other sources.

## Architecture
1. Define the comparison objective and material dimensions.
2. Pass both source references and the objective to `agent_shared_document_comparator`; do not pre-extract both full documents into the parent.
3. Synthesize material differences, similarities, additions/removals, and unresolved questions.
4. If a difference requires external context to assess significance, formulate a bounded question and use `agent_shared_bounded_researcher` only when the user requested or needs that external assessment.
5. Verify high-stakes sourced claims with `agent_shared_evidence_verifier` when needed.

## Rules
- Distinguish textual differences from substantive differences.
- Do not infer motive or intent for changes without evidence.
- Prefer topic/section comparison over line-by-line noise unless exact redline comparison was requested.

## Optional file outputs
- If the user requests a standalone comparison report file, create the actual final file with `create_word_document` in the host-provided working/session location; a proposed filename or prose summary is not enough.
- If the user asks to annotate or edit one of the compared Word documents, first produce a compact ordered mutation plan, then delegate only that plan and the target source reference to `agent_shared_document_editor`.
- For edited Word outputs, require the editor's real `final_file_path` from its successful `word_save_as` step before treating the file-producing portion as complete.
- Do not claim attachment or delivery; the host controls that stage.
- If the requested file cannot be created/finalized, return `blocked` for the file-producing request rather than `complete`.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


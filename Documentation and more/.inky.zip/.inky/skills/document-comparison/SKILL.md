---
name: document-comparison
description: Compares two documents or versions for a defined objective using an isolated comparator and returns only material, traceable differences and similarities.
allowed-tools:
  - ask_user
  - agent_shared_document_comparator
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - create_word_document
  - agent_shared_document_editor
model: agentdefaultmodel
---

# Document Comparison

Use when the user needs a substantive comparison of two documents, versions, proposals, policies, specifications, reports, or other sources.

## Architecture
1. Define the comparison objective and material dimensions.
2. Pass both source references and the objective to `agent_shared_document_comparator`; do not pre-extract both full documents into the parent.
3. Synthesize material differences, similarities, additions/removals, and unresolved questions.
4. If a difference requires external context to assess significance, formulate a bounded question and use `agent_shared_bounded_researcher` only when the user requested or needs that external assessment.
5. Verify high-stakes sourced claims with `agent_shared_evidence_verifier` when needed.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

## Rules
- Distinguish textual differences from substantive differences.
- Do not infer motive or intent for changes without evidence.
- Prefer topic/section comparison over line-by-line noise unless exact redline comparison was requested.

## Optional file outputs
- If the user requests a standalone comparison report file, create the actual final file with `create_word_document` in the host-provided working/session location; a proposed filename or prose summary is not enough.
- If the user asks to annotate or edit one of the compared Word documents, first produce a compact ordered mutation plan, then delegate only that plan and the target source reference to `agent_shared_document_editor`.
- For edited Word outputs, require the editor's real `final_file_path` from its successful `word_save_as` step before treating the file-producing portion as complete.
- Do not claim attachment or delivery; the host controls that stage.
- If the requested file cannot be created/finalized, return `blocked` for the file-producing request rather than `complete`.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


---
name: gdpr-privacy-notice-intake
description: Erhebt dialogisch, inkrementell und über mehrere Sitzungen hinweg alle für die Erstellung einer DSGVO-Datenschutzerklärung benötigten Tatsachen. Der Skill liest zu Beginn immer zuerst vorhandene Intake-Erkenntnisse aus dem Workspace ein, schreibt die Markdown-Intake-Datei laufend fort, stellt nur wenige gezielte Fragen pro Runde, hakt bei unvollständigen Antworten nach und behandelt jede nicht bestätigte Annahme nur als Vorschlag bzw. zu klärenden Punkt. Die Interviewlogik steht in diesem Skill; die materiellen Vorgaben liegen getrennt in References/gdpr-privacy-notice-intake-requirements.md.
allowed-tools:
  - text_read
  - text_search
  - workspace_get
  - workspace_inventory
  - workspace_read
  - workspace_write
  - agent_workspace_list
  - agent_workspace_find_files
  - agent_workspace_read
  - agent_workspace_write
  - js_run
  - skill_use
model: agentdefaultmodel
---

# GDPR Privacy Notice Intake

This skill collects, clarifies, validates, and records the factual inputs needed to prepare a GDPR privacy notice. It behaves like a professional fact-finding interviewer: it starts from existing notes, records confirmed facts, marks uncertainty explicitly, suggests plausible options only as options, asks small targeted follow-up questions, and keeps a durable Markdown intake file current across sessions.

Use the user's language. For German-speaking users, use German labels and questions.

The skill does **not** draft the final privacy notice unless the user separately asks for drafting after the intake file is sufficiently complete.

## Non-negotiable behaviour

These rules override every more general instruction in this skill.

1. **Always resume first.** At the start of every run, first search for an existing intake Markdown file in the top level of the current workspace and read it if found. Do this before asking substantive questions and before creating a duplicate file.
2. **No silent assumptions.** Never store an assumption, inference, default, common pattern, or model guess as a fact. Store it only as `Vorschlag – zu bestätigen` or `Unklar` and ask the user to confirm, correct, or reject it.
3. **Clarify until sufficiently answered.** If a material point is incomplete, vague, contradictory, or only partly answered, record the partial answer and ask a focused follow-up later or immediately, unless the user says they do not know or the point is confirmed as not applicable.
4. **Ask few questions.** Ask normally 1-2 questions per turn, 3 only when closely related, and never more than 4 unless the user explicitly asks for a full questionnaire.
5. **Write before asking more.** After every substantive user answer, update the complete Markdown intake file before asking the next question.
6. **Create early.** If no existing intake file is found, create a new top-level Markdown file as soon as the Reference file is available. The initial file must include known facts, open points, and any suggestions awaiting confirmation.
7. **Do not ask again for confirmed facts.** Extract and reuse facts from the current prompt, conversation, existing intake file, and retrieved sources. Ask only about missing, unclear, contradicted, or unconfirmed points.
8. **Do not abandon unresolved mandatory points.** Keep high-priority unresolved points in the file and return to them across sessions until answered, marked not applicable, or recorded as unknown by the user.
9. **Do not claim success without a write result.** Do not say that the Markdown file was created or updated unless the relevant write tool completed successfully.

## Critical path for every run

Follow this sequence exactly.

1. Load this skill.
2. Determine host/workspace capabilities.
3. Search the top level of the current workspace for existing intake Markdown files.
4. If exactly one relevant file is found, read it and reconstruct the current intake state.
5. If multiple relevant files are found, choose the most recently modified one if metadata clearly supports that choice. Otherwise ask one short file-selection question and do not create a duplicate.
6. Only after the continuation check, obtain the mandatory Reference file.
7. Merge any new facts from the user's latest message into the reconstructed state.
8. Mark every inferred but unconfirmed point as `Vorschlag – zu bestätigen`, not as `Erhoben`.
9. Write the complete updated Markdown file.
10. Ask the next small set of focused questions, prioritising unresolved mandatory points and unconfirmed suggestions.

If no existing file is found, steps 4 and 5 are skipped; after the Reference file is obtained, create a new top-level file immediately.

## Mandatory Reference file

Before asking substantive questions or deciding that the intake is complete, obtain the skill Reference file:

```text
skills/gdpr-privacy-notice-intake/References/gdpr-privacy-notice-intake-requirements.md
```

Rules for the Reference file:

- Use `text_read` for the Reference file.
- If the skill loader already supplied the Reference file content, use that content and do not reread it unnecessarily.
- If `text_read` on the canonical relative path returns `not_found`, do not retry the same failing call. Use the exact Reference path from the loaded skill inventory if available, or make one further `text_search`/`text_read` attempt only when the tool result provides a plausible actual path.
- Do not use `workspace_read` or `agent_workspace_read` for the Reference file.
- If the Reference file cannot be obtained, stop and report the inability. Do not invent the intake requirements.

## Workspace discovery and continuation

The output file is a **workspace artifact**, never a skill artifact. It must be stored in the **top level of the current user workspace** unless the user explicitly names a different workspace-relative path.

### Relevant filenames

Look for Markdown files matching one of these patterns:

- `privacy-notice-intake-*.md`
- `*datenschutzerklaerung*intake*.md`
- `*datenschutzerklärung*intake*.md`
- `*datenschutz*intake*.md`
- a filename explicitly mentioned by the user.

### Word host

1. Use `workspace_get` if available to confirm the workspace.
2. Use `workspace_inventory` at the workspace root to find relevant Markdown files.
3. Read an existing intake file with `workspace_read` only if the exact root-level filename/path was returned by `workspace_inventory` or explicitly named by the user.
4. If no relevant file is found, create a new top-level file with `workspace_write`.

### Outlook host

1. Use `agent_workspace_list` or `agent_workspace_find_files` to find relevant Markdown files in the agent workspace root.
2. Read an existing intake file with `agent_workspace_read` only if the exact path was returned by the listing/find tool or explicitly named by the user.
3. If no relevant file is found, create a new top-level file with `agent_workspace_write`.

### Anti-loop rules for file reads

- Never call `workspace_read` or `agent_workspace_read` on a guessed filename.
- Never read a default output filename merely because it might exist.
- Never repeat an identical failing read call.
- A missing output file is not an error; it means a new file must be created after the Reference file is available.
- If a found file cannot be read, report the read failure and ask whether to create a new file or retry with another identified file. Do not repeatedly try the failing path.

## Output path and file naming

Default filename pattern:

```text
privacy-notice-intake-YYYY-MM-DD-<controller-or-project-slug>.md
```

If the controller or project name is not confirmed yet, use:

```text
privacy-notice-intake-YYYY-MM-DD-draft.md
```

Default output filenames must be bare filenames only. They must not contain `/`, `\\`, `skills`, the skill name, `References`, `..`, a leading `.`, or any folder component. They must end with `.md`.

If a name would collide with an existing file and the existing file is not the selected continuation file, choose a new bare filename, for example by appending `-2`.

Use deterministic slug generation with `js_run` if helpful:

- lowercase;
- replace German umlauts (`ä` -> `ae`, `ö` -> `oe`, `ü` -> `ue`, `ß` -> `ss`);
- replace non-alphanumeric sequences with `-`;
- trim leading/trailing hyphens;
- max 60 characters.

## Fact handling: confirmed facts, proposals, and unknowns

The skill must distinguish between confirmed information and working hypotheses.

### Status values

Use these statuses consistently:

- `Erhoben`: the user or a reliable retrieved source has sufficiently confirmed the data point.
- `Teilweise erhoben`: part of the point is confirmed, but material details remain open.
- `Unklar`: the answer is vague, inconsistent, ambiguous, or cannot yet be used safely.
- `Fehlt`: not yet answered.
- `Vorschlag – zu bestätigen`: the skill proposes a plausible value, category, formulation, or option, but the user has not confirmed it.
- `Nicht bekannt`: the user says they do not know.
- `Nicht anwendbar`: the user confirmed, or the context reliably shows, that the point does not apply.

### No-assumption rules

- Do not infer the controller from the domain, signature, file name, workspace, email address, company group, or user profile unless the user confirms it.
- Do not infer that tools such as Microsoft, Google, AWS, Meta, HubSpot, Mailchimp, Stripe, Salesforce, Matomo, or similar providers are used merely because they are common.
- Do not infer legal bases. You may propose likely legal bases as `Vorschlag – zu bestätigen`, but ask the user to confirm the factual/legal approach.
- Do not infer retention periods. Offer practical options, but mark them as proposals until confirmed.
- Do not infer that there are no cookies, transfers, processors, minors, special categories, profiling, or joint controllers from silence.
- Do not mark a topic `Nicht anwendbar` unless the user confirms it or another confirmed fact makes it impossible.
- Do not convert an unanswered question into a fact. Keep it open.

### Proposal style

When helpful, offer concrete options instead of broad questions. Make clear that the options are not assumptions.

Good:

```text
Ich habe dazu noch keine bestätigte Angabe. Häufige Varianten wären: (a) nur Kontaktformular/E-Mail, (b) zusätzlich Newsletter, (c) Kundenkonto/Login, (d) Online-Shop/Zahlung, (e) Recruiting. Welche davon treffen zu, und was fehlt?
```

Bad:

```text
Ich nehme an, dass die Website Kontaktformular, Newsletter und Analytics nutzt.
```

## Incremental workflow

1. Read existing intake state if available.
2. Read the mandatory Reference requirements.
3. Extract confirmed facts from the latest user message.
4. Extract possible but unconfirmed implications only as `Vorschlag – zu bestätigen`.
5. Merge conservatively:
   - keep previous confirmed facts unless the user corrects them;
   - update facts confirmed by the user;
   - flag contradictions as `Unklar`;
   - keep ignored or unanswered questions open;
   - move a point to `Nicht bekannt` only when the user says they do not know;
   - move a point to `Nicht anwendbar` only when confirmed or reliably impossible.
6. Rewrite the complete Markdown file after each substantive update.
7. Ask the next focused question or small question set.
8. In later sessions, repeat from step 1 and continue from the unresolved points.

## Interview strategy

The goal is to gather enough facts for a useful privacy notice, not to dump a questionnaire on the user.

### Question batch size and rhythm

- Default: 1-2 questions per turn.
- Use 3 questions only when they belong to the same topic cluster.
- Maximum: 4 questions per turn, only if the user explicitly invites a broader questionnaire or all questions are short confirmations.
- Prefer a single topic cluster per turn, for example controller details, scope, analytics/cookies, processors, transfers, or retention.
- Ask follow-up questions before moving on when the current answer is materially incomplete and the missing detail is needed to understand the same topic.
- If the user gives a long answer covering several topics, record all of it, then ask only about the most important remaining gap.

### Follow-up rules

- If the user answers only part of a question, acknowledge the part answered in the file and ask only for the missing detail.
- If the user gives a vague answer such as `normale Website`, `übliche Tools`, `Standard`, `wie immer`, or `alles üblich`, ask for concrete confirmation with examples.
- If the user does not answer a material question, keep it open and ask it again later in simpler terms.
- If the user says they do not know, record `Nicht bekannt` and ask whether there is another source, document, colleague, or vendor list that could clarify it. Then move on if they do not have it.
- If the user corrects a previous answer, keep the corrected fact and note the correction in the session log.
- If two answers conflict, do not choose one silently. Mark the point `Unklar` and ask which version is right.

### Question priority

Ask in this order unless the existing file shows a more important bottleneck:

1. Identity and role of the controller, privacy contact, and any representative/DPO.
2. Scope of the notice: website, app, SaaS, customer portal, employee notice, applicants, newsletter, events, e-commerce, support, etc.
3. Core processing operations and affected person groups.
4. Data categories and data sources for each core operation.
5. Legal bases and whether consent/contract/legal obligation/legitimate interests are intended.
6. Recipients, processors, hosting, SaaS tools, payment, analytics, CRM, newsletter, support, HR tools.
7. International transfers and transfer mechanisms.
8. Cookies, tracking, marketing, profiling, automated decision-making.
9. Retention periods or deletion triggers.
10. Data subject rights process, complaint authority, security/governance notes.
11. Special categories, minors, joint controllership, public authority status, or other special cases.

### Adaptive questioning examples

- If there is no website or app, do not ask cookie questions unless another tracking context exists.
- If there is no newsletter, do not ask newsletter vendor questions.
- If the user names a processor but not the country, ask for provider location or whether a DPA/SCCs exist.
- If the user names Google, Microsoft, AWS, Meta, Salesforce, HubSpot, Mailchimp, Stripe, or similar tools, ask whether the relevant entity/region and transfer safeguards are known.
- If employees or applicants are in scope, ask HR-specific data categories, payroll/benefit recipients, background checks, and retention.
- If minors or special categories are involved, ask enhanced safeguards and legal basis details.
- If the user says only Swiss users are targeted, ask whether the notice should nevertheless cover GDPR and whether Swiss FADP should be captured as a separate drafting issue.

### Good question style

Prefer concrete, answerable questions with examples or selectable proposals.

```text
Zum Geltungsbereich habe ich noch keine bestätigte Angabe. Geht es um (a) eine reine Website, (b) Website plus Newsletter, (c) SaaS/Kundenportal, (d) Online-Shop, (e) Bewerbungen/Recruiting oder etwas anderes?
```

```text
Für Analyse/Tracking ist noch nichts bestätigt. Nutzt die Website gar kein Tracking, Matomo, Google Analytics, Meta Pixel, LinkedIn Insight Tag oder ein anderes Tool?
```

```text
Zur Speicherdauer bei Kontaktanfragen: Gibt es eine konkrete interne Frist, oder soll ich als Vorschlag zur Bestätigung erfassen: Bearbeitung der Anfrage plus gesetzliche Verjährungs-/Dokumentationsfristen?
```

Avoid broad, exhausting prompts such as:

```text
Bitte nennen Sie alle Verarbeitungszwecke, Datenkategorien, Empfänger, Rechtsgrundlagen, Speicherfristen, Drittlandtransfers, Cookies und Betroffenenprozesse.
```

## Markdown file structure

Write and rewrite the complete intake file using this structure:

```markdown
# DSGVO-Datenschutzerklärung Intake

## 1. Metadaten

| Feld | Wert |
|---|---|
| Intake-Datei | ... |
| Erstellt am | YYYY-MM-DD |
| Zuletzt aktualisiert am | YYYY-MM-DD |
| Erstellt / nachgeführt durch | Red Ink Skill `gdpr-privacy-notice-intake` |
| Status | Entwurf / unvollständig / in Klärung / bereit zur Ausarbeitung |
| Sprache der späteren Datenschutzerklärung | ... |
| Gewünschter Geltungsbereich | ... |

## 2. Kurzstand

Kurze Zusammenfassung des Vorhabens, der bestätigten Angaben, der noch nicht bestätigten Vorschläge und der wichtigsten offenen Punkte.

## 3. Erhobene Angaben

### 3.1 Verantwortlicher / Vertreter / Datenschutzkontakt

| Datenpunkt | Status | Angabe | Klärungsbedarf / Notiz |
|---|---|---|---|

### 3.2 Geltungsbereich und Zielgruppen

| Datenpunkt | Status | Angabe | Klärungsbedarf / Notiz |
|---|---|---|---|

### 3.3 Weitere Themen gemäss Reference

| Datenpunkt | Status | Angabe | Klärungsbedarf / Notiz |
|---|---|---|---|

## 4. Verarbeitungsvorgänge

| Nr. | Zweck | Betroffene Personen | Datenkategorien | Quelle | Rechtsgrundlage | Empfänger / Auftragsverarbeiter | Drittlandtransfer | Speicherdauer | Status / offene Punkte |
|---|---|---|---|---|---|---|---|---|---|

## 5. Cookies, Tracking und ähnliche Technologien

| Tool / Kategorie | Anbieter | Zweck | Daten | Rechtsgrundlage / Einwilligung | Drittlandtransfer | Speicherdauer | Status / offene Punkte |
|---|---|---|---|---|---|---|---|

## 6. Betroffenenrechte und Prozesse

| Thema | Status | Angabe | Klärungsbedarf / Notiz |
|---|---|---|---|

## 7. Vorschläge / zu bestätigende Punkte

| Priorität | Thema | Vorschlag | Warum vorgeschlagen | Konkrete Bestätigungsfrage |
|---|---|---|---|---|

## 8. Fehlende oder unklare Angaben und nächste Fragen

| Priorität | Thema | Status | Warum relevant | Konkrete nächste Frage |
|---|---|---|---|---|

## 9. Nicht anwendbare Punkte

| Thema | Begründung |
|---|---|

## 10. Quellen / Sitzungsverlauf

- Angaben des Benutzers im Dialog.
- Bestehende Intake-Datei wurde zu Sitzungsbeginn eingelesen: ja/nein.
- Nicht bestätigte Annahmen werden nicht als Fakten verwendet.
- Keine Rechtsprüfung und keine fertige Datenschutzerklärung, sofern nicht separat beauftragt.
```

Keep Markdown tables compact. Escape pipe characters in table cells.

## Data model for internal assembly

Maintain an internal state while interviewing the user. Use `js_run` for validation, sorting, deduplication, and Markdown table assembly when useful.

Recommended internal shape:

```json
{
  "metadata": {},
  "confirmed_facts": {},
  "controller": {},
  "scope": {},
  "processing_operations": [],
  "cookies_tracking": [],
  "processors_recipients": [],
  "international_transfers": [],
  "retention": [],
  "data_subject_rights": {},
  "security_and_governance": {},
  "proposals_to_confirm": [],
  "missing_or_unclear": [],
  "not_known": [],
  "not_applicable": [],
  "session_log": []
}
```

## Completion threshold

The intake is `bereit zur Ausarbeitung` only when at least these points are sufficiently answered, explicitly marked not applicable, or intentionally marked unknown with a practical drafting note:

- controller identity and privacy contact;
- scope and audience of the notice;
- all material processing operations;
- data categories and data subjects for each material operation;
- legal basis or legal-basis question for each material operation;
- recipients/processors and international transfers;
- retention periods or deletion triggers;
- cookies/tracking/marketing status;
- data subject rights contact/process;
- special categories, minors, automated decision-making, profiling, and joint controllership checked;
- no high-priority `Vorschlag – zu bestätigen` remains unresolved.

Do not mark the intake as ready merely because many fields have plausible default answers. Unconfirmed proposals are not facts.

## Interim response after each run

After each run, respond briefly with:

- filename read and/or created/updated;
- write tool used;
- what was newly recorded as confirmed;
- what was recorded only as proposal or unclear;
- the next 1-2 focused questions, with short examples or options where helpful;
- the most important remaining open points.

If any read/write tool fails, do not claim success. Report the failure, the exact tool, and the path attempted.

# Materielle Abfragevorgaben für eine DSGVO-Datenschutzerklärung

Diese Datei enthält die fachlichen Angaben, die der Skill `gdpr-privacy-notice-intake` vom Benutzer erheben, bestätigen oder als fehlend markieren soll. Die Datei ist keine Rechtsberatung und keine fertige Datenschutzerklärung. Sie dient als strukturierte Intake-Checkliste für Informationen nach der DSGVO, insbesondere für Transparenzinformationen nach Art. 12, 13 und 14 DSGVO.

## Leitprinzipien der Abfrage

- Frage nach Tatsachen, nicht nach juristischen Schlussfolgerungen, wenn der Benutzer diese nicht sicher liefern kann.
- Markiere unsichere Rechtsgrundlagen, Rollenqualifikationen, Transfermechanismen und Speicherdauern als zu prüfen.
- Erfasse pro Verarbeitungsvorgang möglichst Zweck, Datenkategorien, betroffene Personen, Quelle, Rechtsgrundlage, Empfänger, Drittlandtransfer und Speicherdauer.
- Trenne verschiedene Datenschutzhinweise, wenn sich Zielgruppe, Produkt, Verantwortlicher oder Verarbeitungskontext wesentlich unterscheiden.
- Erfasse ausdrücklich, welche Punkte nicht anwendbar sind.

## 1. Kontext und Geltungsbereich

Zu erheben:

- Gewünschte Sprache der Datenschutzerklärung.
- Geltungsbereich: Website, App, SaaS, Online-Shop, Newsletter, Recruiting, Kundenportal, Mandats-/Kundenbeziehung, Events, Beschäftigte, B2B-Kontakte, sonstiges.
- Geografischer Bezug: EU/EWR, Schweiz, UK, weltweit oder spezifische Länder.
- Zielgruppe: Kunden, Interessenten, Website-Besucher, App-Nutzer, Beschäftigte, Bewerber, Lieferanten, Geschäftspartner, Kinder/Jugendliche, sonstige.
- Ob mehrere getrennte Hinweise benötigt werden.
- Bestehende Datenschutzerklärung oder Vorversion: Datei, Link oder Text vorhanden?
- gewünschter Detaillierungsgrad und Tonalität.

Klärungsfragen:

- Für welches konkrete Angebot, welche Website, App oder Organisation soll die Datenschutzerklärung gelten?
- Richtet sich das Angebot an Verbraucher, Unternehmen, Beschäftigte, Bewerber oder mehrere Gruppen?
- Werden Personen in der EU/EWR angesprochen oder beobachtet?

## 2. Verantwortlicher, Vertreter und Datenschutzkontakt

Zu erheben:

- Vollständiger Name/Firma des Verantwortlichen.
- Rechtsform.
- Anschrift.
- Land.
- E-Mail und Telefon für Datenschutzanfragen.
- Website/Domain.
- Unternehmensregister-/Identifikationsdaten, sofern gewünscht oder lokal üblich.
- Datenschutzbeauftragter: Name/Funktion, Kontakt, extern/intern.
- EU-Vertreter nach Art. 27 DSGVO, falls der Verantwortliche nicht in der EU/EWR niedergelassen ist und Art. 27 relevant sein könnte.
- Gemeinsame Verantwortlichkeit nach Art. 26 DSGVO: beteiligte Parteien, Rollen, wesentliche Inhalte der Vereinbarung.

Klärungsfragen:

- Wer entscheidet tatsächlich über Zwecke und Mittel der Verarbeitung?
- Gibt es Konzerngesellschaften, Betreiber, Plattformpartner oder Joint Controller?
- Soll ein Datenschutzbeauftragter oder nur ein Datenschutzkontakt genannt werden?

## 3. Informationsquelle: Direkterhebung oder Dritterhebung

Zu erheben:

- Werden Daten direkt bei der betroffenen Person erhoben?
- Werden Daten aus Drittquellen bezogen?
- Drittquellen: öffentlich zugängliche Quellen, Geschäftspartner, Auskunfteien, Behörden, Social-Media-Plattformen, Konzernunternehmen, Datenbroker, sonstige.
- Kategorien personenbezogener Daten aus Drittquellen.
- Ob die betroffene Person bereits informiert wurde oder Ausnahmen nach Art. 14 Abs. 5 DSGVO geprüft werden sollen.

Klärungsfragen:

- Kommen personenbezogene Daten nur vom Nutzer selbst oder auch von Dritten?
- Welche Quelle liefert welche Datenkategorie?

## 4. Verarbeitungsvorgänge

Für jeden Verarbeitungsvorgang separat erheben:

- Laufende Nummer und kurze Bezeichnung.
- Zweck der Verarbeitung.
- Betroffene Personen.
- Kategorien personenbezogener Daten.
- Besondere Kategorien personenbezogener Daten nach Art. 9 DSGVO, falls relevant.
- Strafrechtlich relevante Daten nach Art. 10 DSGVO, falls relevant.
- Quelle der Daten.
- Rechtsgrundlage nach Art. 6 DSGVO, als bestätigt oder zu prüfen.
- Bei Einwilligung: Einwilligungsprozess, Widerrufsmöglichkeit, Protokollierung.
- Bei Vertrag/Anbahnung: Vertragsbezug.
- Bei rechtlicher Pflicht: konkrete Pflicht oder Norm, falls bekannt.
- Bei berechtigtem Interesse: konkretes Interesse, Interessenabwägung vorhanden ja/nein.
- Bei vitalen/öffentlichen Interessen: Kontext und Zuständigkeit.
- Pflicht zur Bereitstellung der Daten und mögliche Folgen der Nichtbereitstellung.
- Empfänger oder Kategorien von Empfängern.
- Auftragsverarbeiter.
- Drittlandtransfer.
- Speicherdauer oder Kriterien für die Festlegung der Dauer.
- Technische/organisatorische Besonderheiten oder Risiken.

Typische Verarbeitungsvorgänge, die abzufragen sind, soweit relevant:

- Betrieb und Sicherheit der Website/App.
- Hosting und Logfiles.
- Kontaktformular und E-Mail-Kommunikation.
- Kundenkonto / Registrierung / Login.
- Vertragserfüllung, Bestellabwicklung, Leistungsbereitstellung.
- Zahlungsabwicklung.
- Lieferung/Versand.
- Support und Kundenservice.
- Newsletter und Direktmarketing.
- CRM und B2B-Kommunikation.
- Lead-Generierung.
- Webanalyse, Reichweitenmessung und A/B-Testing.
- Cookies, lokale Speicher, SDKs und ähnliche Technologien.
- Online-Werbung, Retargeting und Conversion Tracking.
- Social-Media-Präsenzen und Plugins.
- Bewerbungen und Recruiting.
- Events, Webinare, Foto-/Videoaufnahmen.
- Kundenumfragen, Feedback, Reviews.
- Betrugsprävention, IT-Sicherheit und Missbrauchserkennung.
- Compliance, Buchhaltung, Archivierung und Rechtsdurchsetzung.
- KI-/Automatisierungsfunktionen, Chatbots oder Profiling.

## 5. Datenkategorien

Zu erheben, soweit relevant:

- Stammdaten: Name, Anschrift, Firma, Funktion.
- Kontaktdaten: E-Mail, Telefon, Social-Media-Handles.
- Vertragsdaten: Produkte, Leistungen, Laufzeiten, Kommunikation.
- Zahlungs- und Rechnungsdaten.
- Nutzungsdaten: Seitenaufrufe, Klicks, Sessions, Referrer.
- Geräte- und Logdaten: IP-Adresse, User-Agent, Geräte-ID, Betriebssystem, Browser, Zeitstempel.
- Standortdaten.
- Kommunikationsinhalte.
- Bewerbungsdaten.
- Bild-, Audio- oder Videodaten.
- Marketingpräferenzen und Einwilligungsdaten.
- Supportdaten.
- Besondere Kategorien: Gesundheit, Religion, Gewerkschaft, biometrische Daten, sexuelle Orientierung, politische Meinung, rassische/ethnische Herkunft, genetische Daten.
- Daten über Kinder/Jugendliche.

Klärungsfragen:

- Welche konkreten Daten werden je Zweck verarbeitet?
- Werden sensible Daten oder Daten Minderjähriger verarbeitet?

## 6. Rechtsgrundlagen und Einwilligungen

Zu erheben:

- Vorgeschlagene oder bestätigte Rechtsgrundlage pro Verarbeitung.
- Bei Art. 6 Abs. 1 lit. a DSGVO: Nachweis, Widerruf, Freiwilligkeit, Kopplung, Granularität.
- Bei Art. 6 Abs. 1 lit. b DSGVO: Vertrag oder vorvertragliche Maßnahme.
- Bei Art. 6 Abs. 1 lit. c DSGVO: konkrete rechtliche Pflicht.
- Bei Art. 6 Abs. 1 lit. f DSGVO: berechtigtes Interesse, Interessenabwägung, Widerspruchsmöglichkeit.
- Bei Art. 9 DSGVO: Ausnahmegrund nach Art. 9 Abs. 2 DSGVO.
- E-Privacy-/Cookie-Einwilligung, soweit relevant, als separat zu prüfen markieren.

Klärungsfragen:

- Beruht der Vorgang auf Einwilligung, Vertrag, rechtlicher Pflicht oder berechtigtem Interesse?
- Gibt es eine dokumentierte Interessenabwägung?

## 7. Empfänger, Auftragsverarbeiter und Dienstleister

Zu erheben:

- Interne Empfängerkategorien.
- Externe Empfänger: Name, Rolle, Land, Zweck.
- Auftragsverarbeiter: Hosting, Cloud, E-Mail, CRM, Analytics, Marketing, Payment, Support, Versand, HR-Tools, IT-Dienstleister.
- Besteht ein Auftragsverarbeitungsvertrag nach Art. 28 DSGVO?
- Unterauftragsverarbeiter, soweit bekannt.
- Behörden, Gerichte, Berater, Versicherer, Banken, Zahlungsdienstleister.
- Gemeinsame Verantwortliche oder eigenständige Verantwortliche.

Klärungsfragen:

- Welche externen Tools oder Dienstleister erhalten personenbezogene Daten?
- Sind sie Auftragsverarbeiter, eigene Verantwortliche oder gemeinsame Verantwortliche?

## 8. Drittlandübermittlungen

Zu erheben:

- Werden Daten außerhalb EU/EWR übermittelt oder dort zugänglich gemacht?
- Länder und Anbieter.
- Transfermechanismus: Angemessenheitsbeschluss, EU-Standardvertragsklauseln, Binding Corporate Rules, Ausnahmetatbestand, EU-US Data Privacy Framework, sonstiges.
- Ergänzende Maßnahmen, Transfer Impact Assessment oder interne Prüfung vorhanden?
- Remote-Zugriff aus Drittländern.
- Konzerninterne Transfers.

Klärungsfragen:

- Können Anbieter, Support-Teams oder Unterauftragnehmer außerhalb EU/EWR auf Daten zugreifen?
- Auf welche Transfergrundlage stützt sich die Übermittlung?

## 9. Speicherdauer und Löschung

Zu erheben:

- Konkrete Dauer pro Verarbeitungsvorgang oder objektive Kriterien.
- Beginn/Trigger der Frist: Vertragsende, letzte Aktivität, Widerruf, Ablauf gesetzlicher Frist, Bewerbungsabschluss usw.
- Gesetzliche Aufbewahrungspflichten, falls bekannt.
- Lösch-/Anonymisierungskonzept.
- Backups und Log-Retention.
- Umgang mit Widerruf, Widerspruch und Löschanfragen.

Klärungsfragen:

- Wie lange werden die jeweiligen Daten aufbewahrt?
- Gibt es unterschiedliche Fristen für Produktivsysteme, Archive und Backups?

## 10. Betroffenenrechte und Ausübung

Zu erheben:

- Kontaktweg für Rechteanfragen.
- Interner Prozess für Auskunft, Berichtigung, Löschung, Einschränkung, Datenübertragbarkeit, Widerspruch, Widerruf.
- Beschwerderecht bei einer Aufsichtsbehörde; zuständige Behörde, falls bekannt oder gewünscht.
- Identitätsprüfung bei Anfragen.
- Fristenmanagement.

Klärungsfragen:

- An welche E-Mail-Adresse sollen Betroffene Rechteanfragen richten?
- Welche Aufsichtsbehörde soll genannt werden, falls eine konkrete genannt werden soll?

## 11. Cookies, Tracking, SDKs und ähnliche Technologien

Zu erheben:

- Verwendete Cookies, lokale Speicher, Pixel, Tags, SDKs und ähnliche Technologien.
- Tool/Anbieter, Zweck, Kategorie, Lebensdauer, Domain, Datenkategorien.
- Technisch notwendig oder optional.
- Consent-Management-Tool und Konfiguration.
- Einwilligungsprotokollierung und Widerrufsmöglichkeit.
- Analytics, Marketing, Retargeting, Conversion Tracking, Social Plugins, eingebettete Medien, Karten, Captchas, Fonts/CDNs.
- Serverseitiges Tracking oder Tag Manager.

Klärungsfragen:

- Welche Tracking- oder Drittanbieter-Skripte sind eingebunden?
- Gibt es ein Cookie-Banner oder Consent-Management-Tool?

## 12. Marketing, Newsletter und elektronische Kommunikation

Zu erheben:

- Newsletter-Anbieter.
- Anmeldeprozess: Double-Opt-In ja/nein.
- Protokollierte Daten: Zeitpunkt, IP, Quelle, Einwilligungstext.
- Inhalte und Zielgruppen.
- Bestandskundenwerbung.
- Tracking in Newslettern.
- Abmeldemöglichkeit.
- Telefon-, SMS-, Messenger- oder postalisches Marketing.

Klärungsfragen:

- Wie melden sich Personen für Marketingkommunikation an?
- Wird Öffnungs- oder Klicktracking verwendet?

## 13. Profiling und automatisierte Entscheidungen

Zu erheben:

- Gibt es Profiling, Scoring, Segmentierung oder personalisierte Empfehlungen?
- Gibt es automatisierte Entscheidungen mit rechtlicher oder ähnlich erheblicher Wirkung nach Art. 22 DSGVO?
- Logik, Tragweite und angestrebte Auswirkungen.
- Möglichkeit menschlicher Überprüfung.
- Datenquellen und Kriterien.

Klärungsfragen:

- Treffen Systeme Entscheidungen über Personen, ohne dass ein Mensch prüft?
- Hat dies erhebliche Auswirkungen, z.B. Ablehnung, Preis, Zugang oder Risikoklassifizierung?

## 14. Sicherheit, Governance und Dokumentation

Zu erheben:

- Kurzbeschreibung technischer und organisatorischer Maßnahmen, sofern in der Datenschutzerklärung erwähnt werden soll.
- Rollen und Verantwortlichkeiten intern.
- Verzeichnis von Verarbeitungstätigkeiten vorhanden ja/nein.
- Datenschutz-Folgenabschätzung erforderlich oder durchgeführt?
- Datenschutzverletzungsprozess vorhanden?
- Privacy by Design/Default, Schulungen, Zugriffskontrollen.

Klärungsfragen:

- Gibt es besondere Risiken oder eine Datenschutz-Folgenabschätzung?
- Welche Sicherheitsmaßnahmen sollen in allgemein verständlicher Form erwähnt werden?

## 15. Besondere Kontexte

Zusätzlich abfragen, falls relevant:

### Minderjährige

- Alter der Zielgruppe.
- Einwilligung der Eltern/Sorgeberechtigten.
- Altersprüfung.
- kindgerechte Sprache.

### Beschäftigte und Bewerber

- Bewerbungsportal, E-Mail-Bewerbungen, Talentpool.
- Datenkategorien und Empfänger.
- Aufbewahrungsfristen.
- Einwilligung für Talentpool.
- Hintergrundchecks, Referenzen, Assessment-Tools.

### Gesundheits-, Finanz- oder sonstige sensible Kontexte

- Besondere Datenkategorien.
- gesetzliche Pflichten.
- besondere Schutzmaßnahmen.
- beschränkter Empfängerkreis.

### Konzern / Unternehmensgruppe

- konzerninterne Empfänger.
- gemeinsame Systeme.
- gemeinsame Verantwortlichkeit oder Auftragsverarbeitung.
- Drittlandzugriffe.

## 16. Pflichtinformationen nach Art. 13/14 DSGVO als Vollständigkeitskontrolle

Der Intake soll erkennen lassen, ob folgende Informationen vorliegen oder fehlen:

- Identität und Kontaktdaten des Verantwortlichen.
- Kontaktdaten des Datenschutzbeauftragten, falls vorhanden.
- Zwecke und Rechtsgrundlagen der Verarbeitung.
- Berechtigte Interessen, falls Art. 6 Abs. 1 lit. f DSGVO genutzt wird.
- Empfänger oder Empfängerkategorien.
- Drittlandübermittlungen und geeignete Garantien.
- Speicherdauer oder Kriterien für die Festlegung der Dauer.
- Betroffenenrechte.
- Widerrufsrecht bei Einwilligung.
- Beschwerderecht bei einer Aufsichtsbehörde.
- Ob die Bereitstellung gesetzlich/vertraglich vorgeschrieben oder für Vertragsschluss erforderlich ist und mögliche Folgen der Nichtbereitstellung.
- Bestehen automatisierter Entscheidungsfindung einschließlich Profiling und aussagekräftige Informationen zur Logik, Tragweite und Auswirkungen.
- Bei Dritterhebung: Kategorien personenbezogener Daten und Quelle.
- Bei Dritterhebung: Information über öffentliche Quellen, soweit relevant.

## 17. Priorisierung offener Punkte

Verwende folgende Prioritäten für fehlende oder unklare Angaben:

| Priorität | Bedeutung | Beispiele |
|---|---|---|
| Hoch | Blockiert oder gefährdet die Erstellung eines belastbaren Entwurfs erheblich. | Verantwortlicher fehlt; Zwecke/Rechtsgrundlagen fehlen; Drittlandtransfer unklar; sensible Daten unklar; Profiling/Art. 22 unklar. |
| Mittel | Entwurf möglich, aber mit markierten Lücken oder Annahmen. | konkrete Speicherdauer fehlt; AVV-Status unklar; Empfänger nur grob bekannt. |
| Niedrig | Kann später verfeinert werden. | Tonalität; optionale Registerangabe; nicht wesentliche Beschreibung einer Sicherheitsmaßnahme. |

## 18. Mindestdatensatz für einen brauchbaren Intake-Entwurf

Der Skill darf eine Markdown-Datei erstellen, sobald mindestens folgende Punkte sinnvoll dokumentiert sind oder ausdrücklich als fehlend markiert wurden:

- Verantwortlicher oder Projektname.
- Geltungsbereich.
- Zielgruppen.
- mindestens ein Verarbeitungsvorgang oder die Feststellung, dass Verarbeitungsvorgänge noch fehlen.
- Status der wichtigsten Sonderthemen: Cookies/Tracking, Marketing, Drittlandtransfer, besondere Kategorien, Minderjährige, Profiling/automatisierte Entscheidungen.
- Liste der offenen Punkte.

## 19. Nicht-Anwendbarkeit ausdrücklich dokumentieren

Folgende Themen sollen nicht einfach weggelassen werden. Wenn nicht relevant, als `Nicht anwendbar` dokumentieren:

- Datenschutzbeauftragter.
- EU-Vertreter.
- gemeinsame Verantwortlichkeit.
- Dritterhebung.
- besondere Kategorien personenbezogener Daten.
- Daten Minderjähriger.
- Cookies/Tracking.
- Newsletter/Marketing.
- Profiling/automatisierte Entscheidungen.
- Drittlandübermittlungen.
- Datenschutz-Folgenabschätzung.

---
name: large-document-review
description: Reviews one large document for a defined objective without loading the full source into the parent context; delegates bounded reading and optional research.
allowed-tools:
  - ask_user
  - read_word_document_details
  - agent_shared_large_document_analyzer
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - context_compact
  - create_word_document
model: agentdefaultmodel
---

# Large Document Review

Use when a document is large enough that full extraction would materially consume the main context, or when only bounded portions are relevant.

## Architecture
1. Define the review objective before reading broadly.
2. Pass the source reference, not the full extracted text, to `agent_shared_large_document_analyzer`.
3. Receive only the compact source map, findings, anchors, coverage, and precise research questions.
4. If external facts are genuinely required and permitted, keep a single compact lookup in the parent when it can be answered without material context pressure. Use `agent_shared_bounded_researcher` when there are multiple separable external questions, when the retrieval would materially consume parent context, or when isolated research was explicitly requested.
5. Synthesize without re-reading the full source in the parent.
6. Use `agent_shared_evidence_verifier` only for material claims needing a final support check.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

## Rules
- Do not combine a large full-document dump with broad research output in the parent context.
- If coverage is partial, state the unreviewed scope. When the user requested a review of tracked changes or comments, check the delegated coverage before declaring completion. If the requested markup could not be inspected, report that part as incomplete.
- Treat source examples as examples unless expressly controlling.
- Stop once additional reading or research is unlikely to change the requested outcome.

If the user requests a Word review report, actually create the final `.docx` with `create_word_document` in the host-provided working/session location and use the returned output path. Do not treat a prose report or intended filename as the file. If creation fails, return `blocked` for the file-producing request. Do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


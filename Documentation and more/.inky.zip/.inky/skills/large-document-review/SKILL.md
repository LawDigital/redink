---
name: large-document-review
description: Reviews one large document for a defined objective without loading the full source into the parent context; delegates bounded reading and optional research.
allowed-tools:
  - agent_shared_large_document_analyzer
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - context_compact
  - create_word_document
model: agentdefaultmodel
---

# Large Document Review

Use when a document is large enough that full extraction would materially consume the main context, or when only bounded portions are relevant.

## Architecture
1. Define the review objective before reading broadly.
2. Pass the source reference, not the full extracted text, to `agent_shared_large_document_analyzer`.
3. Receive only the compact source map, findings, anchors, coverage, and precise research questions.
4. If external facts are genuinely required and permitted, delegate each bounded question to `agent_shared_bounded_researcher`.
5. Synthesize without re-reading the full source in the parent.
6. Use `agent_shared_evidence_verifier` only for material claims needing a final support check.

## Rules
- Do not combine a large full-document dump with broad research output in the parent context.
- If coverage is partial, state the unreviewed scope.
- Treat source examples as examples unless expressly controlling.
- Stop once additional reading or research is unlikely to change the requested outcome.

If the user requests a Word review report, actually create the final `.docx` with `create_word_document` in the host-provided working/session location and use the returned output path. Do not treat a prose report or intended filename as the file. If creation fails, return `blocked` for the file-producing request. Do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


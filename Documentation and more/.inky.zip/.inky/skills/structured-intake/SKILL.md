---
name: structured-intake
description: Converts messages and source documents into a traceable structured intake record using a caller-provided or compact inferred schema.
allowed-tools:
  - list_attachments
  - m365_search
  - agent_shared_structured_extractor
  - js_run
model: agentdefaultmodel
---

# Structured Intake

Use to collect and normalize facts for professional workflows without turning examples or defaults into facts.

## Schema
Prefer a supplied schema containing fields, types, required/optional status, conditions, validation rules, and source expectations. If none is supplied, create only a compact conventional schema for the stated task and label it as inferred.

## Architecture
1. Identify available source references without pre-extracting all content.
2. Delegate each material source to `agent_shared_structured_extractor` with the schema.
3. Merge returned field values and provenance deterministically.
4. Separate `stated`, `derived`, `assumed`, and `missing` values.
5. Surface conflicts instead of silently choosing one source.
6. In interactive use, ask only for outcome-determinative missing facts; in unattended use, mark them missing rather than inventing them.

## Output
Return a compact structured record plus missing required fields, validation issues, assumptions, source anchors, conflicts, and readiness/next action. This skill is primarily analytical; do not create a file unless the parent workflow explicitly routes the structured result into an appropriate file-producing capability.

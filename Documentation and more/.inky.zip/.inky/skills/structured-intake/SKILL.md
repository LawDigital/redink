---
name: structured-intake
description: Converts messages and source documents into a traceable structured fact record using a caller-provided or configured intake schema when no substantive checklist/assessment decision is being made. Do NOT use for checklist-based screening, eligibility, compliance, scope or policy determinations; use guided-case-assessment for those.
allowed-tools:
  - text_read
  - ask_user
  - list_attachments
  - m365_search
  - agent_shared_structured_extractor
  - js_run
model: agentdefaultmodel
---

# Structured Intake

Use this skill to collect and normalize facts for a parent workflow.

## Hard boundary

This skill is **not** an assessment/checklist engine.

If the requester asks to:
- assess;
- screen;
- determine eligibility/scope;
- apply a checklist;
- decide whether a legal/compliance/policy condition is met;
- produce a configured pass/fail/in-scope/out-of-scope result;

do not use this skill as the substantive workflow. Route to `guided-case-assessment` when that skill is available.

Do not load `structured-intake` and `guided-case-assessment` in parallel merely because the assessment
needs intake questions. `guided-case-assessment` already owns its intake.

A configured intake schema may ask for a user's stated legal basis, retention period, transfer mechanism
or other professional fact, but this skill must record that value rather than decide whether it is legally
sufficient or correct.

## 1. Schema selection

Prefer a caller-supplied schema containing fields, types, required/optional status, conditions,
validation rules, and source expectations.

If no caller schema is supplied:

1. If `references/intake_schemas.json` is available, use it to select a specifically matching configured
   schema. Load only the selected schema package.
2. If several configured schemas plausibly match and `ask_user` is actually available, ask which one
   to use. If interactive clarification is unavailable, do not call `ask_user`; return a concise
   clarification need / blocked result instead. Do not silently combine schemas.
3. If no configured schema matches, create only a compact conventional schema for the stated
   fact-normalization task and label it inferred.

Configured schemas are examples/reference workflows unless the user or an authoritative source makes
them controlling.

## 2. Language and maintainer comments

Stable field ids carry semantics; do not make extraction logic depend on the literal language-specific
wording of a label or answer.

Maintainer-only HTML comments in reference Markdown are not intake content and must never be returned
as a question, field value, warning, or ordinary runtime explanation unless the user explicitly asks to
inspect maintainer metadata.

## 3. Architecture

1. Identify relevant supplied sources. Use `m365_search` only when it is actually advertised for the current host; otherwise rely on supplied/attachment sources and do not treat its absence as a reason to fabricate facts.
2. Resolve the schema.
3. Extract only fields required by the schema.
4. Merge values and provenance deterministically.
5. Separate `stated`, `derived`, `assumed`, `missing`, and conflicts.
6. Ask only for missing material facts when the workflow is interactive and clarification is appropriate.
7. Do not decide a substantive checklist outcome unless a parent assessment workflow supplied and owns
   that logic.

## 4. Output

Return the structured record, missing fields, validation issues, assumptions, source anchors, conflicts,
and readiness for the parent workflow.

When using a configured schema, preserve its stable field ids in the structured record and present
human-readable labels in the dialogue language where practical.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

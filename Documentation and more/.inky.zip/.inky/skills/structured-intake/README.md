# Structured Intake Reference Library

`structured-intake` collects and normalizes facts. It does **not** decide legal/compliance sufficiency,
eligibility, scope or pass/fail outcomes.

## Included sample schema

- `privacy-notice-intake` — structured facts typically useful when preparing or updating a privacy
  notice.

The sample records stated legal bases, retention periods, transfers etc. as facts supplied by the
responsible expert; it does not decide whether those positions are legally correct.

## Authoring model

For each reusable schema:

- `schema.md` — normative human-readable field specification;
- `schema.json` — derived executable schema;
- `source_notes.md` — intended use, provenance and exclusions.

Use `skill-author` for create/sync workflows; experts should normally edit/review `schema.md`, not JSON.

Copy/paste create prompt:

> Create a new reusable structured-intake schema from the attached expert field list. Keep the human-readable `schema.md` as the master, derive `schema.json`, and register the schema. Collect facts only; do not add a substantive compliance decision.

Copy/paste revision prompt:

> Here is the subject-matter expert's revised field list for intake schema `<id>`. Synchronize the existing schema, preserve stable field IDs where possible, and show added, removed, or changed fields.

<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# Source notes

This sample is intentionally jurisdiction-neutral and organisation-neutral. It demonstrates the separation between a human-readable field specification and the derived technical `schema.json`. Before production use, the responsible privacy expert should determine which fields are actually required for the relevant organisation, jurisdiction, and privacy notice.

<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# Privacy Notice — Fact Intake

## Purpose

This sample collects facts that may be needed to draft or update a privacy notice. It does **not** determine whether a stated legal basis, retention period, transfer mechanism, or other privacy position is legally correct or sufficient.

## Core rules

- Record only facts that are known or can be traceably derived from supplied sources.
- Treat stated legal positions as `stated`, not as legal conclusions validated by the intake.
- Keep missing facts explicitly unresolved.
- Preserve provenance/source information for material values.
- Do not perform pass/fail, scope, or compliance determinations in this schema.

## Fields

### 1. Organisation / controller

Name/legal entity and basic identity of the controller or organisation.

- Technical ID: `organisation_identity`
- Type: `text`
- Required in this sample: Yes

### 2. Contact details

Contact address, email address, and other contact details intended for publication.

- Technical ID: `contact_details`
- Type: `object`
- Required in this sample: Yes

### 3. Privacy contact / DPO

Privacy contact or data protection officer, where applicable or intended for the notice.

- Technical ID: `privacy_contact`
- Type: `object`
- Required in this sample: No

### 4. Services and channels

Websites, apps, portals, products, services, or other channels covered by the privacy notice.

- Technical ID: `services_channels`
- Type: `list`
- Required in this sample: Yes

### 5. Categories of data subjects

For example customers, prospects, website visitors, business-contact persons, or applicants.

- Technical ID: `data_subject_categories`
- Type: `list`
- Required in this sample: Yes

### 6. Categories of personal data

The personal-data categories actually processed.

- Technical ID: `personal_data_categories`
- Type: `list`
- Required in this sample: Yes

### 7. Purposes of processing

The actual purposes pursued for each processing activity or relevant data category.

- Technical ID: `processing_purposes`
- Type: `list`
- Required in this sample: Yes

### 8. Stated legal bases

Legal bases stated by the responsible expert; the intake does not assess whether they are correct.

- Technical ID: `stated_legal_bases`
- Type: `list`
- Required in this sample: No

### 9. Sources of personal data

Direct collection, third parties, public sources, affiliates, and similar sources.

- Technical ID: `data_sources`
- Type: `list`
- Required in this sample: No

### 10. Recipients / categories of recipients

Internal and external recipients or categories of recipients.

- Technical ID: `recipients_categories`
- Type: `list`
- Required in this sample: No

### 11. Processors / service providers

Material service providers or categories where transparency is intended.

- Technical ID: `processors_service_providers`
- Type: `list`
- Required in this sample: No

### 12. International transfers

Countries/regions, recipients, and transfer mechanisms stated by the responsible expert.

- Technical ID: `international_transfers`
- Type: `list`
- Required in this sample: No

### 13. Retention / deletion

Stated retention periods or criteria used to determine them.

- Technical ID: `retention_rules`
- Type: `list`
- Required in this sample: No

### 14. Cookies and tracking

Tracking, analytics, advertising technologies, and consent/opt-out mechanisms where relevant.

- Technical ID: `cookies_tracking`
- Type: `object`
- Required in this sample: No

### 15. Automated decision-making / profiling

Whether such processing occurs and what factual information is provided about it.

- Technical ID: `automated_decisions`
- Type: `object`
- Required in this sample: No

### 16. Special-category data / minors

Whether special-category data or data relating to minors is processed and in what context.

- Technical ID: `special_categories_minors`
- Type: `object`
- Required in this sample: No

### 17. Data-subject rights contact/process

How requests for access, rectification, deletion, and similar rights are received and handled.

- Technical ID: `data_subject_rights_contact`
- Type: `object`
- Required in this sample: No

### 18. Complaints / supervisory authority

Information intended to be provided about complaints or the relevant supervisory authority.

- Technical ID: `complaints_authority`
- Type: `object`
- Required in this sample: No

### 19. Privacy-notice updates

Versioning, date, and communication approach for material privacy-notice changes.

- Technical ID: `policy_updates`
- Type: `object`
- Required in this sample: No

### 20. Open points

Unresolved facts or expert decisions that must not be invented.

- Technical ID: `open_points`
- Type: `list`
- Required in this sample: No

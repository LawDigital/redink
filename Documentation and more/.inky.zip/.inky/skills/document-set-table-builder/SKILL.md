---
name: document-set-table-builder
description: Builds a structured table from a collection of documents or sources while delegating one source at a time to isolated row workers.
allowed-tools:
  - ask_user
  - workspace_get
  - workspace_inventory
  - agent_workspace_find_files
  - agent_workspace_search
  - m365_search
  - list_attachments
  - agent_shared_document_table_row_worker
  - js_run
  - create_excel_spreadsheet
  - create_word_document
model: agentdefaultmodel
---

# Document Set Table Builder

Use for inventories, comparison matrices, evidence registers, diligence tables, matter lists, clause tables, or other structured extraction across multiple sources.

## Architecture
1. Resolve columns, criteria, source scope, output language, and desired artifact.
2. Discover the concrete source list without extracting all source texts.
3. Deduplicate and record inclusion/skip decisions.
4. Call `agent_shared_document_table_row_worker` once per processable source.
5. Assemble only returned rows; never fill missing factual cells from general knowledge.
6. Validate exact column order, normalization, and audit counts with deterministic processing.
7. Create Excel/Word only when requested or clearly useful.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

## Rules
- If columns are not supplied, choose a compact domain-appropriate schema; do not hard-code contract/legal columns for unrelated tasks.
- Large-source extraction belongs in the row worker.
- For very large collections, process in manageable batches and compact completed batch detail when supported.
- Report coverage and skipped/failed sources.

## File output
When a spreadsheet or Word report is requested, make the final substantive file action a successful `create_excel_spreadsheet` or `create_word_document` call using the host-provided working/session location. Use the actual output path from that tool result. A proposed filename or text table is not a substitute for the requested file. If creation fails, return `blocked` for the file-producing request. Do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


---
name: document-set-table-builder
description: Builds a structured table from a collection of documents or sources while delegating one source at a time to isolated row workers.
allowed-tools:
  - workspace_get
  - workspace_inventory
  - agent_workspace_find_files
  - agent_workspace_search
  - m365_search
  - list_attachments
  - agent_shared_document_table_row_worker
  - js_run
  - create_excel_spreadsheet
  - create_word_document
model: agentdefaultmodel
---

# Document Set Table Builder

Use for inventories, comparison matrices, evidence registers, diligence tables, matter lists, clause tables, or other structured extraction across multiple sources.

## Architecture
1. Resolve columns, criteria, source scope, output language, and desired artifact.
2. Discover the concrete source list without extracting all source texts.
3. Deduplicate and record inclusion/skip decisions.
4. Call `agent_shared_document_table_row_worker` once per processable source.
5. Assemble only returned rows; never fill missing factual cells from general knowledge.
6. Validate exact column order, normalization, and audit counts with deterministic processing.
7. Create Excel/Word only when requested or clearly useful.

## Rules
- If columns are not supplied, choose a compact domain-appropriate schema; do not hard-code contract/legal columns for unrelated tasks.
- Large-source extraction belongs in the row worker.
- For very large collections, process in manageable batches and compact completed batch detail when supported.
- Report coverage and skipped/failed sources.

## File output
When a spreadsheet or Word report is requested, make the final substantive file action a successful `create_excel_spreadsheet` or `create_word_document` call using the host-provided working/session location. Use the actual output path from that tool result. A proposed filename or text table is not a substitute for the requested file. If creation fails, return `blocked` for the file-producing request. Do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


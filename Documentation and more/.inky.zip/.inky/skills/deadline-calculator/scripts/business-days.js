function addBusinessDays(startDateIso, days, holidaysIso = [], countStartDate = false) {
  const holidays = new Set(holidaysIso || []);
  const date = new Date(startDateIso + 'T00:00:00Z');
  if (Number.isNaN(date.getTime())) throw new Error('Invalid start date');

  let remaining = Number(days);
  if (!Number.isInteger(remaining) || remaining < 0) throw new Error('days must be a non-negative integer');

  function iso(d) { return d.toISOString().slice(0, 10); }
  function isBusinessDay(d) {
    const dow = d.getUTCDay();
    return dow !== 0 && dow !== 6 && !holidays.has(iso(d));
  }

  if (countStartDate && remaining > 0 && isBusinessDay(date)) remaining -= 1;

  while (remaining > 0) {
    date.setUTCDate(date.getUTCDate() + 1);
    if (isBusinessDay(date)) remaining -= 1;
  }
  return iso(date);
}

function addCalendarDays(startDateIso, days, countStartDate = false) {
  const date = new Date(startDateIso + 'T00:00:00Z');
  if (Number.isNaN(date.getTime())) throw new Error('Invalid start date');
  let n = Number(days);
  if (!Number.isInteger(n) || n < 0) throw new Error('days must be a non-negative integer');
  if (countStartDate && n > 0) n -= 1;
  date.setUTCDate(date.getUTCDate() + n);
  return date.toISOString().slice(0, 10);
}

---
name: contract-review-playbook
description: Reviews a contract against a Markdown checklist in References by delegating criterion analysis to the shared contract-review agent and then adding verified Word comments for material findings. Works in Word and Outlook when a comment-capable Word document is available.
allowed-tools:
  - text_read
  - text_search
  - word_extract_text
  - word_search
  - word_comment_add
  - word_comment_list
  - worddoc_get_active
  - worddoc_extract_text
  - worddoc_search
  - worddoc_comment_add
  - worddoc_list_comments
  - m365_get_file
  - agent_workspace_read
  - comment_word_document
  - js_run
  - skill_use
  - agent_shared_contract_review_worker
model: agentdefaultmodel
---

# Contract Review Playbook

Review a contract against the Markdown checklist in `References/contract-review-checklist.md`, obtain a structured finding set from `agent_shared_contract_review_worker`, and add Word comments for all material findings.

This skill is for criteria-based legal and commercial review. It is not general proofreading and it must not produce final legal advice.

## Mandatory reference file

Before reviewing, read:

```text
skills/contract-review-playbook/References/contract-review-checklist.md
```

The checklist contains:

- review criteria;
- if/then scenario rules;
- severity guidance;
- expected comment style;
- escalation rules.

If the reference file cannot be read, stop and report the inability. Do not invent a checklist.

## Mandatory delegation

After the checklist and contract text have been obtained, the parent skill **must call** `agent_shared_contract_review_worker` to perform the criterion-by-criterion analysis.

Do not perform the substantive review solely in the parent skill unless `agent_shared_contract_review_worker` is unavailable. If the agent is unavailable, report that limitation explicitly in the final response.

The parent skill is responsible for orchestration, comment insertion, and verification. The shared agent is responsible for returning the structured findings JSON.

## Supported targets

### Word host

- Active/open document: use `worddoc_get_active`, `worddoc_extract_text`, `worddoc_search`, and `worddoc_comment_add`.
- Saved `.docx` file path: use `word_extract_text`, `word_search`, and `word_comment_add`.

### Outlook host

- Saved `.docx` file path: use shared `word_extract_text`, `word_search`, and `word_comment_add`.
- M365 file or agent workspace file: retrieve text using `m365_get_file` or `agent_workspace_read`; if a comment-capable `.docx` copy/path is available, add comments with `word_comment_add` or `comment_word_document`.
- If only non-commentable text is available, provide a findings report and clearly state that comments were not inserted.

## Review workflow

1. Identify the contract target and whether comments can be inserted.
2. Read the Markdown checklist from `References/contract-review-checklist.md` using `text_read`.
3. Extract the contract text using the appropriate Word, M365, or workspace read tool.
4. Call `agent_shared_contract_review_worker` with JSON input containing:
   - contract id/name/type;
   - checklist path;
   - complete checklist text if available;
   - complete contract text if available;
   - review purpose and user-specific instructions, if any;
   - requested output language.
5. Parse the agent's JSON output and keep the full list of findings in order.
6. For every material finding whose severity is `High`, `Medium`, or user-requested `Low`, identify the smallest reliable anchor span.
7. Add Word comments **sequentially, one tool call at a time**. Do not emit multiple `word_comment_add` or `worddoc_comment_add` calls in the same model response.
8. If an anchor is not found, retry with a shorter exact phrase, heading, or nearest related clause. If still not found, record the comment as skipped and explain why.
9. After all comment insertions, call `word_comment_list` or `worddoc_list_comments` to verify inserted comments.
10. Return a summary of findings, inserted comments, skipped comments, verification result, and limitations.

## Agent input format

Call `agent_shared_contract_review_worker` with task/context equivalent to:

```json
{
  "contract": {
    "id": "GTC.docx",
    "name": "GTC.docx",
    "type": "docx-path"
  },
  "checklist_path": "skills/contract-review-playbook/References/contract-review-checklist.md",
  "review_purpose": "general",
  "user_policy": "optional user/client-specific instructions",
  "language": "same language as the user request"
}
```

Include extracted contract text and checklist text in context when available so the worker does not have to reread them unless needed.

## Commenting rules

- Add comments only for material issues, missing clauses, inconsistent provisions, or scenario-rule failures.
- Default material severities are `High` and `Medium`; include `Low` only if it is important, specifically requested, or needed to explain a scenario rule.
- Use the smallest reliable anchor, usually a clause heading or the relevant sentence.
- If a clause is missing, anchor the comment to the closest related clause or document heading and say that the reviewed item was not found.
- Do not add multiple comments for the same issue unless separate clauses create separate risks.
- Do not rewrite the contract unless the user explicitly asks for drafting changes.
- Comment text must be concise and action-oriented.
- Each comment should start with the severity in square brackets, e.g. `[High]`, `[Medium]`, `[Low]`.

## Sequencing rule for Word comments

Word comment tools are stateful editing tools. Therefore:

- never batch multiple comment tool calls in one response;
- add one comment;
- wait for the tool result;
- then add the next comment;
- continue until all findings have been processed;
- finally verify with the comment-list tool.

This avoids deferred tool calls and lost or partially replayed findings.

## Finding format

Each finding should contain:

- ID, e.g. `CR-001`;
- criterion or rule name;
- severity: `High`, `Medium`, `Low`, or `Info`;
- evidence anchor;
- issue;
- recommendation;
- comment status: inserted, skipped, or not possible.

## Verification

At the end of the run, verify comments by listing comments in the reviewed Word document.

The final answer must state:

- whether `agent_shared_contract_review_worker` was used;
- contract reviewed;
- checklist used;
- number of criteria applied;
- number of findings returned by the agent;
- number of comments inserted according to the insertion calls;
- number of comments visible in the verification list;
- skipped findings/comments and reasons;
- limitations.

If the verification count does not match the expected inserted count, report the mismatch and do not claim full success.

## Output

Return a concise summary in the user's language with:

- contract reviewed;
- checklist used;
- agent used: yes/no;
- number of criteria applied;
- number of comments inserted and verified;
- table of material findings;
- skipped comments or limitations.

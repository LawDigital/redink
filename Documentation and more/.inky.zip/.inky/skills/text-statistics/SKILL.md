---
name: text-statistics
description: Calculates deterministic text statistics with JavaScript, including words, paragraphs, characters, and page count when page information is available.
allowed-tools:
  - js_run
model: agentdefaultmodel
---

# Text Statistics

Use this skill when the user wants simple, deterministic text/document statistics and a lightweight example of `js_run` is appropriate.

## Supported statistics

- words;
- paragraphs;
- characters including whitespace;
- characters excluding whitespace;
- pages, when the source provides reliable page information.

## Inputs

Use the actual source text supplied or extracted for the task. If the source already provides a reliable page count, pass that count separately rather than trying to infer layout from plain text.

For paragraph counting, prefer source structure that preserves logical paragraphs. If the input is only flattened plain text, count non-empty blocks separated by one or more blank lines and state that this is a text-structure count rather than a Word-layout count.

## Rules

- Use `js_run` for the counting operation. If it is not advertised, do not fall back to Python or a model estimate; report that the deterministic counting capability is unavailable for this run.
- Keep the operation deterministic; do not use a language model to estimate counts that JavaScript can calculate exactly.
- Do not estimate rendered page count from word or character count.
- Page count is reliable only when one of the following is available:
  1. a page count supplied by the source/tool metadata; or
  2. explicit form-feed/page-break characters (`\f`) in the input representation.
- If neither is available, return the page count as unavailable rather than inventing one.
- Unicode words should be counted as words. Hyphenated/apostrophized tokens should normally remain one word where the JavaScript runtime supports Unicode property escapes.

## JavaScript example

A reusable example is provided in `scripts/text_statistics.js`. Adapt only the input values or clearly requested counting convention; preserve the deterministic behavior.

## Orchestrator compatibility

- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.

## Output

Return a compact result containing:

- `words`
- `paragraphs`
- `characters`
- `characters_without_whitespace`
- `pages` (number or `null`)
- `page_count_basis` (`source_metadata`, `explicit_page_breaks`, or `unavailable`)

Briefly state any counting assumption that materially affects the result.

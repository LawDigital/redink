/**
 * Deterministic text statistics example for Red Ink / js_run.
 *
 * Usage:
 *   const result = countTextStatistics(text, { pageCount: 12 });
 *   // or, when the text contains form-feed page breaks (\f):
 *   const result = countTextStatistics(text);
 */
function countTextStatistics(text, options = {}) {
  if (typeof text !== "string") {
    throw new TypeError("text must be a string");
  }

  const normalized = text.replace(/\r\n?/g, "\n");

  // Unicode-aware word counting. Internal apostrophes and hyphens remain
  // part of the same word (e.g. "don't", "E-Mail", "Müller-Lüdenscheidt").
  const wordPattern = /[\p{L}\p{N}]+(?:[’'\-][\p{L}\p{N}]+)*/gu;
  const words = normalized.match(wordPattern)?.length ?? 0;

  // Paragraphs are non-empty text blocks separated by one or more blank lines.
  // This is deliberately a text-structure count, not a rendered Word-layout count.
  const trimmed = normalized.trim();
  const paragraphs = trimmed.length === 0
    ? 0
    : trimmed.split(/\n[\t ]*\n+/).filter(block => block.trim().length > 0).length;

  const characters = text.length;
  const charactersWithoutWhitespace = (text.match(/\S/gu) ?? []).length;

  let pages = null;
  let pageCountBasis = "unavailable";

  if (Number.isInteger(options.pageCount) && options.pageCount >= 0) {
    pages = options.pageCount;
    pageCountBasis = "source_metadata";
  } else if (text.length > 0 && text.includes("\f")) {
    pages = text.split("\f").length;
    pageCountBasis = "explicit_page_breaks";
  }

  return {
    words,
    paragraphs,
    characters,
    characters_without_whitespace: charactersWithoutWhitespace,
    pages,
    page_count_basis: pageCountBasis
  };
}

// Example input for direct js_run use:
// const text = "Erster Absatz.\n\nZweiter Absatz mit E-Mail.\fDritte Seite.";
// return countTextStatistics(text);

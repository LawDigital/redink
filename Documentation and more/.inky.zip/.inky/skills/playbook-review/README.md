# Playbook Review Reference Library

`playbook-review` can use caller-provided criteria or one/more configured playbooks from
`references/playbooks.json`.

## Included sample playbooks

- `dpa-customer` — DPA review from the customer/controller perspective.
- `nda-balanced` — balanced NDA/confidentiality review.
- `general-contract-quick-review` — small general commercial contract quick check.
- `saas-customer` — SaaS/cloud agreement review from customer perspective.

These are reference patterns, not automatically controlling legal standards.

## Multi-playbook

A user can explicitly request several configured playbooks in one review, e.g.:

> Review this SaaS agreement with `saas-customer` and also with `general-contract-quick-review`.

Each playbook remains independently traceable. Duplicate findings may be consolidated for presentation
or editing, but the contributing criteria/playbooks remain visible internally.

## Authoring model

For each playbook:

- `playbook.md` — normative human-readable criteria;
- `criteria.json` — derived executable criteria;
- `source_notes.md` — provenance/limitations/maintenance notes.

Use `skill-author` to create or synchronize playbooks; subject-matter experts should normally edit/review
`playbook.md`, not JSON.

Copy/paste create prompt:

> Create a new sample playbook for the playbook-review skill from the attached checklist. Keep the human-readable `playbook.md` authoritative, derive the technical criteria file from it, and register the playbook. Do not invent additional review criteria.

Copy/paste revision prompt:

> Here is the revised source for playbook `<id>`. Synchronize the existing sample, preserve stable criterion IDs where the substantive criterion is unchanged, and show which review criteria changed substantively.

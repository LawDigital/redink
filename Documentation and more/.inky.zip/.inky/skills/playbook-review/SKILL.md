---
name: playbook-review
description: Reviews a document against caller-provided criteria or one or more configured playbooks, using one isolated requirement check per criterion and consolidating overlapping findings without losing playbook provenance.
allowed-tools:
  - text_read
  - ask_user
  - agent_shared_document_requirement_checker
  - agent_shared_evidence_verifier
  - agent_shared_document_editor
  - js_run
model: agentdefaultmodel
---

# Playbook Review

Use for criteria-based review of contracts, policies, procedures, controls, submissions, quality
standards, diligence checklists, governance requirements, or similar professional work.

The skill supports both:
- caller-provided criteria/playbooks; and
- one or more configured playbooks under `references/playbooks/`.

Configured playbooks are examples/reference workflows unless the user or an authoritative source makes
them controlling for the specific task.

## 1. Input and playbook selection

Require a source reference and at least one criterion source.

Priority:
1. Explicit caller-provided criteria/playbook text or file.
2. Explicitly named configured playbook(s).
3. A unique configured playbook match from `references/playbooks.json`.
4. If several configured playbooks plausibly match and `ask_user` is actually available, ask which
   playbook(s) to apply. If interactive clarification is unavailable, do not call `ask_user`; return a
   concise clarification need / blocked result instead. Do not silently select all.

When configured playbooks are needed, read the registry with `text_read` and load only the selected
playbook packages. Do not preload every playbook body.

Caller-provided criteria may contain id, heading, requirement, conditions, severity/priority, keyword
hints, source/provenance, and optional example drafting.

### Multi-playbook mode

A user may request several configured playbooks in one review. In that case:

- keep each playbook's identity and criterion ids;
- namespace or otherwise preserve criterion provenance so ids cannot collide;
- evaluate every selected material criterion once;
- do not merge distinct requirements merely because their wording overlaps;
- after evaluation, consolidate duplicate *findings* when the same source issue satisfies several
  criteria/playbooks, but retain all contributing playbook/criterion references;
- if edits/comments are requested, create one reconciled mutation plan across all selected playbooks
  to avoid duplicate or contradictory edits.

## 2. Reference-language and maintainer-comment rule

Configured playbook logic must not depend on literal source-language wording. Stable ids and the
substantive requirement meaning are controlling.

Maintainer-only HTML comments in reference Markdown (for example sample/distribution disclaimers) are
not review criteria and must never appear in findings, user-facing warnings, comments, tracked changes,
drafting, or ordinary runtime responses unless the user explicitly asks to inspect maintainer metadata.

## 3. Architecture

1. Normalize criteria without changing their meaning. For configured playbooks, preserve playbook and
   criterion provenance.
2. Call `agent_shared_document_requirement_checker` once per material criterion.
3. Keep only compact criterion results in the parent context.
4. Reconcile cross-criterion and cross-playbook conflicts; rank material findings.
5. Present findings grouped by playbook when that improves traceability, plus a short consolidated
   priority view when multiple playbooks were used.
6. If the user requested comments or edits, build one compact mutation plan from reconciled findings
   and delegate that plan plus the source reference to `agent_shared_document_editor`. Do not repeatedly
   edit/retry anchors in the parent context.
7. Accept the editor result only after reconciling applied and unresolved operations. If a file was
   requested, require an actual non-empty `final_file_path` returned after successful `word_save_as`;
   otherwise the file-producing portion is blocked.
8. Verify a bounded set of high-stakes factual assertions with `agent_shared_evidence_verifier` when needed.

## 4. Rules

- Example drafting is not controlling policy unless explicitly designated so.
- Do not invent a missing requirement from general practice.
- Do not perform external legal/compliance research merely because a sample playbook is incomplete.
- Do not pre-extract the full source merely to distribute it to workers.
- A review is analytically complete only when all selected material criteria have a status or a
  documented limitation.
- If the requested outcome includes an edited/commented Word file, the overall task is not complete
  until `agent_shared_document_editor` has produced a real final saved `.docx` copy.
- Do not restart failed edit anchors in the parent. The editor owns current-text refresh, exact-anchor
  recovery, and the per-operation retry cap.
- Once the editor reports an operation unresolved, that result is final for the run; the parent must
  not attempt the same anchor directly.
- Do not claim that the returned path was attached or delivered; the host controls that stage.

Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent
or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented
delivery-scheduling field. Those are host-side concerns.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

---
name: playbook-review
description: Reviews a document against a caller-provided checklist, policy, standard, control set, or playbook using one isolated requirement check per criterion.
allowed-tools:
  - agent_shared_document_requirement_checker
  - agent_shared_evidence_verifier
  - agent_shared_document_editor
  - js_run
model: agentdefaultmodel
---

# Playbook Review

Use for any criteria-based review: contracts, policies, procedures, controls, submissions, quality standards, diligence checklists, governance requirements, or similar professional work.

## Input
Require a source reference and a set of criteria. Criteria may contain id, heading, requirement, conditions, severity/priority, keyword hints, and optional example drafting.

## Architecture
1. Normalize and deduplicate criteria without changing their meaning.
2. Call `agent_shared_document_requirement_checker` once per material criterion.
3. Keep only compact criterion results in the parent context.
4. Reconcile cross-criterion conflicts and rank material findings.
5. If the user requested comments or edits, build one compact mutation plan from the reconciled findings and delegate that plan plus the source reference to `agent_shared_document_editor`. Do not repeatedly edit/retry anchors in the parent context.
6. Accept the editor result only after reconciling applied and unresolved operations. If a file was requested, require an actual non-empty `final_file_path` returned after successful `word_save_as`; otherwise the file-producing portion is blocked.
7. Verify a bounded set of high-stakes factual assertions with `agent_shared_evidence_verifier` when needed.

## Rules
- Example drafting is not controlling policy unless explicitly designated so.
- Do not invent a missing requirement from general practice.
- Do not pre-extract the full source merely to distribute it to workers.
- A review is analytically complete only when all selected material criteria have a status or a documented limitation.
- If the requested outcome includes an edited/commented Word file, the overall task is not complete until `agent_shared_document_editor` has produced a real final saved `.docx` copy.
- Do not restart failed edit anchors in the parent. The editor owns current-text refresh, exact-anchor recovery, and the per-operation retry cap.
- Once the editor reports an operation unresolved, that result is final for the run; the parent must not attempt the same anchor directly.
- Do not claim that the returned path was attached or delivered; the host controls that stage.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


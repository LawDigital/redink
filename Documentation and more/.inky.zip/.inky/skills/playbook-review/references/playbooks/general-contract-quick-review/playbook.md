<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# General Commercial Contract Review — Quick Check

**Perspective:** General commercial quick check

This sample is deliberately small and general. It is an initial screen, not a substitute for a contract-type-specific or transaction-specific playbook.

## Review criteria

### 1. Parties, subject matter and scope

The parties, subject matter, core obligations, dependencies, and material assumptions should be sufficiently clear and internally consistent.

### 2. Fees, taxes and payment mechanics

Pricing/fees, payment timing, invoicing, taxes, adjustments, and material additional charges should be understandable and operationally workable.

### 3. Term and termination

Commencement, duration, renewal, ordinary/extraordinary termination, and consequences of termination should be clear.

### 4. Quality, warranties and acceptance

Where relevant, service/performance standards, defect remedies, warranties, acceptance/testing mechanics, and related deadlines should fit the subject matter.

### 5. Liability

Exclusions, caps, indirect/consequential loss provisions, indemnities, and material carve-outs should be clear, consistent, and commercially intelligible.

### 6. IP and confidentiality

Rights in pre-existing materials and work product, together with confidentiality obligations, should be allocated clearly for the business model.

### 7. Data and security

Where personal, confidential, or business-critical data is involved, data roles, security requirements, and any required ancillary agreements should be identifiable.

### 8. Changes and subcontracting

Material changes to scope, change-control mechanics, and subcontracting should be controlled and transparent.

### 9. Governing law, disputes and notices

Governing law, jurisdiction/dispute resolution, and formal notices should be clear and operationally workable.

### 10. Boilerplate and consistency

Precedence, amendment/form requirements, assignment, force majeure, severability, and schedule/annex references should be consistent and free of obvious gaps where relevant.

<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# Source notes

This sample is jurisdiction-neutral. Industry-specific, competition, employment, privacy, trade-secret, export-control, and similar special issues are not automatically included.

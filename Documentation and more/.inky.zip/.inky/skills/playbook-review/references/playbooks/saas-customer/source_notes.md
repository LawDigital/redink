<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# Source notes

The appropriate risk weighting depends in particular on service criticality, data types, business model, exit dependency, and the applicable regulatory environment.

<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# SaaS / Cloud Agreement Review — Customer Perspective

**Perspective:** Customer

This sample focuses on common customer-side issues in SaaS/cloud agreements and can be combined with the general commercial quick-check playbook.

## Review criteria

### 1. Service scope and service levels

Functionality, availability, support, maintenance windows, measurement methods, and material service-level consequences should be clear and measurable.

### 2. Fees and unilateral changes

Fees, usage metrics, price changes, and changes to service scope/policies should be transparent and provide appropriate customer response options.

### 3. Customer data and usage rights

Ownership/rights in customer data, permitted vendor use, and rights in aggregated/anonymised data should be clearly separated.

### 4. Privacy and information security

Privacy roles, security requirements, sub-processing, and required ancillary agreements should match the actual data flows.

### 5. Security incidents and business continuity

Incident notification, backups, recovery, and relevant business continuity/disaster recovery obligations should be appropriate and operationally usable.

### 6. IP, third-party components and indemnity

Licence rights, third-party components, open-source/licensing risks, and appropriate protection against IP claims should be clearly addressed.

### 7. Warranties and liability

Warranties, liability caps, exclusions, indemnities, and carve-outs should align with data/operational risks and the commercial importance of the service.

### 8. Term, termination and suspension

Renewal, termination, suspension rights, and their triggers/consequences should be clear; critical services should not be unexpectedly withdrawn.

### 9. Exit, data portability and transition support

Data export, format, timing, deletion, transition assistance, and exit costs should be sufficiently addressed to manage lock-in risk.

### 10. Assurance, audit and regulatory requirements

Where relevant, certifications/evidence, audit rights, and customer-specific regulatory requirements should be supported in a practical manner.

<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# DPA Review — Customer/Controller Perspective

**Perspective:** Customer / controller

This sample supports a compact review of a data processing agreement from the customer/controller perspective. It is not a completeness review or legal opinion and contains only the approved sample criteria below.

## Review criteria

### 1. Scope, duration and documented instructions

The agreement should clearly state the subject matter and duration of processing, its nature and purpose, the relevant data/data subjects, and the processor's obligation to follow documented instructions.

### 2. Confidentiality and personnel

Persons authorised to process personal data should be subject to appropriate confidentiality obligations and receive access only as needed.

### 3. Technical and organisational security measures

Security obligations and applicable technical and organisational measures should be sufficiently concrete, reviewable, and proportionate to the relevant risks.

### 4. Sub-processors

Appointment and replacement of sub-processors should be transparent, with appropriate notice/approval mechanics and flow-down of equivalent obligations.

### 5. Assistance obligations

The processor should provide appropriate assistance with data subject rights, security incidents, data protection impact assessments, and other relevant controller obligations.

### 6. Data/security incidents

Notification channels, required information, and timing for data or security incidents should allow the customer to meet its own notification and response obligations.

### 7. International data transfers

International transfers and the mechanisms relied on should be transparent, internally consistent, and aligned with actual processing locations and sub-processors.

### 8. Return and deletion

At termination, return or deletion of personal data should be addressed, including practical exceptions, backups, and evidence where appropriate.

### 9. Information and audit rights

The customer should receive appropriate compliance information/evidence and have a workable audit or verification right that is not rendered ineffective in practice.

### 10. Liability and contractual precedence

Liability, indemnities, and the relationship between the DPA and the main agreement should be clear and consistent; unusual risk shifts should be highlighted.

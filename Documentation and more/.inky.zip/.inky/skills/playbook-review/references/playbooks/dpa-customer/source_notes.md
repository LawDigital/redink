<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction. -->
# Source notes

This sample does not contain organisation-specific or contract-specific negotiation positions. Before production use, the responsible expert should confirm the governing law, actual data flows, security requirements, and internal standards.

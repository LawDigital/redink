---
name: decision-brief
description: Produces a compact decision-oriented brief from supplied sources, bounded research, and an optional isolated second-pass challenge.
allowed-tools:
  - ask_user
  - agent_shared_large_document_analyzer
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - agent_advisor
  - js_run
  - create_word_document
  - create_pdf_from_text
model: agentdefaultmodel
---

# Decision Brief

Use when a professional needs to decide, recommend, approve, reject, prioritize, escalate, or choose between options based on evidence.

## Architecture
1. Define the decision, available options, decision criteria, and source set.
2. For large sources, delegate bounded extraction to `agent_shared_large_document_analyzer`.
3. Research only specific material gaps. Handle a single compact research gap directly when feasible; use `agent_shared_bounded_researcher` only when there are multiple separable research questions, isolation is needed to preserve context, or the user/workflow explicitly requests it.
4. Build a compact evidence matrix: fact, source, implication, uncertainty.
5. Draft a recommendation with alternatives and trade-offs.
6. For difficult/high-impact decisions, ask `agent_advisor` to challenge assumptions and failure modes using only the compact evidence supplied.
7. Reconcile the advisor result; do not copy it blindly.
8. Verify the most consequential factual claims with `agent_shared_evidence_verifier` when needed.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

## Output
Return a concise brief containing: decision/question, recommendation, decisive evidence, assumptions, risks, alternatives/trade-offs, unresolved issues, and next action. Clearly separate fact, inference, and recommendation.

If the user requests a Word/PDF file, actually create the final file with `create_word_document` or `create_pdf_from_text` in the host-provided working/session location and use the path returned by that successful tool call. A filename in prose is not sufficient. If the file cannot be produced, return `blocked` for the file-producing request. Do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


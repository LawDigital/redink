---
name: decision-brief
description: Produces a compact decision-oriented brief from supplied sources, bounded research, and an optional isolated second-pass challenge.
allowed-tools:
  - agent_shared_large_document_analyzer
  - agent_shared_bounded_researcher
  - agent_shared_evidence_verifier
  - agent_advisor
  - js_run
  - create_word_document
  - create_pdf_from_text
model: agentdefaultmodel
---

# Decision Brief

Use when a professional needs to decide, recommend, approve, reject, prioritize, escalate, or choose between options based on evidence.

## Architecture
1. Define the decision, available options, decision criteria, and source set.
2. For large sources, delegate bounded extraction to `agent_shared_large_document_analyzer`.
3. Research only specific material gaps with `agent_shared_bounded_researcher`.
4. Build a compact evidence matrix: fact, source, implication, uncertainty.
5. Draft a recommendation with alternatives and trade-offs.
6. For difficult/high-impact decisions, ask `agent_advisor` to challenge assumptions and failure modes using only the compact evidence supplied.
7. Reconcile the advisor result; do not copy it blindly.
8. Verify the most consequential factual claims with `agent_shared_evidence_verifier` when needed.

## Output
Return a concise brief containing: decision/question, recommendation, decisive evidence, assumptions, risks, alternatives/trade-offs, unresolved issues, and next action. Clearly separate fact, inference, and recommendation.

If the user requests a Word/PDF file, actually create the final file with `create_word_document` or `create_pdf_from_text` in the host-provided working/session location and use the path returned by that successful tool call. A filename in prose is not sufficient. If the file cannot be produced, return `blocked` for the file-producing request. Do not claim attachment/delivery unless the host confirms it.
Host-state rule: produce/finalize the real file and use the successful tool-returned path; do not invent or depend on `IsFinalDeliverable`, forced-delivery state, attachment state, or any invented delivery-scheduling field. Those are host-side concerns.


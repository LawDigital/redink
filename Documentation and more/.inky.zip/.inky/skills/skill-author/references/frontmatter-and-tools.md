# Frontmatter and tool rules (verified against the Red Ink host)

Source basis: the Red Ink host source (`AgentResources.vb`, `SkillInvokeTool.vb`, `TextTools.vb`, `ToolRegistryBuilder.vb`, `SubAgentRunner.vb`, `ThisAddin.Tooling.vb`) and `Red_Ink_Tool_List.md`, as of September 2026. If the host changes, the Tool List and a live test win over this file.

## 1. The Red Ink frontmatter dialect (not full YAML)

The loader uses the regex `^\uFEFF?---\s*\r?\n(.*?)\r?\n---` and then a minimal line parser (`ParseSimpleYaml`).

| Rule | What happens if you break it |
|---|---|
| `---` at character 0. Only a UTF-8 BOM may come before it. | No match: the resource is listed with no description and no tools. |
| One `key: value` per line. The value stays on the same line. | — |
| **No block scalars** (`>`, `>-`, `|`, `|-`). | The value stored is the literal `>-`. Continuation lines are dropped, and an indented line containing `:` becomes a stray key. The `skill_<name>` tool description then reads ">-". The validator accepts this, so the postcondition does not catch it. |
| **No inline comments** (`value  # note`, `- tool  # note`). | They are not stripped. `create_word_document  # report` becomes one bogus tool name. |
| Lists are either `key: [a, b, c]` on one line, or `key:` followed by `- a` / `- b` lines. | `ParseList` splits on **commas only**, so `allowed-tools: a b` becomes one tool named "a b". |
| No nested maps or indented keys. | They are flattened into stray top-level keys. |
| Quotes are optional. `"..."` or `'...'` are removed. | — |
| A colon inside a value is fine (the key ends at the first colon). | — |

**Name.** Use lowercase ASCII kebab-case (`^[a-z0-9]+(-[a-z0-9]+)*$`). It must be **identical to the skill folder name**, or to the agent's file stem (`agents\<name>.md`) or folder (`agents\<name>\AGENT.md`).
- Use the name the user gave. Hyphens are allowed for skills **and** agents: `AgentResources.ScanAgents` (`AgentResources.vb:586-617`) takes `name` from the frontmatter and falls back to the file stem or folder only when `name` is empty; there is no character check on the file name. Only the tool name is sanitised (next bullet). So `agents\zz-test-vertragsextraktor.md` with `name: zz-test-vertragsextraktor` is correct and is called as `agent_zz_test_vertragsextraktor`. Writing the file as `zz_test_vertragsextraktor.md` (V21-S03) breaks the name = stem rule without any benefit.
- Local resources override central ones by `name`, not by folder. A mismatch breaks shadowing and confuses maintenance.
- Tool names (`ToolRegistryBuilder.ToSafeToolSuffix` / `BuildAgentToolName`, `ToolRegistryBuilder.vb:30-75`): `skill_` or `agent_` + name, lowercased, with every run of non-alphanumeric characters turned into one `_`, and leading/trailing `_` removed. Non-ASCII letters become `u<hex4>` (so avoid umlauts). So `skill-author` becomes `skill_skill_author`.
- If two names sanitize to the same tool name, the later one silently wins.
- A skill folder must not contain another `SKILL.md` below it.

**Description.** The host uses it verbatim as the `skill_<name>` / `agent_<name>` tool description and in the skills list.
- Where it is shown (`ToolRegistryBuilder.AddSkills`/`BuildSkillStubConfig`: verbatim, no length cap; `ToolLoaderTool.vb`): the **bootstrap capability router** (`resolve_capability_route`, the first decision of every turn) shows up to **700 characters** (`ShrinkRouting(…, 700)`) and picks a skill "only when its description clearly matches the requested workflow/task type"; the lazy tool index (`tool_loader`, more than 8 tools) shows only the **first 120 characters** (`Shrink(…, 120)`).
- Write one line of at most 250 characters (hard limit 400; the lint warns above 250). Use up to 400 only when the router needs the extra trigger words (e.g. both German and English verbs).
- Name the task types as the user phrases them, in the user's languages ("prüfen", "check", "review" + the object). A bare verb list ("reviews, converts, diagnoses") is too vague: V25-S06 "Bitte prüfe den Skill im Ordner zz-test-flawed …" was routed `kind=none` ("keine klar passende … Route für eine allgemeine Skill-Prüfung eines lokalen Ordners") against the v2.5 skill-author description.
- Lead with the action verbs and objects a user would type. State the output.
- Mention a host only if the resource is restricted to it.
- Differentiate it from overlapping resources, because the router picks by description.

## 2. Keys the host reads

| Key | Applies to | Runtime effect | Verified at |
|---|---|---|---|
| `name` | all | Required. The override identity and the tool name. | AgentResources.PopulateFromMarkdown, validator |
| `description` | all | Required. The tool description and router text. | same |
| `allowed-tools` | all | The key is required, and `[]` is valid. **Skills:** enforced as the execution scope when entered via `skill_<name>` (all declared tools are auto-loaded; undeclared ones are rejected, except `report_progress`, `tool_loader` and `report_inability`). **Not** enforced when loaded via `skill_use`. Unknown names are silently dropped. **Agents:** hard dependencies; a missing one stops the run (`subagent_required_tool_missing`). | ThisAddin.Tooling.vb LoadSkillAllowedToolsFromResponse; AgentHost |
| `optional-tools` | agents | Used when present in the registry; missing ones are ignored. | SubAgentToolScopeInitializer |
| `model` | agents | Special-model label (default `agentdefaultmodel`). **Skills ignore it.** | SubAgentRunner |
| `canonical-source-tools` | agents | Canonical source `result_ref` contract. | SubAgentRunner |
| `enabled` | all | Default true. Any value other than `true/yes/on/1` **disables** the resource: it stays on disk but is hidden from the model. Omit the key; write `false` only on explicit request, or for a NOT VALIDATED script skill (SKILL.md §10). | ParseBool |
| `deliverable-count` | skills | Integer ≥ 0. A positive N makes `expected_artifacts` (exactly N `logical_deliverable_id`/`output_slot_id` pairs) mandatory on **every** invocation, and turns them into a hard completion and delivery contract. Use it only when the number of files is fixed. Omit it for answer-only skills. | SkillInvokeTool.ValidateDeclaredDeliverableContract |
| `required-successful-tools` | skills | Each named tool must succeed at least once before `complete` is accepted. There is no ordering or count. **Every name must also be in `allowed-tools`** (the validator rejects it otherwise). Split on `, ; space`. | validator; Tooling.vb |
| `deliverable-required-effects` | skills | Opaque host-verified effect ids that every final deliverable must prove, for example `content_mutated` (a plain `file_copy`/`file_move`/`file_rename` never satisfies it) or `worksheet_mutated.<sheet>` (sheet name lowercased; ä/ö/ü → ae/oe/ue; other separators → `_`). **Requires a positive `deliverable-count`.** Ids match `^[a-z][a-z0-9_.-]{0,63}$`. Declare an effect only when the task really requires that change. | validator; SkillInvokeTool |
| `network`, `timeout`, `required-successful-tools-before-final-mutation` | — | **No effect in current hosts.** Do not author them. `js_run` network access is the per-call `allow_network` argument. | grep: no consumer |

Any other key (for example `trigger-keywords`, `version` or `tags`) is silently ignored. Remove it.

## 3. `allowed-tools`: the dependency contract

Before writing, build the table `workflow step → tool → host(s) → required/optional` internally. Then derive the smallest complete list:

- It reads `references/` or `scripts/` → `text_read`.
- It ships `scripts/*.js` → `js_run`. Declare `js_run` only if a script or a named deterministic computation exists.
- It reads the primary input → a reader that is valid on each target host:
  - Outlook and AutoPilot, **mail attachments**: `list_attachments`, `read_attachment`, `extract_pdf_text`, `read_word_document_details` (by `attachment_name`; a local file gives "Attachment not found", V214-S20). **A file on disk** (also one the skill created): `word_extract_text` (path), `text_search`.
  - Word: `worddoc_extract_text` for the open document, or `word_extract_text` for a file.
- It produces a file → the actual finalizer, for example `create_word_document` (Outlook/AutoPilot), `word_save_as`, `create_excel_spreadsheet` or `excel_complete_live_workbook`.
- It asks the live user → `ask_user`. The body must say what happens in AutoPilot, where `ask_user` is a no-op.
- It delegates → `agent_<name>`. That agent must exist, or be written in the same run.
- Online sources → the family wildcard (`swiss-caselaw*`) or `selected_online_sources`. Their tools (e.g. `get_regeste`, `fetch_document`) have no Tool List row; for the lint give the declared entry `"YYN"` in `D.tools` (V24-S16 declared the individual names and ended with four `tool_unverified` errors).
- Wildcards are expanded against the tools selected for the run. Use them only for online-source families. **Never `*`.**
- `tool_loader`, `report_progress` and `report_inability` are always available to a loaded skill, so declaring them is redundant. Note that `report_inability` is not available in Word.
- `python_execute` is **not** a foundation dependency; it exists only when the external helper is installed.
- A reviewing step that removes a tool must re-check that each workflow step still has a declared tool.

## 4. Reading `Red_Ink_Tool_List.md` completely

The file is about 30 KB.
- `text_read` with `max_chars` returns at most that many characters. Current builds also return `has_more`, `next_offset` and `total_chars`, and accept `start_char` (alias `offset`).
- **Preferred: one `text_search` call** with `regex: true` and all the tools in one alternation:
  ~~~
  \|\s*`(ask_user|text_read|list_attachments)`\s*\|[^\n]*
  ~~~
  The `match` field returns the complete table row, ending `| Yes | Yes | No |` (Word | Outlook | AutoPilot). The 40-character `context` window is too short for that. This was tested against the September 2026 list. In run V2-S01 it returned all 7 requested rows in one call. If the backticks are dropped, the pattern matches empty strings and heading fragments instead. That happened in run V2-S02, where 8 searches returned nothing usable.
- **Complete read:** call `text_read {path, max_chars: 15000, start_char: 0}`, then repeat with `start_char = next_offset` until `has_more` is false. **Omit `expected_snapshot_sha256`.** In V2-S01 the model copied the snapshot hash wrongly, and page 2 failed with `source_hash_mismatch`. If the result carries no `has_more` field, the build is older: call `text_read {path}` without `max_chars`, which returns the whole file.
- `context_expand` re-serves the stored tool result. It cannot read past the `max_chars` a `text_read` was given, but it is the only way to see a result over about 4,000 characters, which the host replays as a ~800-character preview plus `result_ref` (V24 logs: `compacted=true`). So each page of a complete read needs one `context_expand`; prefer the `text_search` above.
- Columns: **Word**, **Outlook** (Outlook Local Chat / agent mode) and **AutoPilot**. For the lint (SKILL.md §12), pass the rows you verified as `"tools": {"tool": "YYN", ...}` (Word/Outlook/AutoPilot). The lint has no built-in snapshot, so a declared tool without a row is reported as `tool_unverified`.
- The file lives in **`central_root`** (`C:\...\.inky\Red_Ink_Tool_List.md`), not in `local_root`: every V23 run lost a call on `not_found` there.

Host availability traps (September 2026 list; re-verify):

| Tool family | Word | Outlook LC | AutoPilot |
|---|---|---|---|
| `ask_user`, `memory_*`, `m365_*`, `skill_use`, `report_progress`, `web_content_retriever` | Yes | Yes | **No** |
| `worddoc_*`, `word_doc_*` | Yes | **No** | **No** |
| `word_verify_revisions` | Yes | No | No |
| attachment tools, PDF tools, `create_word_document`, `create_excel_spreadsheet`, `excel_*`, `agent_workspace_*`, `report_inability` | **No** | Yes | Yes |
| `summarize_thread` | No | No | Yes |
| `text_*`, `file_*`, `workspace_*`, `word_*` (file on disk), `js_run`, `tool_describe`, `context_expand` | Yes | Yes | Yes |

There is **no mail-send tool**. AutoPilot answers the sender through host delivery.

## 5. `text_write` for resources

The schema offers `path`, `filename`, `text`, `mode` (`overwrite` | `append` | `create_new`) plus optional artifact fields. For skill and agent files, use the **fixed argument set in SKILL.md §4**: a complete, stable id triple, `artifact_state: working`, `artifact_delivery_intent: none`, `storage_kind: host_managed` and `expected_artifacts: []`. Here is why:
- **Pre-check (runs before execution):** `ToolCallSequencing.ValidateExplicitArtifactIdentityArguments`. It treats a key as present when it exists and is not null, **including `""`**. If any of `artifact_id`, `logical_deliverable_id`, `output_slot_id` or `supersedes_artifact_id` is present, all three ids must be non-empty, or the call fails with `explicit_artifact_identity_incomplete`. The model tends to send `supersedes_artifact_id: ""` on its own, so "leave the fields out" failed in practice: 16 of 19 writes were rejected in V2-S01, and the first write in V2-S02 and in S03.
- If `artifact_id` equals `supersedes_artifact_id`, for example `"ignore"`/`"ignore"`, the call fails with `explicit_artifact_self_supersession` (V2-S02).
- A rejected write stays an **unresolved failure**. A later successful write with a different id scope did not clear it in the deployed host (V2-S01, V2-S02, S03). Every final `complete` answer is then rejected (`complete_with_unresolved_tool_failure`).
- A successful write carrying a **non-empty** `expected_artifacts` registers expected slots (`RegisterExpectedDeliverablesFromArguments`). A `working` resource file never becomes a Final, so delivery throws "expected-artifact contract is incomplete; automatic delivery of a partial sibling set is blocked" (`ArtifactDelivery.ResolvePathsForDelivery`), and the Local Chat UI shows no answer at all.
- `expected_artifacts: []` declares an empty contract with no slots. Delivery and completion then need no Final (`HasAllExpectedDeliverableSlots` with 0 slots; `RequestRequiresCreatedDeliverable` stays false).
- Placeholder values such as `"omit"` shared by several files create duplicate identities (`invalid_explicit_artifact_result`). Use one id triple per file.
- The host does not invent this contract. Skill-author's own invocation returns `declared_deliverable_count: 0` and `expected_artifacts: []`, which lock nothing. The slots came only from the model's `text_write` arguments.

Other `text_write` facts:
- It writes UTF-8 (with a BOM) and creates parent folders.
- An omitted or relative path resolves to the workspace, then staging, then the **Desktop**. That is never the resource tree.
- The default `mode` is overwrite.

## 6. Host values and resolution for authored skills

`resource_index.host` is one of the following:
- `Word`
- `Outlook Local Chat` (Local Chat agent mode)
- `Outlook` (another interactive Outlook tooling surface)
- `Outlook AutoPilot`
- empty (sub-agents, or no provider)

Branch on this value. Use a capability probe only when it is empty. Deciding the host because `ask_user` is present is wrong, because Word also has it. Excel is never a host: Excel workbooks are handled by the Excel tools listed above.

## 7. Skills vs. agents

- A **skill** is loaded into the shared conversation (`skill_<name>` or `skill_use`) and guides later steps. Use it for user-facing, multi-step workflows.
- An **agent** (`agent_<name>`) runs isolated on the secondary model. It receives `task` (+ `context`) and never sees the conversation or Inky.md.
  - Required call arguments: `task`, `subagent_task_id` (stable per logical task) and `expected_artifacts` (`[]` for analysis-only work).
  - Its final text must be a single JSON object. Anything else becomes `agent_empty_result`, with one retry.
  - The parent receives `{summary, result, resultKind, agent, memory_key, stub}`.
- A single-file agent (`agents\<name>.md`) has `agents\` as its resource directory, so it shares `agents\references\`. Use `agents\<name>\AGENT.md` when the agent needs its own references.
- A resource written in this run cannot be called as `skill_<name>` / `agent_<name>` until the next run, because the registry is built once per run.

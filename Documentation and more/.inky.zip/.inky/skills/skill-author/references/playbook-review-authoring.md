# Authoring recipe — playbook-review reference library

## Scope

Use this recipe when authoring configured playbooks for the generic `playbook-review` skill. The
skill-author core remains generic; this file defines the reference-library convention.

## Source model

Each configured playbook package uses:

- `playbook.md` — normative, human-readable criteria and drafting guidance;
- `criteria.json` — derived executable representation;
- `source_notes.md` — provenance, version, assumptions and maintenance notes;
- root registry `references/playbooks.json` — discoverability, aliases and file paths.

A subject-matter expert should normally review `playbook.md`, not JSON.

Maintainer-only HTML comments in sample files are distribution metadata and must never be returned as
review findings, model warnings, comments, edits or ordinary runtime text.

## Multi-playbook behavior

The runtime may apply one or several configured playbooks to the same source. Preserve each playbook's
identity and criterion ids. Do not merge two criteria merely because they use similar words. After
criterion evaluation, duplicate *findings* may be consolidated for presentation/editing when the same
source issue satisfies several playbooks; preserve all contributing playbook/criterion provenance.

## Create / revise / synchronize

1. Read the playbook-review `SKILL.md` and registry.
2. Maintain the expert-approved rule set in `playbook.md`.
3. Compile each criterion into `criteria.json` with stable ids, heading, requirement, conditions,
   severity/priority, optional keyword hints and optional example drafting.
4. Keep example drafting non-controlling unless `playbook.md` explicitly marks it controlling.
5. Register/update the playbook in `playbooks.json` with narrow aliases and a useful description.
6. Preserve stable ids on wording-only changes.
7. Do not invent missing negotiation positions or legal requirements. Ask the expert when material.
8. Validate JSON, unique ids, registry paths and traceability of each criterion to `playbook.md`.

## Recommended Red Ink prompts

Create:

> Create a new sample playbook for the playbook-review skill from the attached checklist. Keep `playbook.md` authoritative, derive the technical criteria file, and register the playbook. Do not invent additional review criteria.

Revise:

> Here is the revised source for playbook `<id>`. Synchronize the existing sample, preserve stable criterion IDs where the substantive criterion is unchanged, and show which review criteria changed substantively.

How-to:

> Briefly explain which copy/paste prompt and source file I should give Red Ink to create a new playbook or update an existing one. Do not modify anything yet.

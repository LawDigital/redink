# Templates

Copy a skeleton, fill in every `<...>` and delete the sections that do not apply. Write the body in the user's language or in English. Keep the frontmatter rules from `frontmatter-and-tools.md`.

These templates deliberately contain **no literal task-status envelope**. Keep it that way: describe the footer in words.

---

## A. Skill (SKILL.md)

~~~~markdown
---
name: <kebab-name identical to the folder>
description: <Verb + object + output in one line, max 250 chars; trigger words in the first 120; host only if restricted>
allowed-tools: [<only tools used below, each verified for every supported host>]
---

# <Title>

## Purpose
<One paragraph: what the skill does, for whom, and the result.>
Use when: <typical requests>. Do not use for: <near misses; name the overlapping skill if one exists>.

## Supported hosts and gate
Supported: <Outlook Local Chat | Word | Outlook AutoPilot>.
Step 0: read `resource_index.host`. If it is not one of the supported hosts, stop and end with the
TASK_STATUS footer, status blocked, reason "<skill> runs only in <hosts>". If a required tool
(<list>) is not available, stop the same way; never substitute another tool or guess.

## Inputs
- <Input 1>: <where it comes from> - read it with `<tool>`.
- If <required input> is missing, or there are several candidates, do not guess: say exactly what is
  missing, ask the user to attach or drop the file and send again, and end with the TASK_STATUS footer,
  status blocked. (Never request a file through ask_user - it cannot receive files.)
- Clarifications that change the result: ask with `ask_user`, one question per call.
  <AutoPilot branch, if AutoPilot is supported: do not ask; state the missing point in the reply and block.>

## Workflow
1. <Step> - `<tool>` <exact arguments that matter>.
2. Read `references/<criteria>.md` with `text_read` (absolute path from this skill's references inventory).
3. <Step per criterion / per document ...>
4. <Deterministic step? -> see section C: run `scripts/<x>.js` with `js_run`; never compute by hand.>
5. <Output step - finalizer tool, file name, report the returned path.>

## Output
<Exact format: table columns, order, lengths, language. For files: `<finalizer tool>`, file name
`<name.ext>`, report only the path returned by the tool.>
<For legal content:> Add: "Entwurf - vor Verwendung durch eine Anwältin / einen Anwalt zu prüfen." (or the
English equivalent).

## Limits and safe failure
- Never invent facts, provisions or values. Mark any uncertain point as "zu verifizieren".
- Tool unavailable, input missing, script error -> blocked with a precise reason; no partial result
  presented as complete.
- End every final answer with exactly one TASK_STATUS footer (complete or blocked). Never quote a
  footer anywhere else.
~~~~

Every authored skill must contain (SKILL.md §7):
1. Purpose, and when (not) to use it.
2. Supported host(s), with a **first step that checks `resource_index.host`** (`Word`, `Outlook Local Chat`, `Outlook`, `Outlook AutoPilot`, or empty in a sub-agent) and blocks on unsupported hosts. Never infer the host from `ask_user` being present.
3. Inputs, each with the tool that reads it. A missing required file ends blocked with a request to attach it and resend; never ask for a file through `ask_user`.
4. A numbered workflow; every step names its tool.
5. The output format. For files: the finalizer tool, the file name, and "report the path the tool returned".
6. Safe failure: a tool is unavailable, an input is missing or a script fails → block with a reason, never guess. Describe the footer in words.
7. No restating of Inky.md, only deviations. The runtime replies in the user's language.

Checklist while filling in the template:
- The folder name and `name:` are the user's kebab-case name exactly (SKILL.md §3).
- Every tool named in the workflow appears in `allowed-tools`, and nothing else does.
- Every `references/...` / `scripts/...` file named in the body exists.
- Criteria live in `references/` with their article references. The body only says how to apply them.

---

## B. Sub-agent (`agents\<name>.md`, or `agents\<name>\AGENT.md` when it needs its own references)

~~~~markdown
---
name: <kebab-name identical to the file stem / folder>
description: <What the agent returns, in one line>
allowed-tools: [<hard dependencies only; may be empty: []>]
optional-tools: [<host-dependent helpers, e.g. read_attachment, js_run>]
---

# <Title>

## Mission
<One bounded job. The agent does NOT see the conversation or Inky.md; everything it needs arrives in
`task` (and `context`).>

## Task input (from the parent)
<Exact KEY: value lines the parent passes, e.g. SOURCE_TEXT, FIELDS, LANGUAGE.>

## Rules
- Use only the exposed tools. Never ask the user; return missing information instead.
- Do not invent values. Unknown -> "nicht gefunden" / null with a reason.
- <Budget, e.g. at most 2 reads per document.>

## Output (binding)
Your FINAL message is exactly ONE JSON object and nothing else (no prose, no Markdown fence):
{"status":"ok|insufficient|failed","summary":"<one sentence>","result":{<schema>},"missing":[<items>]}
- ok: the job is done. insufficient: the input lacks what is needed (list it in "missing").
  failed: a tool error prevented the job (explain it in "summary").
~~~~

File name: `agents\<name>.md` with the kebab-case `<name>` the user gave (hyphens allowed), e.g. `agents\zz-test-vertragsextraktor.md` with `name: zz-test-vertragsextraktor`. The host derives the tool name `agent_zz_test_vertragsextraktor` itself (`ToolRegistryBuilder.BuildAgentToolName`); never use that underscore form as the file name.

The parent skill calls `agent_<name>` with `task` (all the data), `subagent_task_id` (stable per logical task, for example `<skill>-<doc>-1`) and `expected_artifacts: []` when the agent returns data only. The parent declares `agent_<name>` in its `allowed-tools`, and still works or blocks cleanly when the agent is unavailable.

---

## C. Script-backed skill: the section to put into SKILL.md

~~~~markdown
## Calculation (deterministic - never compute by hand)
1. Read with `text_read`: `scripts/<x>.js` and `references/<data>.json` (absolute paths from the
   inventory). Do not read references/testcases.json at runtime.
2. Call `js_run` with ONLY the `code` argument, built from exactly these 3 parts:
   const INPUT = {"<field>": "<value>", ..., "refs": {"<data>": <references/<data>.json pasted as JSON>}};
   <full text of scripts/<x>.js, pasted verbatim as code>
   return run(INPUT);
   Allowed values: <field>: <enum / format, e.g. "2026-03-25" as a quoted ISO date>, ...
   Write every INPUT value as JSON (strings in double quotes). The script text goes in as code,
   exactly as read: never inside backticks, quotes, String.raw, eval or new Function. Always pass
   every reference data file in "refs"; the script has no built-in copy of that data.
   Correct: const INPUT = {"<field>": "<value>", "refs": {...}};  function run(INPUT) {...}  return run(INPUT);
   Wrong:   const script = (backtick) function run ... (backtick);  eval(script);
3. Use only the values in the js_run result. Show the answer field (<answer field, e.g.
   massgebendes_fristende>) first, then the intermediate values. If the result has "error", report it.
4. If js_run is unavailable or returns ok:false, stop: TASK_STATUS footer, status blocked, reason
   "deterministic calculation unavailable". Never estimate or calculate yourself.
~~~~

## D. Script file skeleton (`scripts/<x>.js`)

~~~~javascript
// <x>.js - <what it computes>. Runs in js_run (browser sandbox, no Node APIs; never write them, not even in a comment).
// INPUT: { <field>: <type, allowed values, format>, ..., refs: { <data>: <shape> } }
// OUTPUT: { <answer field>: <the value the user acts on, never null>, <intermediate fields>, ..., notes: [<string>] }
//         or  { error: "<reason>" } for invalid input.
// Rules implemented: <cite the provisions, e.g. Art. 142-146 ZPO>, one comment per rule branch.
function run(INPUT) {
  if (!INPUT || typeof INPUT !== "object") return { error: "INPUT missing" };
  if (!INPUT.refs || !INPUT.refs.<data>) return { error: "refs.<data> missing" };
  // validate every field and enum first; return {error} instead of throwing
  // ... pure, synchronous computation only; every loop bounded, e.g. for (var g = 0; g < 4000 && ...; g++) ...
  return { /* result */ };
}
~~~~

- **Pure and synchronous.** `run(INPUT)` returns a value that depends only on `INPUT`: no I/O, no `await`, no global state, no `Date.now()` / `new Date()` without arguments, no randomness. Helper functions are fine; keep them at top level or inside `run`, and indent every function body (no `return` at column 0 outside a function).
- **Bounded loops.** Every `while`/`for` has a hard iteration cap and returns `{error}` when the cap is hit. An unbounded date loop froze V23-S04's test call until the 20 s timeout.
- **Data as JSON, never as template strings.** Template literals are allowed only for building short output strings, never to hold data or file text.
- **Compact.** Aim for under 8 KB with short comments; the script is typed again in the test call and at every runtime call.

- **Reference data only from `INPUT.refs`.** Read holidays, suspension windows, rates and similar data from `INPUT.refs.<data>`; never hard-code a copy in the script. If a needed entry is missing, return `{error: "refs.<data> missing"}`. The harness (§G) checks this with its `refsUsed` probe. Every file under `references/` must be consumed (by the script via `refs`, or by a workflow step that reads it); delete files nothing uses. V22-S04: the script hard-coded the ZH holidays and ignored `holidays-zh-2026-2027.json` and `stillstand-zpo.json`, so editing the JSON (e.g. adding 2028) would have changed nothing.
- **Month and year periods are anchored on the triggering event** (e.g. the service date), not on the first running day, unless the statute says otherwise; see the domain note in §E.
- **Apply every rule to every unit it covers.** If a rule applies to days and months (e.g. a suspension of time limits), implement it for both, or return `{error: "unsupported: <combination>"}` and document the limit. Never let one branch silently skip a rule: in V22-S04 month deadlines never consulted the suspension windows and came out 16-32 days early, some ending inside a suspension period.
- Dates: use UTC (`Date.UTC`) and ISO strings, never local time.
- Check that the reference data covers the days the calculation **actually inspected**: a holiday list is needed only for the days the end-day shift looks at (raw end … final end); suspension windows computed from rules (fixed dates, Easter) need no year list. Return an `error` if an inspected day's year is missing. Never use a fixed margin such as `start + 800 days` (V21-S04: 2028 data demanded on every input, 22 of 23 cases blocked) or "nominal end year + 1" (V27-S04: 31.01.2027 + 1 month → `error`).
- **One answer field, always filled.** The result names the value the user acts on in one field (`massgebendes_fristende`, `final_deadline`, `total_due`) that is never `null` on success: equal to the adjusted value if an adjustment happened, else to the raw value. Never make the caller combine `verschobenes_fristende: null` with `rechnerisches_fristende` (V28-S04: every date right, no final date on 4 of 8 checks).
- The script source must contain no `require(`, `module.exports`, `__dirname`, `__filename` or `process.` pattern, not even in comments. The host rejects any js_run code that contains them.
- Record the reason for each shift at the point where it happens (e.g. the list of skipped days with their names). A single "reason" variable that each loop pass overwrites names the wrong day.

## D2. Calendar-period engine (deadlines, notice periods, limitation periods) - SHIPPED, do not write it

**For any deadline/period/calendar calculation skill, do NOT write the engine yourself.** `file_copy` `<skill-author dir>\references\calendar-engine.js` (exact path from this skill's `references[]` inventory) → `<new skill>\scripts\calendar-engine.js`, unchanged. Then write only (a) the jurisdiction data JSON and (b) SKILL.md's `js_run` call contract (§C: `const INPUT = {...};` + the engine text as code + `return run(INPUT);`). Then run the test harness (§G, the engine text as the script) with the mandatory anchors (must pass), then the lint. Every hand-written S04 engine (V24-V212) broke anchors.

Contract (header of the file has the detail): `INPUT = {service_date: "YYYY-MM-DD", amount: <int>, unit: "days"|"months", procedure: "<string>", refs: {holidays: <data>, suspension: <data>}}` → `{fristbeginn, stillstandstage, stillstand_daten, rechnerisches_fristende, massgebendes_fristende (answer field, never null), verschoben, verschiebungsgrund}` or `{error}`.

Data files (the only jurisdiction-specific part), e.g. Swiss ZPO, Gerichtsort ZH:
- `references/feiertage-zh.json`: `["2026-01-01", "2026-01-02", "2026-04-03", ...]` or `{"years": [2026, 2027], "dates": {"2026-08-01": "Bundesfeier", ...}}`; every year the end-day shift may inspect (a missing year returns `error`).
- `references/stillstand-zpo.json`: `{"windows": [{"label": "Osterstillstand", "easter_from": -7, "easter_to": 7}, {"label": "Sommerstillstand", "start": "07-15", "end": "08-15"}, {"label": "Weihnachtsstillstand", "start": "12-18", "end": "01-02"}], "no_suspension_procedures": ["summarisch"]}` (Easter is computed by the engine; `end < start` crosses the year end; absolute ISO windows also work).

The model the engine implements: event day not counted; days run from the next day, not inside a suspension window; months: nominal end = event day + n months (clamped, 31.01. + 1M = 28.02.), L = calendar days first running day → nominal end, then L running days skipping suspended days; a Saturday/Sunday/holiday end moves to the next working day. Verified (v2.13, headless Edge, tools\check_suite.py adapter): all 8 S04 checker cases (a, b, c, d, A, B, C, i) with three holiday data shapes. Rules it does not model (e.g. Art. 145 Abs. 2 lit. a, service inside a window with a month deadline = "zu verifizieren") are documented in the authored SKILL.md; never patch the engine.
## E. Test cases (`references/testcases.json`)

Write this file **before the first test run**, in the same batch as the reference data files (not the script). Keep it compact (at most about 12 cases): it is typed in every test call. `expected` lists only the keys you check, using the script's **exact output keys**, with dotted paths for nested values (e.g. `"verschobenesFristende.date"`). **Every computed case asserts the answer field** (the tail checks it, §G). Assert lists by length and single elements (`"stillstandstage.length": 32`, `"stillstandstage.0": "2026-07-15"`), never as a whole array: V28-S04's four 32-date arrays made each test call ~2 KB longer. For an invalid-input case, `{"error": "<text>"}` passes when the result has any `error`.

### Independent oracle (binding for every computed case)

The test is worth nothing if the expected values come from the same reasoning as the script. V25-S04: the first test call failed 3/11, and two of the failures were the author's **correct** month cases (`t4` expected 31.08.2026, got 02.09.; `t5` expected 21.08., got 22.08.→24.08.). The author then rewrote both expectations to the script's output, with new `why` texts copying the script's logic ("nominales Monatsende ab 01.07. ist 01.08."); the second call passed 11/11 and the wrong script shipped as validated.

1. **Derive by hand, in writing, before the script runs.** Every case without an expected `error` has a `derivation` field (one line, about 60-300 characters) with the **explicit step-by-step count**: the rule applied at each step, each intermediate date, the days counted in each stretch, and the sum. Example: `"30.06.+1M=30.07. (Art.142 II), L=30 d from 01.07.; run 01.-14.07.=14; still 15.07.-15.08.; 16 left: 16.-31.08.; 31.08. Mo, no holiday -> 31.08."`. "ergibt sich aus dem Monatsende" is not a derivation. The test tail (§G) lists cases without one as `underived`, and the script is then not validated.
2. **Never from the script.** Do not run the script, reuse its helper logic, or read its output to fill in `expected` or `derivation`. Count calendar days yourself, on the rule text.
3. **Mismatch = the script is suspect first.** Re-count the failing case by hand, in writing. Change an `expected` value only if the re-count finds a concrete slip in your own derivation (name it: "t2: counted 11.-14.07. as 2 days, is 4"). **Never change an expectation to the actual value because the script produced it**, and never rewrite a derivation to describe the script's method. A case you cannot re-derive to the actual value stays as it is: fix the script, or ship NOT validated.
4. **Mandatory reference cases are immutable.** Cases whose values this skill prescribes (SKILL.md §10, e.g. 30.06.2026 + 1 month → 31.08.2026) carry `"anchor": true`; their `expected` is copied, never edited. A failing anchor always means the script is wrong.
5. **One case per interaction.** Besides one case per rule, at least one case wherever two rules act on the same calculation (see the matrix below), each with its own hand count.

~~~~json
{
  "script": "scripts/<x>.js",
  "cases": [
    {"id": "t1-typical", "input": {...}, "expected": {"<outKey>": "<value>"}, "derivation": "<rule>: <step-by-step hand count>"},
    {"id": "t2-anchor-i", "anchor": true, "input": {...}, "expected": {...}, "derivation": "<copied reference case, with the count>"},
    {"id": "t3-boundary-y", "input": {...}, "expected": {...}, "derivation": "boundary of rule y: ..."},
    {"id": "t4-invalid", "input": {...}, "expected": {"error": "..."}, "derivation": "invalid input"}
  ]
}
~~~~

### Case matrix (build it before writing any case)

One boundary per rule is not enough: bugs sit where two rules meet. V22-S04 passed 7/7 own tests but shipped month deadlines that ignored the suspension periods, because no case combined "month deadline" with "suspension".

1. **Rows = rules.** Every rule the user named, each exception, and each exception of the same provision the user did not name (mark those supported / excluded / "zu verifizieren").
2. **Columns = units and variants.** Every value of every input that changes the computation: days **and** months (and weeks/years if accepted), each procedure type, each place/canton, each input kind.
3. **Cells.** One case per applicable rule × variant cell. A cell the script does not support gets a case that expects `error`.
4. **Interactions.** One case per pair of rules that can act on the same calculation, e.g. suspension × month deadline, suspension × weekend/holiday shift, end-of-month rule × suspension, service inside a window × day deadline **and** × month deadline, exception branch × window.
5. **Boundaries.** For each rule, the first and last day it applies, and one day outside.
6. **Invalid and unsupported.** At least one invalid input and one input outside the supported scope (other canton, uncovered year).
7. **Every asserted field.** For each case, assert every output field the skill shows the user (e.g. start date, list of suspended days, raw end, shifted end, reason), not only the final result. Each assertion is derived from the rule text.

Write the matrix into the `derivation` texts (cell id + hand count), and list uncovered cells as open points in the final answer.

Coverage minimum:
- at least 3 cases, and at least one per matrix cell and per interaction;
- **one boundary per rule**;
- one invalid and one unsupported input.

For date and deadline calculators (e.g. Art. 142-146 ZPO), the matrix contains at least:
- a year boundary;
- a month end: day 31 into a shorter month, February, and service on the 28th/30th;
- the first **and** last day of each suspension window;
- **a month deadline whose running period spans a suspension window** (suspended days are added; the end must not fall inside a window);
- **a month deadline whose computed end falls inside a window**;
- derivation for both: see the domain note below. **Anchor cases:** the six Zürich anchors A1-A6 in SKILL.md §10 (month × summer window 30.06./20.06.2026 + 1M → 31.08./21.08.2026; month end 31.01.2027 + 1M → 01.03.2027; days × summer window + weekend 01.07.2026 + 20 d → 24.08.2026; summary, no suspension 01.07.2026 + 20 d → 21.07.2026; holiday chain 15.12.2026 + 10 d summary → 28.12.2026), copied with `"anchor": true`. Sanity check: an expected end (before the weekend/holiday shift) inside a window is always wrong (V24-S04 `t5` expected 26.07.2026);
- service inside a window (Art. 146 type) with a **day** deadline **and** with a **month** deadline, asserting the displayed start (first day after the window) and that suspended days before the start are not listed. The month end for service inside a window is disputed (for service 20.07.2026: anchor = last window day 15.08. → 15.09.2026, or anchor = first running day 16.08. → 16.09.2026): mark it "zu verifizieren" and name the reading the script uses;

**Domain note: month deadlines with suspension (Art. 142 Abs. 2, 145, 146 ZPO and similar regimes).**
1. **Month anchor = the day of the triggering event (service), not the first running day.** Art. 142 Abs. 1 does not count the day of service; the month rule then ends the period on the day with the same number as the service day: 30.06. + 1 month = 30.07.; 31.01. + 1 month = 28.02. (last day of the month). Adding the month to the first running day (01.07. + 1M = 01.08.) is one day too long, and the suspension then makes it worse: V25-S04 returned 02.09.2026 instead of 31.08.2026 for exactly that reason.
2. **Convert to the running-period model.** L = calendar days from the first running day to the nominal end (30.07.: L = 30). Count forward from the first running day, **skipping every suspended day**, until L days are consumed; that day is the raw end. Then apply the weekend/holiday shift (Art. 142 Abs. 3).
3. Equivalent shortcut: nominal end + the number of suspended days between the first running day and the nominal end, those extra days again counted only on non-suspended days (30.07. + 16 suspended days in 15.-30.07. → 16 running days from 16.08. → 31.08.). Do **not** just add the whole window length to the nominal end: it is right only when the whole window lies inside the running period and the extension does not reach another window, and wrong when the nominal end falls before the window or the start inside it.
- each exception branch (e.g. summary proceedings, Art. 145 Abs. 2 lit. b) with both units; conciliation (Art. 145 Abs. 2 lit. a) as supported or as `error`;
- a holiday followed by a weekend, and a shifted end after a window;
- a deadline that ends in the last covered year, and one that would need the next (expects `error`).

## F. AutoPilot variant (only if the user targets AutoPilot)

- Every tool must be `Yes` in the AutoPilot column. Do not use `ask_user`: missing information goes into the reply and the run blocks.
- If the skill always returns a fixed number of files, set `deliverable-count: N` and name the finalizer for each file. Optionally list the finalizer in `required-successful-tools`; it must also be in `allowed-tools`.
- Hand-off text for the user: see `host-surfaces.md` §4 (select the skill for the AutoPilot session, sender policy, restart, test mail).

---

## G. Script test call (one `js_run` call runs every case)

`code` = exactly these 5 parts, in this order, and nothing else. Parts 1-3 are JSON you write, part 4 is the script **as code**, part 5 is the TEST TAIL copied exactly. `timeout_ms: 30000`.

~~~~javascript
const __CASES = <the "cases" array of references/testcases.json, as JSON>;
const __REFS = {"<data>": <references/<data>.json as JSON>, "<data2>": <...>};
const __FINAL = "<the answer field, e.g. massgebendes_fristende>";   // "" only for a script without a single answer value
<the full text of scripts/calendar-engine.js (§D2), as code; it defines run(INPUT)>
<the TEST TAIL below, copied exactly>
~~~~

TEST TAIL (skill-author test tail v2.9, about 2 KB, no backticks):

~~~~javascript
// ===== skill-author test tail v2.9 - copy exactly, below the script =====
function __get(o, k) { var p = String(k).split("."), i; for (i = 0; i < p.length; i++) { if (o == null) return undefined; o = o[p[i]]; } return o; }
function __run(inp, refs) { var x = {}, k; for (k in inp) x[k] = inp[k]; x.refs = refs; try { return run(x); } catch (e) { return {error: "THROWN: " + e.message}; } }
function __s(v) { v = JSON.stringify(v); return v && v.length > 90 ? v.slice(0, 87) + "..." : v; }
var __fail = [], __pass = 0, __used = true, __nod = [], __anc = [], __nA = 0, __i, __c, __a, __k, __bad, __f;
for (__i = 0; __i < __CASES.length; __i++) {
 __c = __CASES[__i]; __a = __run(__c.input, __REFS); __bad = []; if (__c.anchor) __nA++;
 if (!("error" in __c.expected)) {
  if (!(typeof __c.derivation === "string" && __c.derivation.length >= 30)) __nod.push(__c.id);
  if (__FINAL) { __f = __get(__a, __FINAL); if (__f == null || __f === "") __bad.push("final field " + __FINAL + " empty"); if (!(__FINAL in __c.expected)) __bad.push("case does not assert " + __FINAL); }
 }
 for (__k in __c.expected) {
  if (__k === "error") { if (!(__a && __a.error)) __bad.push("expected an error, got " + __s(__a)); continue; }
  if (JSON.stringify(__get(__a, __k)) !== JSON.stringify(__c.expected[__k])) __bad.push(__k + ": expected " + __s(__c.expected[__k]) + ", got " + __s(__get(__a, __k)));
 }
 if (!__bad.length) __pass++; else { __fail.push({id: __c.id, anchor: !!__c.anchor, mismatch: __bad}); if (__c.anchor) __anc.push(__c.id); }
}
for (__k in __REFS) { __used = false; break; }
for (__i = 0; !__used && __i < __CASES.length; __i++) if (!("error" in __CASES[__i].expected)) { __a = __run(__CASES[__i].input, {}); __used = !!(__a && __a.error); break; }
return {harness: "skill-author/test-tail v2.9", passed: __pass, total: __CASES.length, anchors: __nA, refsUsed: __used, underived: __nod, anchorFailed: __anc, validated: __pass === __CASES.length && __used && !__nod.length, failed: __fail};
~~~~

Worked example (a 3-case holiday-shift script; the real script replaces part 4):

~~~~javascript
const __CASES = [
 {"id": "t1-weekday", "input": {"date": "2026-09-02"}, "expected": {"end": "2026-09-02"}, "derivation": "02.09.2026 is a Wednesday, not in holidays -> no shift"},
 {"id": "t2-saturday", "input": {"date": "2026-11-14"}, "expected": {"end": "2026-11-16", "shifted": true}, "derivation": "14.11. Sa -> 15.11. Su -> 16.11. Mo, no holiday -> 16.11."},
 {"id": "t3-invalid", "input": {"date": "14.11.2026"}, "expected": {"error": "invalid date"}}
];
const __REFS = {"holidays": ["2026-08-01", "2026-12-25", "2026-12-26"]};
const __FINAL = "end";
function run(INPUT) {
  if (!INPUT.refs || !INPUT.refs.holidays) return {error: "refs.holidays missing"};
  if (!/^\d{4}-\d\d-\d\d$/.test(INPUT.date)) return {error: "invalid date"};
  var H = INPUT.refs.holidays.join(","), p = INPUT.date.split("-"), d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])), s = false, g;
  function iso(x) { return x.toISOString().slice(0, 10); }
  for (g = 0; g < 30 && (d.getUTCDay() === 0 || d.getUTCDay() === 6 || H.indexOf(iso(d)) >= 0); g++) { d = new Date(d.getTime() + 864e5); s = true; }
  return {end: iso(d), shifted: s};
}
<the TEST TAIL, copied exactly>
~~~~

- The tail adds `refs: __REFS` to each case input, exactly as the runtime recipe (§C) passes `INPUT.refs`. If the runtime recipe uses another shape, change only the line `x.refs = refs;` in `__run`.
- **Answer-field check (`__FINAL`):** every computed case must return a non-empty `__FINAL` value **and** assert it in `expected`; otherwise the case fails ("final field … empty", "case does not assert …"). V28-S04's script, re-run with this tail and `__FINAL = "verschobenes_fristende"`, fails 5 of 9 cases on exactly that.
- **`refsUsed` probe:** the first valid-input case is re-run with empty `refs`. A script that really reads its data from `INPUT.refs` must return `error`; if it still returns a normal result, it has a hard-coded copy of the data, `refsUsed` is false, and the script is **not validated** (SKILL.md §10). With no reference data (`__REFS` = `{}`), `refsUsed` is true.
- **Short result.** Only failing cases are returned (`failed: [{id, anchor, mismatch}]`, values cut at 90 characters), so the result stays under the ~4,000 characters above which the host compacts it (V28's 6,650-character result needed a `context_expand`). `anchors` counts the cases marked `"anchor": true`.
- The script is **validated** only when the **last** call returns `validated: true` (`passed === total`, `refsUsed` true, `underived` empty) **and** `anchors` equals the number of mandated anchors. `anchorFailed` lists failing mandatory cases: the script is wrong there, never the expectation. **Fix loop** (SKILL.md §10 step 4): re-count each failing case by hand in writing (§E "Independent oracle"), fix the script, re-run all cases; at most 4 test calls. Change the script, never an anchor; a non-anchor expectation changes only for a named slip in your own count.
- `ok:false` from `js_run` means the test did not run (syntax error, guard rejection, timeout); it is never a test result, and it counts as a call. Causes: a data part that is not valid JSON, the script wrapped in backticks or quotes, an unbounded loop.
- Final answer table: id | input | expected | actual | pass (a passing case's actual equals its expected).

## H. Lint call

The lint is described completely in SKILL.md §12: three `text_search` calls on the written file (FM, DEFECTS, INVENTORY) and one `js_run` with `const D = {...};` + the LINT BLOCK from SKILL.md §12, copied exactly + `return lint(D);`. The result carries `"linter":"skill-author/lint-resource.js"` and `"version":"2.4"`. There is no linter file to read.

**Troubleshooting.**
- **`js_run` returns a syntax error** ("Unexpected identifier …", "Invalid or unexpected token"): `D` is not valid JSON, or text was wrapped in backticks or quotes, or the block was not copied exactly. Fix that and re-run once. A later successful run of the same check clears the failure (the host logs "Recovered prior tool failure after successful logical replacement").
- **`node_api_unavailable`:** a value in `D` or the test data contains `require(` or a similar pattern (§I). Write that occurrence inside the JSON string as `require\u0028`; the value is the same, but the guard no longer matches.
- **DEFECTS search returns hits you cannot place:** each `match` is one line of the frontmatter (or a literal task-status tag in the body); fix that line, re-write the file, repeat the three searches.
- Never replace the lint with a self-written checker, and never clear a failure with a dummy script that just returns success.

## I. `js_run` contract (host source: `JsRunTool.vb`, `WebView2JsSandbox.vb`)

- `code` is the only data input; the other parameters are `timeout_ms`, `allow_network`, `navigate_url`, `wait_after_load_ms`, `wait_for_selector`. There is no `args`, `input` or file parameter.
- The code runs as the **body of an async function** (`new Function`), so it must end with `return <value>;`. `await` works.
- Browser sandbox: no file access, no `require`/`import`, network off unless `allow_network`, nothing carries over between calls.
- The host rejects the whole call (`node_api_unavailable`) if the code text contains `require(`, `module.exports`, `__dirname`, `__filename` or `process.env/argv/cwd/platform` anywhere, **even inside a comment or a string**.
- The result is `{ok, result, logs}` or `{ok:false, error}`. Timeout default 15 s, maximum 120 s. No host size limit, but the whole code is typed in one tool call, so keep it compact.
- Never put a script or file text inside a template literal, `String.raw`, a quoted string or `eval`: a backtick or `${` in the text breaks the parse, and `\d` silently becomes `d`.

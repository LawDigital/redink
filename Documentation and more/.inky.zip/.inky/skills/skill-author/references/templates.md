# Skill template (keep < 3,900 chars: arrives without preview)

Fill every `<...>`, drop what does not apply. This template never adds author-side questions (intake = SKILL.md §0.3 only): derive open design choices (depth, structure vs. assessment, sections) and state them as assumptions. Body in the user's language or English. No literal task-status envelope anywhere: describe the footer in words. Other patterns: `agent-template.md` (sub-agent), `script-authoring.md` (scripts), `word-output.md` (Word files), `host-surfaces.md` §3b (AutoPilot).

~~~~markdown
---
name: <kebab-name = folder>
description: <Verb + object + output, one line, max 250 chars, trigger words first>
allowed-tools: [<only tools used below; text_read if any references/ or scripts/ file is named; js_run for scripts>]
---

# <Title>

## Purpose
<What, for whom, result.> Use when: <requests>. Do not use for: <near misses>.

## Supported hosts and gate
Supported: <Outlook Local Chat | Word | Outlook AutoPilot>.
Step 0: read `resource_index.host`. Not supported, or a required tool (<list>) missing: stop, say why, and end the answer with the TASK_STATUS footer, status blocked.

## Inputs
- <Input>: <source> - read with `<tool>`.
- Required input missing or ambiguous: say what is missing, ask to attach it and resend (never via ask_user), end with the TASK_STATUS footer, status blocked.
- Clarifications: `ask_user`, one question per call. <AutoPilot: never ask; block.>

## Workflow
1. <Step> - `<tool>` <arguments that matter>.
2. Read `references/<criteria>.md` with `text_read`.
3. <Script step: see script-authoring.md §C; field names exactly as the script header defines them.>
4. <Output step: finalizer tool, file name, report the returned path.>

## Output
<Exact format.> Then end the answer with the TASK_STATUS footer, status complete.
<Legal content:> "Entwurf - vor Verwendung durch eine Anwältin / einen Anwalt zu prüfen."

## Limits and safe failure
- Never invent facts, provisions or values; uncertain = "zu verifizieren".
- Tool unavailable, input missing, script `error`: give the reason and end with the TASK_STATUS footer, status blocked.
~~~~

**Rules for every authored skill (the runtime host rejects the final otherwise):**
1. **Every exit path names the footer in words** (success, wrong host, missing input, script error, tool failure). Never "gib genau/nur diese Punkte aus" or "nenne nur den Fehlercode" without "und beende die Antwort mit dem TASK_STATUS-Footer, Status ...". V214-S14: the error branch said "nenne nur den Fehlercode", the model dropped the footer, the host rejected 5 finals (`missing_task_status`) and replaced the answer.
2. **Only tools that work on the input's real location.** A local file (created, copied, `word_apply_template` output) is checked with path tools (`word_extract_text`, `text_search`), never with attachment readers (`read_word_document_details`, `read_attachment`, `list_attachments`): their "not found" stays an unresolved failure and the host refuses `complete` (V214-S20, 5 rejections). One verification tool per check, no "A oder B" choices.
3. A host check, inputs with readers, a numbered workflow with one tool per step, the exact output, safe failure.
4. No restating of Inky.md; the runtime answers in the user's language.

Checklist: folder = `name:` = the user's kebab name; every workflow tool is in `allowed-tools`, nothing else; every named `references/`/`scripts/` file exists; criteria live in `references/` with their article references (then `text_read` is in `allowed-tools`).

# Converting Claude / foreign skills to Red Ink

Use this when the user asks you to convert an existing SKILL.md (Claude Code, another agent framework or a prompt collection), or to check whether it runs in Red Ink.

## Steps

1. **Read the source** with `text_read`. If the user pasted it, use the pasted text. Also read any files it references.
2. **Intake:** the SKILL.md §0.3 algorithm applies (max 4 questions, nothing after the intake answers; derive the rest as stated assumptions). Ask only for what the source does not settle, typically the target host(s) and the input channel.
3. **Map every tool and capability** to a verified Red Ink tool (`frontmatter-and-tools.md` §4). If there is no equivalent, remove the capability and state the loss.

   | Foreign capability | Red Ink equivalent (verify per host) |
   |---|---|
   | Read/Write/Edit file, filesystem | `text_read` / `text_write` / `text_search` (text), `file_*` (binary, copy/move) |
   | Bash / shell / Python / code execution | `js_run` for in-memory deterministic computation (no filesystem, no Node APIs). `python_execute` only if the helper is installed; never as a required dependency. Otherwise: not available |
   | WebFetch / web search | `retrieve_web_content`, `internet_search`, `web_grounding`, `download_web_files` (actual files) |
   | Browser automation | `browser_open` / `browser_snapshot` / `browser_interact` (config-dependent) |
   | Ask the user / AskUserQuestion | `ask_user` (interactive only; one question per call; not in AutoPilot) |
   | Sub-agent / Task tool | `agent_<name>` (an isolated agent that you author too; JSON output) |
   | Word/Excel/PowerPoint/PDF generation | `create_word_document`, `word_*`, `create_excel_spreadsheet`, `excel_*`, `create_powerpoint`, `create_pdf_from_text`, `word_to_pdf` (check the host columns) |
   | Open Word document | `worddoc_*` (Word only) |
   | Mail attachments | `list_attachments`, `read_attachment`, `extract_pdf_text` (Outlook/AutoPilot) |
   | Send mail | **none**: there is no send tool. AutoPilot replies to the sender through host delivery |

4. **Rewrite the frontmatter** in the Red Ink dialect (`frontmatter-and-tools.md` §1-2):
   - drop unknown keys (`version`, `license`, `tags`, `model` on skills, ...);
   - use a single-line description;
   - make `name` equal the folder name;
   - put only verified tools in `allowed-tools`.
5. **Add what foreign skills lack:**
   - host gate (SKILL.md §7);
   - an input reader for each host;
   - the finalizer for file outputs;
   - safe failure with the footer described in words;
   - a script-backed deterministic step (SKILL.md §10) where the source relied on shell or Python computation.
6. **Move bundled scripts:** Python/Bash scripts cannot run. Port pure logic to `scripts/<x>.js` using the skeleton in `script-authoring.md` §D, and test it (SKILL.md §10). Anything that needs the filesystem, network or packages is dropped and reported.
7. **Copy binary assets** (templates, images) with `file_copy` into the new skill's `references/`, never with `text_write`.
8. **Validate** as in SKILL.md §12 (the three searches, the lint, the cross-check).
9. **Verdict in the final answer:**
   - *runs as is*;
   - *runs after the listed adaptations* (list each one); or
   - *cannot run here* (give the blocking reason, for example "needs shell access").

   When the user only asked for a check, give the verdict and a patch plan, and write nothing.

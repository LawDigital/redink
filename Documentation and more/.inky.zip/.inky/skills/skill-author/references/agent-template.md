# Sub-agent template

Read only when the package contains a sub-agent. Frontmatter rules: SKILL.md §5.

## B. Sub-agent (`agents\<name>.md`, or `agents\<name>\AGENT.md` when it needs its own references)

~~~~markdown
---
name: <kebab-name identical to the file stem / folder>
description: <What the agent returns, in one line>
allowed-tools: [<hard dependencies only; may be empty: []>]
optional-tools: [<host-dependent helpers, e.g. read_attachment, js_run>]
---

# <Title>

## Mission
<One bounded job. The agent does NOT see the conversation or Inky.md; everything it needs arrives in
`task` (and `context`).>

## Task input (from the parent)
<Exact KEY: value lines the parent passes, e.g. SOURCE_TEXT, FIELDS, LANGUAGE.>

## Rules
- Use only the exposed tools. Never ask the user; return missing information instead.
- Do not invent values. Unknown -> "nicht gefunden" / null with a reason.
- <Budget, e.g. at most 2 reads per document.>

## Output (binding)
Your FINAL message is exactly ONE JSON object and nothing else (no prose, no Markdown fence):
{"status":"ok|insufficient|failed","summary":"<one sentence>","result":{<schema>},"missing":[<items>]}
- ok: the job is done. insufficient: the input lacks what is needed (list it in "missing").
  failed: a tool error prevented the job (explain it in "summary").
~~~~

File name: `agents\<name>.md` with the kebab-case `<name>` the user gave (hyphens allowed), e.g. `agents\zz-test-vertragsextraktor.md` with `name: zz-test-vertragsextraktor`. The host derives the tool name `agent_zz_test_vertragsextraktor` itself (`ToolRegistryBuilder.BuildAgentToolName`); never use that underscore form as the file name.

The parent skill calls `agent_<name>` with `task` (all the data), `subagent_task_id` (stable per logical task, for example `<skill>-<doc>-1`) and `expected_artifacts: []` when the agent returns data only. The parent declares `agent_<name>` in its `allowed-tools`, and still works or blocks cleanly when the agent is unavailable.


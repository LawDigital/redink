# Authoring recipe — Office design repository

## Scope

Use this recipe when the user wants to install, document, revise, review, or understand an Office
design carrier under the Red Ink `designs/` resource family. Keep the core `skill-author` generic;
this recipe owns the design-repository authoring convention.

The ordinary user-facing workflow must be source-first and human-readable. Do **not** require a user
to author JSON merely to make a standalone PowerPoint template available.

## PowerPoint — preferred user workflow

For a standalone PowerPoint design, the simplest package is:

```text
designs/powerpoint/My_Template.potx
```

or:

```text
designs/powerpoint/My_Template.pptx
```

The host discovers approved carriers placed directly in that folder. If the design needs explanation,
add a same-basename Markdown companion:

```text
designs/powerpoint/My_Template.potx
designs/powerpoint/My_Template.md
```

The Markdown is ordinary natural-language guidance. There is no required JSON schema.

A `.pptx` may intentionally contain a few sample slides that demonstrate layout use. When it is used
as a repository design carrier, those sample slides are normally removed from the generated deck, but
the runtime may inspect them before generation to understand the template.

## What to put in the Markdown guide

Prefer a short document that says:

1. what the template is for;
2. the **exact custom-layout names** that matter and when each should be used;
3. important limits (for example, a team layout designed for exactly three people);
4. layouts/uses that should be avoided automatically;
5. any real image/chart/content expectations;
6. the fallback rule when no layout safely fits.

Do not translate this into a private scoring table, layout-number mapping, or organization-specific
hard-coded heuristic. The runtime can inspect actual masters/layouts/placeholders/sample slides and
use a bounded LLM interpretation step. Human guidance, when present, is authoritative for
organization-specific intent.

Use `designs/powerpoint/DESIGN_GUIDANCE_TEMPLATE.md` as a copy/edit starting point when it is present.

## `designs.json` is advanced, not the normal PowerPoint path

Use `designs.json` only when an administrator genuinely needs advanced aliases, explicit renderer
defaults, or one stable design profile spanning several Office applications. A standalone PowerPoint
carrier does not require it.

Never make a subject-matter expert understand JSON just to install a `.potx`/`.pptx` or explain its
master layouts.

## Create / install

When the user asks Red Ink to install a PowerPoint design carrier:

1. Resolve the exact target resource root and author-mode permissions.
2. Copy the supplied `.potx`/`.pptx` into `designs/powerpoint/` under a stable descriptive filename.
3. If the user supplied natural-language layout guidance, write it as the same-basename `.md`.
4. If no guidance was supplied, do **not** invent layout rules. Explain that runtime template
   introspection can map layouts from the actual file and that a guide can be added later if the
   design owner wants to constrain intended use.
5. Do not create or edit `designs.json` unless the user actually needs advanced profile features.
6. Preserve the binary Office carrier exactly; do not rewrite it through a text tool.

## Revise guidance

When a design owner returns a revised Markdown guide:

1. read the existing same-basename `.md`;
2. apply only the requested guidance changes;
3. preserve exact custom-layout names unless the owner/template has changed them;
4. do not modify the `.potx`/`.pptx` unless the user supplied a replacement carrier;
5. if guidance names no longer match a replacement template and the runtime cannot verify them from
   available tooling, flag the mismatch for a PowerPoint runtime test rather than guessing.

## How-to mode — copy/paste prompts

Explain the simplest path first. Good user prompts include:

> Install the attached PowerPoint template as a Red Ink design. Put the binary carrier under `designs/powerpoint/`. Do not require JSON. I have not provided layout guidance, so leave layout interpretation to the actual template metadata and runtime unless you need a factual clarification.

> Install the attached PowerPoint template and the attached natural-language layout notes as one Red Ink design. Store the notes as the same-basename Markdown companion. Do not encode the layout guidance as JSON.

> Explain how I should add a corporate PowerPoint template to Red Ink and how I can optionally describe its master/layout usage in Markdown. Do not modify anything yet.

> Here is the revised Markdown guidance for our PowerPoint template. Update only the design guide and leave the binary template unchanged.

## Review checklist

Before declaring a design-resource change complete, verify:

- the carrier is in the correct `designs/<application>/` directory;
- any companion Markdown has the same basename;
- no user-facing JSON authoring was introduced unnecessarily;
- binary carriers were copied, not text-rewritten;
- guidance is template-specific and does not become a global Red Ink heuristic;
- the package documentation explains runtime introspection/fallback;
- a real Windows PowerPoint/VSTO runtime test remains required for master/layout rendering behavior.

# Authoring recipe — Office design repository

## Scope

Use this recipe when the user wants to install, document, revise, review, or understand an Office
design carrier under the Red Ink `designs/` resource family. Keep the core `skill-author` generic;
this recipe owns the design-repository authoring convention.

The ordinary user-facing workflow must be source-first and human-readable. Do **not** require a user
to author JSON merely to make a standalone PowerPoint template available.

## PowerPoint — preferred user workflow

For a standalone PowerPoint design, the simplest package is:

```text
designs/powerpoint/My_Template.potx
```

or:

```text
designs/powerpoint/My_Template.pptx
```

The host discovers approved carriers placed directly in that folder. If the design needs explanation,
add a same-basename Markdown companion:

```text
designs/powerpoint/My_Template.potx
designs/powerpoint/My_Template.md
```

The Markdown is ordinary natural-language guidance. There is no required JSON schema.

A `.pptx` may intentionally contain a few sample slides that demonstrate layout use. When it is used
as a repository design carrier, those sample slides are normally removed from the generated deck, but
the runtime may inspect them before generation to understand the template.

## What to put in the Markdown guide

Prefer a short document that says:

1. what the template is for;
2. the **exact custom-layout names** that matter and when each should be used;
3. important limits (for example, a team layout designed for exactly three people);
4. layouts/uses that should be avoided automatically;
5. any real image/chart/content expectations;
6. the fallback rule when no layout safely fits.

Do not translate this into a private scoring table, layout-number mapping, or organization-specific
hard-coded heuristic. The runtime can inspect actual masters/layouts/placeholders/sample slides and
use a bounded LLM interpretation step. Human guidance, when present, is authoritative for
organization-specific intent.

Use `designs/powerpoint/DESIGN_GUIDANCE_TEMPLATE.md` as a copy/edit starting point when it is present.

## Word — structured template workflow

For new Word designs, install a clean `.docx` carrier under `designs/word/`; DOCX is the recommended carrier. Legacy `.dotx` may remain supported where needed, but do not prefer it for new structured designs. A simple style-only carrier can still be installed without extra configuration. If the template contains native document structure that
must be preserved and filled at exact locations, add a same-basename Markdown companion and use
speaking placeholders in the exact form `[[RI:SlotName]]` inside the Word carrier.

The visible slot id is deliberately not semantic. `[[RI:Body]]`, `[[RI:Text]]`, and
`[[RI:MainText]]` can all mean the same thing when the guide maps them to the same source. Never add
organization-specific alias rules to shared code merely because one template uses a familiar word.

The companion file's ordinary prose remains human guidance. `## Word template slots` is machine-readable for insertion/value binding. Body formatting may live either in a design-local `## Word body styles` section or, preferably when several carriers share one style family, in a shared policy referenced by `style_policy_file` in `designs.json`. Shared policies may also expose a validated `## Word native styles` inventory. Use table-free property lists for newly
authored or edited guides. For example:

```text
- placeholder: [[RI:Recipient]]
  purpose: Person, company or group to whom the document is addressed.
  source: template_fields.recipient
  required: yes

- placeholder: [[RI:Body]]
  purpose: Main substantive body at this exact location; exclude fixed front matter.
  source: markdown_content
  required: yes
```

Rules:
- `source:` is `markdown_content` or `template_fields.<key>`.
- `purpose:` is the plain-language semantic instruction exposed to the model; do not make the model
  infer the field from a placeholder id or arbitrary key name.
- `content:` is optional. `markdown_content` defaults to `markdown`; `template_fields.<key>` defaults
  to `text`. Use an explicit content property only for a deliberate non-default mode.
- Canonical property values are bare. Matching backticks or quotation marks are tolerated as legacy
  input but are not required and should not be emitted for new/revised guides.
- The [[ and ]] around an RI placeholder are required marker delimiters, not quotation marks.
- Markdown slots must be the only visible content in their paragraph so native paragraph/run
  formatting can be inherited safely.
- Every declared marker must exist in the carrier; unresolved `[[RI:...]]` markers are a hard error.
- A slot-bearing carrier and its same-basename companion form one atomic design unit. If markers are
  added, removed, or renamed, deploy both files together.
- A slot-bound template owns document structure. Do not silently prepend content or add a generic
  cover page when no declared location exists for it.

When exact body formatting matters, add under `## Word body styles`, for example:

```text
- paragraph: My Body Style
- heading1: My Heading 1
- bullet1: My Bullet 1
```

Supported semantics are `paragraph`, `heading1..heading6`, `bullet1..bullet9`, and
`numbered1..numbered9`. Style names are exact native paragraph-style names from the carrier. When this
section exists, every heading/list level used in Markdown must be mapped; missing levels are hard
errors, not fallback styling. `paragraph` is optional and, when declared, controls ordinary non-empty
body paragraphs. Paragraphs inside Word tables and `[[visual:...]]` placement markers remain outside
this paragraph-style mapping. Legacy Markdown-table contracts remain accepted by the parser as
backward-compatible input, but skill-author should not emit them for new or revised Word guides.

If multiple carriers share the same exact style system, create one shared policy file such as
`designs/word/ORGANIZATION_STYLE_POLICY.md`, reference it from each catalog entry with
`style_policy_file`, and keep carrier-specific companion files focused on slots. The shared policy may
contain `## Word body styles` plus `## Word native styles`. The host merges and validates the policy
against each carrier. Do not duplicate the same style map across many companions.

For numbered native heading styles, also add a machine-readable rendering rule:

```text
## Word rendering rules

- heading_numbering: native
```

Use `native` when Word supplies the visible heading number and `preserve` when Markdown heading text
should retain its own numbering. A design companion can override the shared policy for a genuinely
different carrier. With `native`, the model should emit title text only and the renderer defensively
strips leading manual numbering prefixes before applying the native style. Only explicit `- key: value`
lines inside `## Word rendering rules` are machine-readable; explanatory prose is ignored. Currently
`heading_numbering` is the only rendering-rule switch.

Use `designs/word/WORD_DESIGN_GUIDANCE_TEMPLATE.md` as the copy/edit starter when present.

## `designs.json` is advanced, not the normal PowerPoint path

Use `designs.json` only when an administrator genuinely needs advanced aliases, explicit renderer
defaults, or one stable design profile spanning several Office applications. A standalone PowerPoint
carrier does not require it.

Never make a subject-matter expert understand JSON just to install a `.potx`/`.pptx` or explain its
master layouts.

## Create / install

When the user asks Red Ink to install a PowerPoint design carrier:

1. Resolve the exact target resource root and author-mode permissions.
2. Copy the supplied `.potx`/`.pptx` into `designs/powerpoint/` under a stable descriptive filename.
3. If the user supplied natural-language layout guidance, write it as the same-basename `.md`.
4. If no guidance was supplied, do **not** invent layout rules. Explain that runtime template
   introspection can map layouts from the actual file and that a guide can be added later if the
   design owner wants to constrain intended use.
5. Do not create or edit `designs.json` unless the user actually needs advanced profile features.
6. Preserve the binary Office carrier exactly; do not rewrite it through a text tool.

When the user asks to install a structured Word carrier, additionally:

1. copy the supplied `.docx` to `designs/word/` (preferred for new designs; retain legacy `.dotx` only when specifically required);
2. give each distinct slot a `[[RI:SlotName]]` marker; a plain-text marker may intentionally repeat when the same value belongs in several places;
3. create/update the same-basename `.md` with the exact `## Word template slots` property-list mapping;
4. if several designs share the same style system, create/reference one shared `style_policy_file`; otherwise add a local `## Word body styles` section and map only the Markdown heading/list levels the template intentionally supports; add `## Word rendering rules` with `heading_numbering: native` when native heading styles provide numbering;
5. keep slot ids readable but treat `source:` as the binding authority and `purpose:` as the model-facing meaning; never rely on the id text alone;
6. use bare property values in new/revised guides; quotes/backticks are compatibility input only;
7. deploy the carrier and companion together whenever machine-readable placeholders change;
8. verify every declared placeholder and every body/native style from the local or shared policy exists in each carrier before delivery;
9. when multiple Word formats are installed, add catalog routing metadata (`document_type`, `language`, `organization`, `default_for`, optional `is_default`) so the agent does not guess between formats; document_type is the primary key and language only selects among same-type variants; `template_file`, `guidance_file`, and `style_policy_file` paths are relative to `designs/`;
10. remember the loading fallbacks: omitted `guidance_file` may use a same-basename `.md`, but `style_policy_file` must be explicit; explicit catalog entries beat loose-carrier discovery; local entries beat central entries;
11. structured slot-bound creation and generic creation without a carrier are OOXML-only; legacy non-slot carriers remain a compatibility path and may require Word/COM.

## Revise guidance

When a design owner returns a revised Markdown guide:

1. read the existing same-basename `.md`;
2. apply only the requested guidance changes;
3. preserve exact custom-layout names unless the owner/template has changed them;
4. do not modify the `.potx`/`.pptx` unless the user supplied a replacement carrier;
5. if guidance names no longer match a replacement template and the runtime cannot verify them from
   available tooling, flag the mismatch for a PowerPoint runtime test rather than guessing.

## How-to mode — copy/paste prompts

Explain the simplest path first. Good user prompts include:

> Install the attached PowerPoint template as a Red Ink design. Put the binary carrier under `designs/powerpoint/`. Do not require JSON. I have not provided layout guidance, so leave layout interpretation to the actual template metadata and runtime unless you need a factual clarification.

> Install the attached PowerPoint template and the attached natural-language layout notes as one Red Ink design. Store the notes as the same-basename Markdown companion. Do not encode the layout guidance as JSON.

> Explain how I should add a corporate PowerPoint template to Red Ink and how I can optionally describe its master/layout usage in Markdown. Do not modify anything yet.

> Here is the revised Markdown guidance for our PowerPoint template. Update only the design guide and leave the binary template unchanged.

## Review checklist

Before declaring a design-resource change complete, verify:

- the carrier is in the correct `designs/<application>/` directory;
- any companion Markdown has the same basename;
- no user-facing JSON authoring was introduced unnecessarily;
- binary carriers were copied, not text-rewritten;
- guidance is template-specific and does not become a global Red Ink heuristic;
- the package documentation explains runtime introspection/fallback;
- structured Word guides have an exact `## Word template slots` property-list mapping and every declared marker exists;
- Word slot binding comes from `source:` rather than hard-coded placeholder aliases, and each newly authored slot has a clear model-facing `purpose:`;
- any `## Word body styles` mapping uses supported neutral semantics, exact native style names, and
  intentionally exposes only the heading/list levels the template supports;
- new/revised Word companion contracts are table-free, while legacy Markdown-table contracts remain input-compatible;
- a slot-bearing Word carrier and its same-basename companion are delivered together when markers change;
- a real Windows Word/VSTO runtime test remains required for structured Word slot binding and final native insertion/style inheritance;
- a real Windows PowerPoint/VSTO runtime test remains required for PowerPoint master/layout rendering behavior.


## Complete design-set switching

When multiple independent Office design repositories must be alternated, keep each as a full
`.inky/design_sets/<set>/designs/` tree and select one via `.inky/design_sets/active.json`. Do not put
organization-specific routing rules into global `Inky.md` files. Within a Word family, keep recurring body
styles in one shared style policy; use a companion body-style mapping only for a genuine carrier-specific
override. Tables align to the preceding generated paragraph's effective indent automatically.

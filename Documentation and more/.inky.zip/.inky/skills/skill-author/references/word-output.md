# Word output with formal requirements (keep < 3,900 chars: no preview)

Use when the authored skill makes a Word file and the user gave formal requirements (font, size, headings, margins) or a template. Prose rules alone fail (arguments dropped, `consulting` default).

**Intake.** Requirements but no template named → one `ask_user`: "Gibt es eine Word-Vorlage (.docx) mit den verlangten Formatvorlagen?" ("Ja, ich nenne den Pfad / lege sie bei" / "Nein, ohne Vorlage"). A file never arrives via `ask_user`: ask for it in your answer.

**M1 - mandatory in the authored SKILL.md (both variants):** a section `### Formatvorgaben` with **every** user requirement as a **numbered Markdown line** `1.`, `2.` …, the user's values copied literally, each mapped to its source:
~~~~markdown
### Formatvorgaben
1. **F1** Fliesstext Arial 11 pt - Formatvorlage "Normal" der Vorlage | word-format.json base_font_name, base_font_size
2. **F2** Überschriften Arial 14 pt fett - Formatvorlage "Heading 1" | NICHT erzwingbar ohne Vorlage (Host-Grenze), best effort
3. **F3** keine `{{...}}` Platzhalter übrig - Prüfung mit word_extract_text (Pfad)
~~~~
Never bullets or prose for these. Your final answer: guaranteed vs. best-effort items, per best-effort item the host limit and a template recommendation.

**(a) Template supplied (deterministic).**
1. `file_copy` the file into `<new_resource_root>\skills\<name>\references\<file>.docx` (a `.dotx` only if no `.docx` exists).
2. Authored runtime section:
~~~~markdown
## Word-Ausgabe (immer aus der Vorlage)
1. `word_apply_template` mit skill: "<name>", template: "<file>.docx" (relativ zu references/), output_name: "<Name>.docx", substitutions: {"KEY": "<einzeiliger Wert>", ...}. Den zurückgegebenen Pfad verwenden.
2. Nur falls die Vorlage `{{BODY}}` hat: `word_write` auf diesen Pfad, tasks: [{operation_id: "body-1", op: "replace", find: "{{BODY}}", text: "<Markdown>"}].
3. `word_extract_text` mit dem zurückgegebenen Pfad: kein `{{` übrig; sonst einmal nachbessern, dann blockieren.
Nie `create_word_document`, `word_format`, `worddoc_format` für diese Ausgabe.
~~~~
3. `allowed-tools`: `word_apply_template`, `word_extract_text` (+ `word_write`); never `create_word_document`, never `read_word_document_details` / `read_attachment` for a local file (attachment readers: V214-S20 final rejected 5x).
4. State in the authored SKILL.md: placeholders only in the main body; a placeholder paragraph becomes one plain run; German style ids (`berschrift1`) fall back to Normal.

**(b) No template (Outlook / AutoPilot only; Word host has no `create_word_document`).**
1. `references/word-format.json` with literal `create_word_document` arguments, only real keys, e.g. `{"style_preset": "plain", "professional_layout": false, "base_font_name": "Calibri", "base_font_size": 11, "page_orientation": "portrait", "show_page_numbers": true, "include_cover": false, "use_repository_default_design": false}`. Also real: `file_name`, `document_language`, `header_text`, `footer_text`. Never invent `margins`, `heading_font_size`.
2. **M2 - this sentence, verbatim in the authored SKILL.md:** "Übergib bei jedem Aufruf von `create_word_document`, auch bei jedem Wiederholungsversuch (retry), alle Schlüssel aus `references/word-format.json` unverändert; lass keinen weg und verwende kein anderes Preset." (en: "Pass every key of `references/word-format.json`, unchanged, on every `create_word_document` call, including every retry.")
3. Heading size/font, margins, spacing, numbering are not arguments: mark them best effort in F1..Fn, tell the user, recommend a template.

**Checks before the lint (text_search on the written SKILL.md):** `^\s*\d+\.\s.*\d+\s*pt` hits every size requirement (M1); variant (b) also `jedem Aufruf|every .*call` and `retry|Wiederholungsversuch` (M2). A miss → rewrite SKILL.md now.

## Artifact arguments in authored Word skills (mandatory; V216-S20 t2)
The authored SKILL.md must tell the runtime model, for **every** `word_apply_template`, `word_write`, `create_word_document` and `word_save_as` call (first call and retries alike):
- pass **either no artifact identity keys at all, or the complete triple** `artifact_id`, `logical_deliverable_id`, `output_slot_id` with non-empty, stable values (e.g. `werkvertrag_docx_1`, `werkvertrag`, `werkvertrag_docx`) — never an empty string and never only one or two of them (`supersedes_artifact_id` only when really superseding);
- reuse exactly the same values on a retry; never switch between "with ids" and "without ids" in one run.
Reason: the host pre-check rejects partial or empty ids (`explicit_artifact_identity_incomplete`) and the failure is not cleared by a later successful call, so every final answer is then rejected (V216-S20 t2: 5 rejected finals, host finding H-03/H-04). Put this rule verbatim into the authored skill's workflow step that creates the Word file.

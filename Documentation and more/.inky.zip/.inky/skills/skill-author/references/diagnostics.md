# Diagnosing previous tooling runs

Use this when the user asks what happened or went wrong in an earlier run, or asks you to fix a skill "based on the last run". The diagnostics logs are the ground truth. Do not rely on chat history alone.

## 1. Preconditions

- Logs live in `local_root\diagnostics\`. The folder is always readable.
- Outlook tooling runs (Local Chat) are logged there only while Skill-author mode is on. Word's logging location was not verified; if no Word log is present, ask the user for it. With APIDebug they go to a single file on the Desktop, which is overwritten each run.
- `resource_index.diagnostics_files` is filled only while Skill-author mode is on. When it is absent, use `file_list` on the folder. If no suitable log exists:
  - tell the user to enable Skill-author mode (Agents > Manage Skills & Agents) and reproduce the run;
  - end with the task-status footer, status blocked.
- Fixing a resource afterwards still requires author mode.
- Only the newest **5** tooling logs (and 5 sub-agent return logs) are kept, so older runs may be gone.
- AutoPilot runs log to `%APPDATA%\RedInk\autopilot-logs\` instead. Those are outside your read roots, so ask the user to attach the log if it is needed.

## 2. File names (verified in the host logger)

- While a run is **in progress**, its log is named `RI_Tooling_Log__<yyyyMMdd-HHmmss>.txt`, with **no skill suffix**.
- When the run **ends**, the file is renamed to `RI_Tooling_Log__<stamp>__<skill_slug>.txt`, if a top-level skill was recorded. Runs without a skill keep the unsuffixed name.
- Sub-agent and skill return payloads: `RI_SubAgent_Returns__<stamp>[__<skill_slug>].txt`.
- `resource_index.diagnostics_files` lists `{path: <file name only>, size, last_write_utc}`, newest first. Build the absolute path as `local_root + "\diagnostics\" + path`.

## 3. Choosing the run (deterministic)

1. **Inventory.** Use `resource_index.diagnostics_files`. If it is empty or absent, call `file_list` on `local_root\diagnostics\`. Never guess a file name. Never use `js_run` to touch the filesystem (no `require`, `fs` or `process`). If neither source gives a list, block with the reason "no diagnostics inventory available".
2. Keep only `RI_Tooling_Log__*.txt`.
3. **Exclude the current run.** That is the **newest file without a `__<skill>` suffix**: it is the log of this diagnosis, still being written. Every file with a suffix, including `__skill_author`, is a completed earlier run and remains a candidate.
4. If the user named the run (a skill name, a timestamp, or "the last failed run of X"), pick the newest matching candidate **without asking**. A skill slug is the sanitized skill name, for example `zz_test_kaputt`.
5. Otherwise, if exactly one candidate remains, take it.
6. Otherwise, **you must ask**. This skill explicitly instructs you to call `ask_user` here, even though "the newest" looks like an obvious default. Ask one question and offer up to 5 candidates as `options`, each labelled with the timestamp, the skill slug, and the Success/Failed result from the log's final summary.

## 4. Reading and diagnosing

- Read the chosen log with `text_read`. For a large log, use a chunked read (`start_char`/`next_offset`), or `text_search` for the key markers:
  - the tools loaded / "allowed-tool scope";
  - `not_found`, `access_denied`, "is not allowed for this sub-agent" (also used for skill scope rejections), `js_run_disabled`, `node_api_unavailable`;
  - `explicit_artifact_identity_incomplete`, `explicit_artifact_self_supersession`, `multiple_task_status`, `complete_with_unresolved_tool_failure`, "partial sibling set", `source_hash_mismatch`;
  - `skill_authoring_postcondition_failed`, "HOST SKILL-AUTHOR RECOVERY RESTART";
  - `js_run` failures "Unexpected identifier '<word>'" / "Invalid or unexpected token" together with a backtick right after `code: 'const x = ` in the `Executing tool: js_run` line: file text was wrapped in a template literal (V23-S02/S03/S04); `errorCode=timeout`: usually an unbounded loop in the script;
  - the session summary lines `Success:` / `Failed:`;
  - the orchestrator's `input` to `skill_skill_author` (`Executing tool: skill_skill_author (input: '...')`; the full text is at the end of the skill result line `{"name":"skill-author",…"input":"…"}` and in the `RI_SubAgent_Returns` file). Compare it with `latestUserRequestRaw`: a paraphrase that says "Plane"/"Umsetzungsplan" explains a plan-only run (V22-S03); "bearbeite in diesem Turn nur eine Datei" / "erste sinnvolle Dateiänderung" explains a one-file run (V24-S03, S05, S06 turn 2);
  - `Tool replay retention: … tool=text_read; … compacted=true; originalChars=N; replayChars=~800`: the model saw only a preview of that file, not its content, unless a `context_expand` of the `result_ref` follows;
  - `ConvertCanonicalToModelFormat error … ToolName='skill_use'`: the `skill_use` definition could not be exposed, so the skill was never loaded (host defect, V24-S09).
- The log keeps LLM responses only as about 200-character excerpts and prompts only as stubs. Say so if the diagnosis depends on text that was not logged.
- Tie every root cause to **evidence**: quote or paraphrase the log line and give its approximate position. Then read the affected resource files and name the exact defect. Examples:
  - a tool that was used but not declared in `allowed-tools`;
  - a referenced file that is missing;
  - a block-scalar description;
  - a resource write whose artifact ids are partial or placeholders, or whose `expected_artifacts` is non-empty (see `frontmatter-and-tools.md` §5).
- Separate **skill defects** (fixable here) from **host behaviour** (report it; you cannot fix it here).

## 5. Fixing

Fixing is only allowed when the user asked for it. Then:
- switch to REVISE mode (SKILL.md §13): read every affected file, change all files that are needed (for example add `js_run` to `allowed-tools` **and** create the missing `references/<file>.json`, e.g. a standard German stop-word list as a JSON array, stated as an assumption), and keep everything else unchanged. "Konservativ" in the orchestrator's `input` never means leaving a known defect unfixed (V24-S12 turn 2 fixed only `allowed-tools` and ended with `referenced_file_missing`);
- validate (SKILL.md §12);
- in the final answer, cite the log evidence, list each change per file, and tell the user to re-run the skill in a **new** chat to confirm.

# Authoring recipe — structured-intake reference schemas

## Scope

Use this recipe for reusable schema packages consumed by the generic `structured-intake` skill.
These schemas collect/normalize facts; they must not become substantive eligibility, compliance,
scope, pass/fail or legal-decision engines.

## Source model

Each schema package uses:

- `schema.md` — normative human-readable description of the fields and collection rules;
- `schema.json` — derived executable field schema;
- `source_notes.md` — provenance, intended use, exclusions and maintenance notes;
- root registry `references/intake_schemas.json`.

Subject-matter experts should normally review `schema.md`. JSON is a technical translation.

Maintainer-only HTML comments in sample files are non-runtime distribution metadata and must not be
surfaced during intake.

## Create / revise / synchronize

1. Read `structured-intake/SKILL.md` and the schema registry.
2. Define only facts that the intake should collect; keep evaluation/judgment outside the schema.
3. Use stable semantic field ids and explicit data types, cardinality, required/optional status,
   conditional relevance and provenance expectations.
4. Compile `schema.md` into `schema.json`; preserve ids on wording-only revisions.
5. If an expert asks for a field that is actually a legal/compliance determination, record the
   underlying fact instead or route that decision to an assessment/review workflow.
6. Register/update the schema with narrow aliases/description.
7. Validate JSON, unique ids, registry paths and that no field rule encodes a substantive pass/fail outcome.

## Recommended Red Ink prompts

Create:

> Create a new reusable structured-intake schema from the attached expert field list. Keep `schema.md` as the human-readable master, derive `schema.json`, and register the schema. Collect facts only; do not add a substantive compliance decision.

Revise:

> Here is the subject-matter expert's revised field list for intake schema `<id>`. Synchronize the existing schema, preserve stable field IDs where possible, and show added, removed, or changed fields.

How-to:

> Explain, with a concrete copy/paste prompt, how to create or update a structured-intake reference pattern from a Word or Markdown field list. Do not modify anything yet.

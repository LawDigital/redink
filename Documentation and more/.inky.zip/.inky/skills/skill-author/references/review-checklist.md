# Review checklist (deterministic; work through it in order)

Use this list in REVIEW mode. Write modes validate with SKILL.md §12 (searches and lint) and do not need to read this file. For each item, record the result (pass / fail / n.a.) and, for each failure, the evidence (key, line or path) and the fix. Do **not** call a frontmatter "readable" or "valid" before items 1-3 have been checked mechanically.

## Collect first

1. `text_read` the descriptor: `SKILL.md`, `AGENT.md` or `agents\<name>.md`. Use the exact path from `resource_index`.
2. `file_list` the resource folder recursively, then `text_read` every file under `references/` and `scripts/` that the body names.
3. Get the Tool List rows for every declared tool, and for every tool the body mentions. Use the complete read or the row-regex `text_search` (see `frontmatter-and-tools.md` §4).
4. Run the checks of SKILL.md §12 on the descriptor: the three `text_search` calls (FM, DEFECTS, INVENTORY) on its path, then one `js_run` = `const D = {...};` (JSON built from the search results, `host_targets` = the hosts the resource claims, `agents` = the names in `resource_index.agents`) + the LINT BLOCK from SKILL.md §12, copied exactly + `return lint(D);`. Never put the file text into `js_run`.

   The lint result must contain `"linter":"skill-author/lint-resource.js"`; a result without it came from an ad-hoc check and counts as "lint not run". If `js_run` is unavailable or fails twice, check A-C by reading and report "lint not run: <error>". Each DEFECTS hit is a finding for A2-A4 or A9 (the `match` is the offending line), or C7.

## A. Parser level (blocking)

| # | Check | Typical defect |
|---|---|---|
| A1 | The frontmatter starts at character 0 (a BOM is allowed). | Blank line or text before `---` |
| A2 | No block scalar in any value (`>`, `>-`, `|`, `|-`). The description is on one line. | `description: >-` loads as ">-" |
| A3 | Every line is `key: value`, a `- item` under an empty key, or a full-line `#` comment. There are no continuation lines and no indented keys. | Wrapped description lines |
| A4 | No inline `# comment` after a value or list item. | `- create_word_document  # report` |
| A5 | Lists are comma-separated or `- item` lines, and no item contains a space. | `allowed-tools: a b` |
| A6 | `name` exists, is kebab-case ASCII, and **equals the folder name** (skill) or the file stem/folder (agent). The file/folder uses the name the user gave (hyphens allowed), not the `_` tool form. | `name: x-check` in folder `x-flawed`; `agents\zz_test_x.md` with `name: zz-test-x` (V21-S03) |
| A7 | `description` exists and is not just `>`/`|`. It is ≤ 250 characters (≤ 400 when needed for trigger words) with the task type + object in the first 120, in the user's languages. | Vague or overlong router text |
| A8 | The `allowed-tools` key exists (`[]` is fine). | Missing key |
| A9 | Only known keys (`frontmatter-and-tools.md` §2). No `network`, `timeout` or `…-before-final-mutation`, and no `model` on a skill. | `trigger-keywords`, `version` |
| A10 | `enabled` is absent, or `false` only on the user's explicit request or for a NOT VALIDATED script skill (SKILL.md §10). | Invented `enabled: false` |
| A11 | `deliverable-count` is an integer ≥ 0. `required-successful-tools` ⊆ `allowed-tools`. `deliverable-required-effects` only with `deliverable-count` > 0. | Host validator rejects these |
| A12 | No nested `SKILL.md`/`AGENT.md` inside the resource folder, and no name collision after sanitising. | Stray copies |

## B. Tools and hosts (blocking)

| # | Check |
|---|---|
| B1 | Every static tool exists in `Red_Ink_Tool_List.md`. Invented tools such as `outlook_send_mail` or `send_mail` are a failure. |
| B2 | Every tool is `Yes` for **every** host the resource claims. For AutoPilot, flag `ask_user`, `m365_*`, `memory_*`, `skill_use`, `report_progress`, `worddoc_*` and `word_doc_*` unless they are gated. For Outlook, flag `worddoc_*`/`word_doc_*`. For Word, flag the attachment tools and `create_*`. |
| B3 | Every tool used in the body is declared (scope enforcement rejects undeclared tools), and every declared tool is used. |
| B4 | There is a reader for the primary input on each host (Outlook: `list_attachments`/`read_attachment`/`extract_pdf_text`/…; Word: `worddoc_extract_text` or `word_extract_text`). `text_read` is present when `references/` or `scripts/` are read. |
| B5 | A file-producing workflow names its real finalizer, the file name, and "report the returned path". |
| B6 | Every `agent_<name>` exists (`resource_index.agents`), or is written in the same run. For agents: no `ask_user`, and the output contract is exactly one JSON object. |
| B7 | Wildcards are only used for online-source families, and `*` is never used. |

## C. Body and behaviour

| # | Check |
|---|---|
| C1 | Purpose and when (not) to use it are stated, and the supported host(s) are stated. |
| C2 | The host gate uses `resource_index.host` and blocks cleanly on unsupported hosts. Presence of `ask_user` is not used as a host signal. |
| C3 | Inputs are stated. A missing or ambiguous input leads to blocked with an exact request, never a guess. Files are never requested through `ask_user`. |
| C4 | A numbered workflow, with one tool per step. |
| C5 | The output format is exact (columns, file name, language). |
| C6 | Safe failure: tool unavailable, input missing, script error → blocked with a reason. |
| C7 | **No literal task-status envelope** in the body. The footer is described in words. |
| C8 | Every `references/...` / `scripts/...` path in the body exists, and every criterion the body promises is actually in those files. |
| C9 | Script-backed skills have the exact `js_run` recipe: text_read the script; `const INPUT = {JSON};` + the script verbatim (never in backticks, quotes or eval) + `return run(INPUT);`. They also state the allowed input values as quoted JSON, "never compute by hand", and a blocked path. `references/testcases.json` exists, with expected values derived by an explicit hand count from the rule/statute text (`derivation`, never from the script; check one interaction case yourself by counting days: a derivation that mirrors the script's method, e.g. a month added to the first running day, is a finding), and covers the case matrix of `templates.md` §E: every rule × unit/variant (days **and** months), every rule interaction (e.g. month deadline across a suspension window), one boundary per rule, invalid and unsupported input. The script reads all shipped data from `INPUT.refs` (no hard-coded copy) and every `references/` file is used. The result has one answer field that is never `null` on success (e.g. `massgebendes_fristende`, not only a `verschobenes_fristende` that is `null` without a shift); calendar periods use the `templates.md` §D2 engine. The harness from `templates.md` §G (tail v2.9, with `__FINAL`) returns `validated: true` with all mandated anchors; if not, the skill is `enabled: false` and marked NOT VALIDATED. |
| C10 | There are no TODO, placeholder or "planned extension" sections. |

## D. Content and safety

| # | Check |
|---|---|
| D1 | Legal criteria cite exact provisions, stay in the requested jurisdiction (for example DSG, not GDPR terms), and invent nothing. Uncertain points are marked "zu verifizieren". |
| D2 | Legal output carries a draft/lawyer-review note. |
| D3 | **No automatic sending** of substantive output to clients or third parties, and no send-capable tool without human approval. Flag this as high risk and propose a draft-for-review variant. |
| D4 | Writes stay inside allowed roots. The resource does not tell the model to use `workspace_*` for resources, and does not override retained earlier-message files. |
| D5 | The description differentiates the resource from overlapping resources in `resource_index`. |

## Output of a review

1. **Verdict:** usable as is / usable after the listed fixes / not usable (reason).
2. **Findings**, most severe first. For each: the checklist id, the evidence (line or key), why it matters at runtime, and the exact fix.
3. **Corrected frontmatter**, always given in full, in a `~~~~` fence.
4. Any other body changes as short patch instructions (not the whole file). Never include a literal task-status envelope.
5. An offer to apply the fixes. Do not write anything until the user asks.

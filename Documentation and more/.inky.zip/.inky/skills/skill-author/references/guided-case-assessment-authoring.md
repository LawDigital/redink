# Authoring recipe — guided case assessment packages

## Scope

This recipe extends generic `skill-author` behavior for child assessment packages of a configured
case-assessment engine. The recipe contains the package-specific rules; the core skill-author remains
agnostic.

## Source model

Use this hierarchy:

1. **Subject-matter source** — Word/Markdown/PDF/policy/checklist supplied or approved by the expert.
2. **`requirements.md`** — the single normative, human-readable rule source maintained in the package.
3. **`source_notes.md`** — provenance, version, deliberate interpretations, known ambiguity and maintenance notes; not a second rulebook.
4. **Derived executable files** — `intake.json`, `checklist.json`, `actions.json`, and technical metadata in `profile.json`.
5. **`expert_review.md`** — non-normative, human-readable mirror of what the executable package will actually do.

Subject-matter experts should normally review items 1, 2, 3 and `expert_review.md`; they should not
be required to hand-edit JSON.

## Maintainer-only sample comments

A distributed sample may contain an HTML comment such as:

`<!-- MUSTERHINWEIS: ... -->`

Such comments are maintainer/distribution metadata. Preserve them when synchronizing the package, but
never compile, quote, summarize, or surface them in runtime intake questions, assessment results,
reports, actions, or ordinary user interaction unless the user explicitly asks to inspect maintainer metadata.

## Normative versioning

When an assessment has a subject-matter requirements version, keep that version in the human-readable normative master (`requirements.md`) as the single authoritative value. Do not require the expert to maintain the same version independently in JSON or profile metadata. Technical metadata may point to the version source, and derived `expert_review.md`/reports may display the value, but they are mirrors only.

On CREATE, ask for a version only if the supplied approved source does not already state one and versioning is required by the package. On SYNC, detect a changed version in the revised normative source and propagate its display or source pointer to derived artifacts without inventing or incrementing a version autonomously. If substantive rules change but the expert has not supplied the intended version and the package requires versioning, ask one focused question rather than guessing.

## Language independence

Keep decision semantics independent of display language:

- stable fact/criterion/outcome ids and choice ids carry logic;
- never branch on the literal language-specific wording of a user answer;
- canonical expert documents may declare a reference language (for example `de-CH`);
- interactive questions/results may follow the requester's dialogue language when the profile says so;
- a configured output may have a fixed language (for example a German compliance record);
- translations must preserve the configured rule meaning and must not add domain content.

## A. Create a new assessment package

1. Read the target engine `README.md` and `SKILL.md`, then inspect one existing package only as a
   structural example. Do not copy its domain rules.
2. Read the expert source. Do not ask the expert to convert it to JSON.
3. Draft/maintain `requirements.md` in plain language as the normative rule source.
4. Put provenance, effective date/source version, deliberate interpretations and unresolved questions
   in `source_notes.md`.
5. Compile the approved rules:
   - `intake.json`: only facts needed for decisions/outputs, stable semantic ids, explicit choices/conditions;
   - `checklist.json`: deterministic criteria/order/precedence with traceability to `requirements.md`;
   - `actions.json`: every final outcome label, instruction and configured output/action;
   - `profile.json`: metadata, file links, language policy and execution/output policies; no hidden
     substantive rule that exists nowhere in `requirements.md`.
   - if a Requirements-Version exists, `profile.json` may contain only a pointer to its location in `requirements.md`, not an independently maintained duplicate value;
6. Register the package in the engine registry using workflow-specific aliases/description. Add
   multilingual aliases only when they identify the same workflow; do not make logic depend on keywords.
7. Generate `expert_review.md` from the resulting executable package.
8. Validate all JSON, paths, ids, fact references, outcomes, anchors and profile/registry consistency.
9. Never invent a missing threshold, exception, precedence, classification or outcome. Ask one focused
   expert question when a decision-affecting point is ambiguous.

## B. Synchronize from a revised expert file

1. Read the existing package, registry entry and current `expert_review.md`.
2. Read the revised expert source and classify changes into substantive rule changes, wording-only
   changes, new/removed facts, changed thresholds/exceptions/outcomes/precedence and provenance changes.
3. Update `requirements.md` first; update `source_notes.md` only for provenance/interpretation/ambiguity.
4. Recompile only affected technical structures. Preserve stable ids when the underlying semantic
   concept remains the same.
5. Regenerate `expert_review.md` and produce a concise change report distinguishing decision-impacting
   changes from wording-only changes.
6. Re-run deterministic cross-file validation and regression cases.
7. If the expert edited `expert_review.md`, treat those edits as review instructions: reconcile them
   into `requirements.md` first, then regenerate JSON and the review mirror.

## C. Expert review file

`expert_review.md` should contain:

- assessment title/id and source status;
- human-readable facts that can become material;
- decision path/criteria in order;
- possible outcomes and actions;
- configured outputs;
- a short approval checklist for facts, rules, order, exceptions, thresholds, outcomes/actions,
  interpretations and output requirements;
- a technical note that JSON is derived and stable ids are preserved.

Do not dump raw JSON into the expert review.

## D. Recommended Red Ink prompts

For a new package:

> Create a new reference case for the case-assessment skill from the attached expert policy. Keep the substantive master human-readable, derive the technical JSON files, and create an expert-review file. Do not invent substantive rules; ask when an outcome-determinative ambiguity cannot be resolved.

For a returned expert revision:

> Here is the subject-matter expert's revised source for reference case `<id>`. Synchronize the case, preserve stable IDs where the substantive concept is unchanged, update only affected technical structures, show the substantive changes, and regenerate the expert-review file.

For a how-to question:

> Explain, with a concrete copy/paste prompt, how to create a new reference case or synchronize a file returned by the subject-matter expert. Do not modify files yet.

## E. Validation

At minimum validate:

- all JSON parses;
- `assessment_id` consistency;
- every checklist fact exists in intake;
- every emitted outcome exists in actions;
- profile-declared runtime files exist;
- registry points to the correct profile;
- ids are unique;
- substantive executable rules are traceable to `requirements.md`;
- `source_notes.md` does not contradict `requirements.md`;
- maintainer-only comments are not copied into executable/user-facing fields;
- `expert_review.md` is regenerated after substantive technical changes.
- any displayed Requirements-Version in derived reviews/reports exactly matches the normative value in `requirements.md`.

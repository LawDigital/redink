// calendar-engine.js - skill-author v2.13 shipped deadline engine (generic, jurisdiction-agnostic).
// DO NOT EDIT in a generated skill: file_copy it to <skill>\scripts\calendar-engine.js and put all
// jurisdiction rules into data JSON (holidays, suspension windows, procedures without suspension).
// Pure ES5, UTC only, every loop bounded, no I/O. js_run usage: paste this file's text, then
//   return run(INPUT);
// INPUT = {
//   service_date: "YYYY-MM-DD"            (event day; not counted)
//   amount: 30                             (positive integer)
//   unit: "days" | "months"                ("weeks" / "years" also accepted)
//   procedure: "ordentlich"                (free string; matched against no_suspension_procedures)
//   refs: {
//     holidays:   ["2026-08-01", ...] | [{date, name}] | {"2026-08-01": "Bundesfeier"} | {years:[2026,2027], dates:{...}}
//     suspension: {windows: [...], no_suspension_procedures: ["summarisch"]} | [windows...]
//   }
// }
// Window forms (in refs.suspension.windows or refs.suspension_windows):
//   {label, start: "07-15", end: "08-15"}          fixed month-day, every year (end < start = crosses year end)
//   {label, start: "2026-07-15", end: "2026-08-15"} absolute dates
//   {label, easter_from: -7, easter_to: 7}          Easter-relative (Gauss/Meeus Easter computed here)
//   (from/to or von/bis are accepted as synonyms of start/end)
// Output: {fristbeginn, stillstandstage, stillstand_daten, rechnerisches_fristende, massgebendes_fristende,
//          verschoben, verschiebungsgrund, hinweis} or {error, massgebendes_fristende: "nicht berechenbar"}.
// Model: the event day is not counted; days run from the next day and do not run inside a suspension
// window; a month period ends on the same day number (or the month's last day) and is converted to its
// running length, so suspension days extend it; a Saturday, Sunday or listed holiday end moves to the
// next working day. Holiday data must cover every year the shift inspects, else an error is returned.
var CalEngine = {
  D: function (s) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s)), d; if (!m) return null; d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])); return d.getUTCMonth() === +m[2] - 1 ? d : null; },
  iso: function (d) { return d.toISOString().slice(0, 10); },
  add: function (d, n) { return new Date(d.getTime() + n * 864e5); },
  addMonths: function (a, n) { var y = a.getUTCFullYear(), m = a.getUTCMonth() + n, last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate(); return new Date(Date.UTC(y, m, Math.min(a.getUTCDate(), last))); },
  easter: function (y) { var a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451); return new Date(Date.UTC(y, Math.floor((h + l - 7 * m + 114) / 31) - 1, (h + l - 7 * m + 114) % 31 + 1)); },
  // holidays in any common shape -> {map: {iso: name}, years: {yyyy: true}}
  holidays: function (x) {
    var out = { map: {}, years: {} }, add = function (iso, name) { if (CalEngine.D(iso)) { out.map[iso] = name || "Feiertag"; out.years[iso.slice(0, 4)] = true; } };
    var walk = function (v, depth) {
      var i, k, it;
      if (!v || depth > 4) return;
      if (typeof v === "string") { add(v, null); return; }
      if (Object.prototype.toString.call(v) === "[object Array]") {
        for (i = 0; i < v.length; i++) { it = v[i]; if (typeof it === "string") add(it, null); else if (it && typeof it === "object") { if (it.date || it.datum) add(it.date || it.datum, it.name || it.label || it.bezeichnung); else walk(it, depth + 1); } }
        return;
      }
      if (typeof v === "object") {
        if (v.years && Object.prototype.toString.call(v.years) === "[object Array]") for (i = 0; i < v.years.length; i++) out.years[String(v.years[i])] = true;
        for (k in v) {
          if (!Object.prototype.hasOwnProperty.call(v, k) || k === "years") continue;
          if (CalEngine.D(k)) add(k, typeof v[k] === "string" ? v[k] : (v[k] && v[k].name) || null);
          else if (v[k] && typeof v[k] === "object") walk(v[k], depth + 1);
        }
      }
    };
    walk(x, 0);
    return out;
  },
  // suspension data in any common shape -> {windows: [...], none: [procedure names without suspension]}
  suspension: function (R) {
    var w = [], none = [], s = R.suspension, i, pick = function (o) { return o && (o.windows || o.suspension_windows || o.stillstand || o.periods); }, isArr = function (a) { return Object.prototype.toString.call(a) === "[object Array]"; };
    if (isArr(s)) w = s; else if (isArr(pick(s))) w = pick(s);
    if (isArr(R.suspension_windows)) w = w.concat(R.suspension_windows);
    if (s && isArr(s.no_suspension_procedures)) none = none.concat(s.no_suspension_procedures);
    if (isArr(R.no_suspension_procedures)) none = none.concat(R.no_suspension_procedures);
    for (i = 0; i < none.length; i++) none[i] = String(none[i]).toLowerCase();
    return { windows: w, none: none };
  },
  // "MM-DD", "DD.MM." or "YYYY-MM-DD" -> [month, day, year|null]
  md: function (v) { var m = String(v || ""); if (/^\d{4}-\d{2}-\d{2}$/.test(m)) return [+m.slice(5, 7), +m.slice(8, 10), +m.slice(0, 4)]; if (/^\d{2}-\d{2}$/.test(m)) return [+m.slice(0, 2), +m.slice(3, 5), null]; m = /^(\d{1,2})\.(\d{1,2})\.?$/.exec(m); return m ? [+m[2], +m[1], null] : null; },
  inWindow: function (d, W) {
    var y, i, w, s, e, p, q, E, t = d.getTime(), a, b;
    for (i = 0; i < W.length; i++) {
      w = W[i] || {};
      a = w.start || w.from || w.von; b = w.end || w.to || w.bis;
      for (y = d.getUTCFullYear() - 1; y <= d.getUTCFullYear(); y++) {
        if (typeof w.easter_from === "number" && typeof w.easter_to === "number") { E = CalEngine.easter(y).getTime(); s = E + w.easter_from * 864e5; e = E + w.easter_to * 864e5; }
        else {
          p = CalEngine.md(a); q = CalEngine.md(b);
          if (!p || !q) break;
          if (p[2]) { s = Date.UTC(p[2], p[0] - 1, p[1]); e = Date.UTC(q[2], q[0] - 1, q[1]); }
          else { s = Date.UTC(y, p[0] - 1, p[1]); e = Date.UTC(y + (q[0] * 100 + q[1] < p[0] * 100 + p[1] ? 1 : 0), q[0] - 1, q[1]); }
        }
        if (t >= s && t <= e) return w.label || w.name || "Stillstand";
      }
    }
    return null;
  }
};

function run(INPUT) {
  var fail = function (msg) { return { error: msg, massgebendes_fristende: "nicht berechenbar" }; };
  if (!INPUT || typeof INPUT !== "object") return fail("INPUT missing");
  var R = INPUT.refs || {}, ev = CalEngine.D(INPUT.service_date), n = Number(INPUT.amount), unit = String(INPUT.unit || "").toLowerCase();
  var proc = String(INPUT.procedure || "").toLowerCase(), H = CalEngine.holidays(R.holidays), S = CalEngine.suspension(R);
  var W = S.windows, i, first, nominal = null, L, d, g, cnt = 0, susp = [], start = null, end = null, why = [], wd, k;
  if (!ev) return fail("invalid service_date (YYYY-MM-DD): " + INPUT.service_date);
  if (!(n > 0 && n % 1 === 0)) return fail("invalid amount: " + INPUT.amount);
  if (!R.holidays) return fail("refs.holidays missing");
  for (i = 0; i < S.none.length; i++) if (proc && (proc === S.none[i] || proc.indexOf(S.none[i]) >= 0)) W = [];
  first = CalEngine.add(ev, 1);
  if (unit === "days" || unit === "weeks") L = unit === "weeks" ? 7 * n : n;
  else if (unit === "months" || unit === "years") { nominal = CalEngine.addMonths(ev, unit === "years" ? 12 * n : n); L = Math.round((nominal - first) / 864e5) + 1; }
  else return fail("unsupported unit: " + INPUT.unit);
  for (d = first, g = 0; g < 5000 && !end; g++, d = CalEngine.add(d, 1)) {
    if (CalEngine.inWindow(d, W)) { if (start) susp.push(CalEngine.iso(d)); continue; }
    if (!start) start = d;
    if (++cnt === L) end = d;
  }
  if (!end) return fail("loop bound hit");
  for (d = end, g = 0; g < 30; g++, d = CalEngine.add(d, 1)) {
    k = CalEngine.iso(d); wd = d.getUTCDay();
    if (!H.years[k.slice(0, 4)]) return fail("holiday data missing for " + k.slice(0, 4));
    if (wd === 6 || wd === 0) why.push(k + " " + (wd ? "Samstag" : "Sonntag"));
    else if (H.map[k]) why.push(k + " " + H.map[k]);
    else break;
  }
  if (g === 30) return fail("loop bound hit");
  return { fristbeginn: CalEngine.iso(start), stillstandstage: susp.length, stillstand_daten: susp,
    rechnerisches_fristende: CalEngine.iso(end), massgebendes_fristende: CalEngine.iso(d), verschoben: why.length > 0,
    verschiebungsgrund: why.length ? "Fristende auf Samstag/Sonntag/Feiertag verschoben: " + why.join(", ") : "keine Verschiebung",
    hinweis: "Fristberechnung ohne Gewaehr - bitte pruefen" };
}

# Host surfaces, files and delivery (for resources you author)

Read this when the target includes AutoPilot or several hosts, or when the authored skill produces files. Inky.md is already in the system prompt of every run, so authored resources should state only where they deviate from it.

## 1. The three tooling surfaces

Excel is **not** a host surface. Excel workbooks are handled by the Excel tools in Outlook and AutoPilot.

| Surface (`resource_index.host`) | Runs selected skills | Open-document tools | Attachments / drag & drop | Interactive |
|---|---|---|---|---|
| **Word** (`Word`) | yes: `skill_<name>`, plus `skill_use` in agent mode | `worddoc_*`, `word_doc_*` | no | yes (`ask_user`) |
| **Outlook Local Chat** (`Outlook Local Chat`; `Outlook` for other interactive Outlook tooling) | yes: `skill_<name>`, plus `skill_use` in agent mode | no | yes: dropped files are visible to `list_attachments`/`read_attachment` in agent mode | yes (`ask_user`) |
| **Outlook AutoPilot** (`Outlook AutoPilot`) | yes, only as dynamic `skill_<name>` (no generic `skill_use`) | no | yes (mail attachments) | **no**: `ask_user` is a no-op; writes are limited to the workspace root |

- **`skill_use` vs. `skill_<name>`.** `allowed-tools` is enforced as the execution scope only when the skill is entered via `skill_<name>`. Author as if it were always enforced.
- **Host resolution in authored skills.** Branch on `resource_index.host`. Block when the host is not supported. If `host` is empty (a sub-agent), rely on the tools actually offered. Never assume a tool exists.

## 2. Compatibility gating

1. State the supported hosts explicitly in the body.
2. Step 0 checks the host and that each required tool is offered. If one is missing, stop before doing any partial work, and end with the task-status footer, status blocked, and a reason naming the tool and the supported hosts.
3. A tool that is unavailable on one supported host is allowed only when the body gates it (for example, "in Word use `worddoc_extract_text`; in Outlook use `read_attachment`").
4. Agents: `allowed-tools` are hard dependencies, and `optional-tools` hold host- or config-dependent helpers (`m365_*`, attachment tools, `agent_workspace_*`, `js_run`). `python_execute` is never a standard dependency.

## 3. Files, deliverables and delivery (authored skills)

- **Word:** create or finalize real files in the host staging/output area (or a connected workspace). Word collects outputs itself. For a returned Word file, perform every mutation and comment first, then finalize with `word_save_as` where available. If anything mutates the file after the save, finalize again.
- **Outlook Local Chat:** inputs arrive as attachments or dropped files; an attachment name is **not** a filesystem path. Produce the output in the session/staging area; the host collects it. A workspace copy is persistence, not delivery.
- **AutoPilot:** unattended. Produce files only in the locations exposed to the run. The host validates, registers and delivers them. Never invent or set host delivery state (registered deliverables, final flags, forced delivery, attachments).
- **Real file finalization.** When the outcome is a file, the workflow must call an actual create/save/export tool and report the path **that tool returned**. A path mentioned in prose is not a file. If the file cannot be produced, the status is blocked, never complete.
- **Single final output.** Prefer in-place tools (`word_write` / `word_markup` with batch `tasks`). When a tool creates a new file, use one stable output name rather than `_v1`, `_v2` or `_final`. Delete or clearly label intermediates, and name the one final file.
- **Handoffs.** Check that each step produces the representation the next step accepts (path vs. attachment vs. workspace item vs. open document vs. text). Add an explicit bridge (save, copy or stage), or do not chain the steps.
- **Skill assets.** Copy templates from the skill's `references/` to staging or the workspace before modifying them. Never edit assets in place.
- **`deliverable-count: N`** (fixed file count only). Every invocation must pass exactly N `expected_artifacts` (`logical_deliverable_id` + `output_slot_id`), and the slots become a hard completion contract.
  - Author the skill around those stable logical slots, and name the finalizer for each slot.
  - The host binds the physical revisions itself. Do not make the model invent `artifact_id` rotations.
  - Omit this key for answer-only or interactive-only skills.
- **`deliverable-required-effects`** (with `deliverable-count` > 0): `content_mutated` means a plain copy, move or rename does not count as the deliverable. For Excel transformations, `worksheet_mutated.<sheet>` (sheet name lowercased; ä/ö/ü → ae/oe/ue; other separators → `_`) demands a real mutation of that sheet, so a partial edit of another sheet is not success. Declare an effect only when the task truly requires it.
- **`required-successful-tools`:** list tools whose success is an invariant for `complete`, for example a mandatory post-mutation QA read. Each must also be in `allowed-tools`. There is no ordering and no call count.
- **Review metadata.** New comments, tracked changes and annotations use the author `Inky` unless the user names someone else; pass it explicitly where the tool supports it. Never rewrite existing authorship.
- **Context.** Use a file-backed full-text path (`text_export_to_text` → `text_analyze_file`) when one LLM must reason over a whole document that fits. Use semantic retrieval only for large sources or genuine retrieval tasks. Use `context_expand` only for results that were genuinely truncated.
- **Bounded recovery.** An exact-anchor edit gets one attempt plus at most two recoveries per logical operation.

## 3a. Word files with formal requirements (pattern: `word-output.md`)

| Tool | Hosts | What it can fix | What it cannot |
|---|---|---|---|
| `word_apply_template` (skill, template relative to the skill's `references/`, output_name, substitutions) | Word, Outlook, AutoPilot | every style of the template (body, headings, margins, numbering, header/footer) | placeholders only in the main body; placeholder paragraph becomes one plain run |
| `word_write` (replace / insert_before / insert_after / append / delete_paragraph, batch `tasks`) | Word, Outlook, AutoPilot | Markdown `#`..`######` → style ids `Heading1..6`, rest → Normal (the template's styles) | lists get `ListParagraph` without numbering; German style ids (`berschrift1`) are not found |
| `create_word_document` (`markdown_content` or `markdown_path`, `file_name` without .docx) | Outlook, AutoPilot (**not Word**) | body font/size (`base_font_name`, `base_font_size`), `style_preset` (consulting/executive/minimal/plain), `professional_layout`, `accent_color`, `page_orientation`, `table_style_name`, `header_text`, `footer_text`, `show_page_numbers`, `include_cover`/`cover_*`, `use_repository_default_design` | no template path; heading sizes, margins, spacing and numbering are hard-coded; omitted arguments fall back to defaults (prompt suggests `consulting`) |
| `word_format` / `worddoc_format` | file / open doc | direct bold/italic/size (integer pt)/colour/align, a style id | no font name, spacing, margins, style definitions: never use it to "restyle" template output |

- Deterministic formatting needs a template in the skill's `references/` (copied at authoring time with `file_copy`, Skill-author mode on) or a design in `designs\word\` (admin only, read-only for skill-author: `office-design-repository-authoring.md`).
- Without a template only the argument set in `references/word-format.json` is deterministic, and only if passed in full on every call and retry.
- No guaranteed tool reads fonts or sizes back (`read_word_document_details`, `word_extract_text` return text only); `python_execute` is optional, never a hard dependency.

## 3b. AutoPilot variant of an authored skill (moved from templates.md §F in v2.15)

- Every tool must be `Yes` in the AutoPilot column. Do not use `ask_user`: missing information goes into the reply and the run blocks.
- If the skill always returns a fixed number of files, set `deliverable-count: N` and name the finalizer for each file. Optionally list the finalizer in `required-successful-tools`; it must also be in `allowed-tools`.

## 4. AutoPilot deployment hand-off (put this in the final answer when the target is AutoPilot)

1. **Select the skill** `skill_<name>`, every `agent_<name>` it uses, and every declared helper tool in the AutoPilot session / tool selection.
2. **Sender policy:** restrict the trigger to the intended (internal) senders. For example, `ONLY skill_<name>` for those senders narrows the session to this skill and its declared helpers. The policy narrows an authorised session; it does not enable an unselected skill.
3. **Restart AutoPilot** after installing or changing a resource. Resources are not hot-reloaded into a running session.
4. **Test** with a test mail from an allowed sender: a typical case and a case with a missing attachment. Check the reply and the AutoPilot log (`%APPDATA%\RedInk\autopilot-logs\`).
5. Say explicitly that you did **not** test it in AutoPilot. skill-author cannot run there.

## 5. Inky.md

- One `Inky.md` per root is read. The central and local files are concatenated, with the local file appended after the central one. `Inky_for_AutoPilot.md` is not read by the current code; it is only a template.
- The current hosts do **not** let author mode write `Inky.md` or anything under `designs\`: the write roots are only `skills\` and `agents\`. Do not look for workaround paths. Say so plainly and give the exact absolute target path built from `resource_index` (`<local_root>\Inky.md`, e.g. `C:\RedInk\Library\.inky-VISCHER\Inky.md`, even if the file does not exist yet; or `<root>\designs\<app>\`), the manual step (open or create the file in a text editor, paste at the end, save, start a new chat), and the text to paste in a `~~~~` fence. Do not search for the file with `file_list` (V24-S09 listed `.`, `C:\`, `/mnt/data` and gave no path).
- Never add Inky.md rules that tell the model to ignore, discard or not reuse files tagged as retained from earlier messages. Retention is controlled by host configuration, not by Inky text.
- Do not use Inky.md as a collection point for organisation-specific rules. Suggest a skill or a reference file instead. If the user insists, follow their choice.

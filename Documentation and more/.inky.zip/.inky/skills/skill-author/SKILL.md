﻿---
name: skill-author
description: Drafts, reviews, and revises Red Ink skills and agents that work with the Word and Outlook tooling loops, using only registered host tools and the correct resource directory layout.
allowed-tools:
  - text_read
  - text_write
  - text_search
  - tool_loader
  - tool_describe
  - js_run
model: agentdefaultmodel
---

# Skill Author

Use this skill to create or revise Red Ink skills and agents so they work with the tooling loops.

## Hosts that support tooling

There are exactly three tooling surfaces. Excel does NOT support tooling; never target it.

- **Word** — the desktop add-in. Has live-document tools (`worddoc_*`, `word_doc_*`) for the currently open document, plus file-based `word_*` and `workspace_*` tools.
- **Outlook Local Chat / Agent** — the interactive chat in Outlook. Full tool surface including `m365_*`, `skill_use`, and `memory_*`.
- **Outlook AutoPilot** — unattended background runs. Used by only a few users but MUST be considered. It exposes a reduced surface.

### AutoPilot constraints (critical)

Per `Red_Ink_Tool_List.md`, under AutoPilot the following are NOT available:
`skill_use`, `memory_put`/`memory_get`/`memory_list`/`memory_delete`, all `m365_*` tools, `web_content_retriever`, and the Word live-document tools.

Consequences:
- AutoPilot cannot load a skill via `skill_use`, so a skill's instructions only apply where `skill_use` exists (Word and Outlook Local Chat).
- Do not author a skill whose workflow depends on session memory or `m365_*` and expect it to run under AutoPilot.
- AutoPilot runs are locked to their workspace root; writes outside it are denied.

## Authoritative tool list

The file `Red_Ink_Tool_List.md` in the `.inky` directory is the source of truth for tool names and per-host availability (columns: Word, Outlook, AutoPilot). Before putting any tool in `allowed-tools`:

1. Read it with `text_read` (or `tool_loader` for full definitions).
2. Confirm the tool exists and is `Yes` for every host the skill targets.
3. When several tools overlap (for example the different Word editors `worddoc_*`, `word_*`, and `word_doc_*`, or `word_write` vs. `word_markup` vs. `word_format`), call `tool_describe` to read each candidate's exact parameters and instructions and pick the one whose parameters match the task. `tool_describe` inspects tools without making them callable; call it with `tool`, `tools`, or a `prefix` (for example `word`), or with no arguments for a full index.
4. Only reference selected online sources if they are configured; include them (or the placeholder `selected_online_sources`, or a wildcard such as `swiss-caselaw*`) in `allowed-tools`.

## Prerequisite: author mode

Writing into the resource directory only works when "Skill-author mode" is enabled in "Manage Skills & Agents". When it is off, resource folders are read-only.

The `skill_use` response's `resource_index` reports the current access state as explicit flags. Read them BEFORE any write and act deterministically:

- `author_mode_active` — `true` when Skill-author mode is on. When `false`, all resources are READ-ONLY.
- `local_writes_allowed` — `true` when writes to the local `.inky` root are permitted (i.e. author mode is on).
- `central_writes_allowed` — `true` only when the additional "Also allow writing to the shared/central resource folder" option is enabled. This may be impossible to enable in a locked-down configuration; never assume it.

Rules:
- If `author_mode_active` is `false` or `local_writes_allowed` is `false`: do not create or edit any file. Tell the user to enable Skill-author mode, then stop.
- Write to the central root ONLY when `central_writes_allowed` is `true`. Otherwise write everything under the local root and never target the central root — it will be denied.
- Prefer local unless the user explicitly asks to change the shared set.

If a write is denied, tell the user to enable author mode (and, for shared changes, the central option). Do not attempt workarounds.

## Resource directory layout

Resources are discovered from two roots: the central root and the local root (the user's `.inky` directory). Local entries override central entries with the same name.

    <root>/
      Inky.md                        # optional project-wide guidance
      Red_Ink_Tool_List.md           # authoritative tool/availability reference
      skills/
        <skill-name>/
          SKILL.md                   # required; YAML frontmatter + Markdown body
          scripts/                   # optional helper scripts
          references/                # optional reference files/templates
      agents/
        <agent-name>.md              # single-file agent, OR
        <agent-name>/AGENT.md        # folder-based agent

Always build target paths from the ABSOLUTE roots given in the `skill_use` response's `resource_index`, never from a relative path. A relative path such as `skills/<name>/SKILL.md` resolves into the temporary workspace, NOT the resource tree, and the resource will be lost. The index provides `local_root`, `central_root` (may be empty), `author_mode_active`, `local_writes_allowed`, `central_writes_allowed`, and a precomputed `new_resource_root` (the correct root for new resources given the current permissions). Treat `new_resource_root` as authoritative: it already accounts for whether central writing is allowed, so always target it and never override it toward `central_root` when `central_writes_allowed` is `false`.

When creating a new skill, write `new_resource_root + "\skills\<name>\SKILL.md"`. When creating a new agent, write `new_resource_root + "\agents\<name>\AGENT.md"` (or `new_resource_root + "\agents\<name>.md"`). Parent folders are created automatically. Edits under a resource root are re-scanned automatically, so a written skill or agent is discovered in the same session.

By default a newly created skill or agent is ACTIVE immediately. Only if the user explicitly asks for it to be created inactive (e.g. "create it disabled", "draft it but do not activate it yet"), add `enabled: false` to the YAML frontmatter. An entry with `enabled: false` stays on disk and remains visible and editable in "Manage Skills & Agents", but is not offered to or callable by the model until the user sets `enabled: true` (or removes the line). Never add `enabled: false` on your own initiative.

## Frontmatter schema

Both skills and agents use YAML frontmatter:

- `name`: unique resource name (kebab-case).
- `description`: one concise sentence used in the skill/agent listing.
- `allowed-tools`: list of registered tool names (verified against `Red_Ink_Tool_List.md`).
- `model` (optional): a special-task-model key, e.g. `agentdefaultmodel` or `researchmodel`.
- `network` (optional, default false): opt-in for tools that touch the network (`js_run` with navigation, web tools).
- `timeout` (optional): seconds; 0 = default.
- `enabled` (optional, default true): set `false` ONLY when the user explicitly asks for the resource to be created or kept inactive. A disabled resource remains on disk and editable but is not offered to the model.

## How skills and agents run

- A skill is loaded on demand by the main loop via `skill_use(name, input?)`. Its Markdown body becomes the instructions the model follows in subsequent turns. Skills share the main conversation; they do not run in isolation. `skill_use` is unavailable under AutoPilot.
- An agent is delegated via `agent_<name>(task, context?)` and runs in an ISOLATED context; it cannot see the main conversation, so `task`/`context` must be self-contained. It returns `{summary, result, memory_key, stub}`.
- Prefer a skill for user-facing, multi-step guidance; prefer an agent for a bounded sub-task that would otherwise consume large context.

## Host-aware tool selection

- `worddoc_*` and `word_doc_*` address the currently OPEN Word document (Word host only; read-oriented by default). In the Word chatbot, the inline `[#REPLACE …]`/`[#INSERTAFTER …]` command channel takes precedence for changes to the open document.
- `word_*` (e.g. `word_extract_text`, `word_markup`, `word_apply_template`) operate on `.docx` files by path and are available in Word, Outlook, and AutoPilot.
- `workspace_*` and `text_*` operate on files inside the allowed boundary and are available in all three surfaces.
- `m365_*`, `memory_*`, and `skill_use` are Word + Outlook only (not AutoPilot).
- Do not list a tool for a host where its column is `No` unless the skill has explicit host branching.

## Runtime environment and limitations

- Skills run inside a tooling loop: each turn is either tool calls or final prose. During active tooling, final prose must end with exactly one `<TASK_STATUS>{"status":"complete"|"blocked","reason":"..."}</TASK_STATUS>` footer.
- `text_write` creates UTF-8 text files only. Never use it for PDF, DOCX, XLSX, PPTX, images, archives, audio, or video; use the dedicated producing tools instead.
- Default per-file size limit is 2 MiB.
- `js_run`: the `code` parameter is the BODY of an async function; return a top-level value. Network is disabled unless `network` is opted in.
- User-facing prose uses the language of the latest user request.

## Load your tools first

Before reading or writing any file, call `tool_loader` once for the tools you
will need this run (typically `text_read`, `text_write`, and `text_search`).
This avoids "tool not exposed at turn start" retries.

## Finding the file to edit (do this FIRST)

The `skill_use` response for this skill includes a `resource_index` listing every
discovered skill and agent with its exact `file` path. To modify an existing
skill or agent:

1. Look up its entry in `resource_index` by name.
2. Read that exact `file` path with `text_read`.
3. Write the change back to the SAME `file` path with `text_write`.

Never guess a path, never create a new folder for an existing resource, and do
not use `agent_workspace_*` tools here — the `.inky` resource directory is not a
workspace, so those tools will fail with "No active workspace".

## Authoring workflow

1. Confirm the target host(s) and whether a skill or agent is the right form. Then check the access flags in `resource_index`: if `author_mode_active` is `false` or `local_writes_allowed` is `false`, do not read on to write anything — tell the user to enable Skill-author mode and end the turn with `<TASK_STATUS>{"status":"blocked","reason":"Skill-author mode is disabled; resources are read-only."}</TASK_STATUS>`.
2. Read `Red_Ink_Tool_List.md`; verify every intended tool exists and is available on each target host.
3. Inspect existing resources with `text_read`/`text_search` before editing; reuse shared workers instead of proliferating one-off agents.
4. Draft or revise ONE file per turn and explain each change.
5. Use `js_run` for deterministic validation (JSON well-formedness, tables, dates, sorting, deduplication).
6. Write NEW resources to an absolute path built from `resource_index.new_resource_root`; edit EXISTING resources at their exact `file` path from `resource_index`. Never use a relative path. State the exact absolute path created or changed.
7. Remove stale or duplicate resources instead of accumulating overlapping workflows.

## Review checklist

1. Target host(s) identified; Excel not targeted.
2. Every tool name exists in `Red_Ink_Tool_List.md` and is available on each target host.
3. AutoPilot-incompatible dependencies (`skill_use`, `memory_*`, `m365_*`) flagged if the skill must run under AutoPilot.
4. Cross-host tools removed unless explicit host branching is present.
5. Shared tools preferred for shared workflows; no one-off agent proliferation.
6. Write/comment tools used only after inspection.
7. Safe failure behavior included.
8. Deterministic validation with `js_run` where applicable.
9. Frontmatter valid; `name` unique; `description` a single clear sentence.

## Required body sections for authored resources

Every skill/agent body should include: purpose, inputs, target host(s), workflow, tool usage, output format, and limitations/safe-failure behavior.

## Output format

Return revised Markdown files or a concise patch plan. If writing files, state exact absolute paths created or changed, and whether they went to the local or central root.
Always begin your final response with a one-line confirmation naming the skill and resource you changed, e.g. "Applied skill-author: updated agent 'advisor' (model → advisormodel1)."
# Guided Case Assessment

## Purpose

`guided-case-assessment` is a generic engine for administrator-defined case assessments. The engine
itself contains no domain decision rules. Each assessment is a self-contained package under
`references/assessments/<assessment-id>/`.

The runtime flow is intentionally exclusive: once this skill matches the user's workflow, no preliminary
research or parallel substantive review is performed unless the selected package explicitly allows it.

1. select exactly one assessment from `references/assessments.json`;
2. load that assessment's `profile.json`;
3. collect/derive facts defined in `intake.json`;
4. ask only the next outcome-determinative missing fact;
5. evaluate `checklist.json` in its declared order and precedence;
6. execute outcome-specific instructions from `actions.json`;
7. create mandatory configured outputs;
8. return the configured concise result.

## Recommended authoring model — experts should not write JSON

For substantive maintenance, use this hierarchy:

- `requirements.md` — **single normative substantive master**;
- `source_notes.md` — source/provenance, deliberate interpretations, ambiguity and maintenance notes;
- `intake.json`, `checklist.json`, `actions.json`, `profile.json` — derived technical implementation;
- `expert_review.md` — non-normative human-readable mirror of what the implementation will actually do.

A subject-matter expert should normally review `requirements.md`, `source_notes.md` and
`expert_review.md`, not hand-edit JSON.

The included `skill-author` contains a generic recipe mechanism. When asked to create or synchronize a
reference case for this skill, it reads the applicable authoring recipe from its own `references/`
directory, updates the human-readable source first, preserves stable ids where possible, regenerates
affected technical structures and validates cross-file consistency.

### Copy/paste prompts for Red Ink

Create a new assessment package:

> Create a new reference case for the case-assessment skill from the attached expert policy. Keep the substantive master human-readable, derive the technical JSON files from it, and create an expert-review file. Do not invent substantive rules; ask when an outcome-determinative ambiguity cannot be resolved from the source.

Synchronize a returned expert revision:

> Here is the subject-matter expert's revised source for reference case `<id>`. Synchronize the existing case, preserve stable IDs where the substantive concept is unchanged, update only affected technical structures, show the substantive changes, and regenerate the expert-review file.

Ask only for instructions:

> Explain, with a concrete copy/paste prompt, how I can create a new reference case or synchronize a file returned by the subject-matter expert. Do not modify files yet.

## Folder structure

```text
guided-case-assessment/
├─ SKILL.md
├─ README.md
└─ references/
   ├─ assessments.json
   └─ assessments/
      └─ <assessment-id>/
         ├─ README.md              # optional maintainer/distribution note, not runtime
         ├─ profile.json
         ├─ intake.json
         ├─ checklist.json
         ├─ actions.json
         ├─ requirements.md
         ├─ source_notes.md
         ├─ expert_review.md        # recommended
         └─ <optional output specs/templates>
```

There are intentionally no root-level `profile.json`, `intake.json`, `checklist.json` or `actions.json`.
`assessments.json` is the only assessment-selection registry.

## Relationship between the files

```text
expert/source document
        ↓
requirements.md        = what applies (normative)
        ↓
intake.json             = which facts must/can be collected
checklist.json          = how those facts are evaluated
actions.json            = what each result means / what happens next
profile.json            = package wiring, policies and outputs
        ↓
expert_review.md        = readable mirror of the implemented logic

source_notes.md         = where the rules came from / deliberate interpretations
```

Do not silently maintain the same substantive rule in several places. If a rule changes, change the
normative source first and then synchronize the derived artifacts.

## Assessment package contract

### `profile.json`

Defines metadata, language policy, runtime policies and points to the files that belong to the assessment.
It must not contain hidden substantive decision rules that exist nowhere in `requirements.md`.

### `intake.json`

Defines the facts the assessment understands. Every checklist fact must be declared here. Use stable
semantic ids. Categorical choice ids such as `yes/no/unknown` should remain language-independent even
when display labels/questions are localized.

### `checklist.json`

Defines criterion evaluation and outcome precedence. Every substantive rule should be traceable to a
section in `requirements.md`. Stable ids should survive wording-only revisions.

### `actions.json`

Maps every possible final outcome to its configured next steps and user-facing presentation. Every
outcome that can be emitted by `checklist.json` must exist here.

### `source_notes.md`

Documents source/version, deliberate interpretations, known ambiguity and maintenance notes. It is not
a second normative rulebook.

### `expert_review.md`

A non-technical review mirror generated from the implemented package. If an expert edits it, treat the
edits as review instructions: reconcile them into `requirements.md` first, then regenerate JSON and
`expert_review.md`.

### Maintainer-only comments

Sample/reference Markdown may contain HTML comments with distribution disclaimers or maintainer notes.
The runtime skill ignores these comments and never exposes them in questions, results, reports or
actions unless the user explicitly asks to inspect maintainer metadata.

## Selection behavior

The user may name an assessment explicitly or describe the configured workflow naturally. Registries may
contain multilingual aliases. Selection and decision logic must not depend on the literal language of the
request; stable ids and semantic matching are controlling.

If exactly one enabled assessment exists, a generic assessment request may select it automatically. If
several enabled assessments plausibly match, the skill asks which one to use and does not load all packages.

## Question behavior

Interactive Word / Outlook Local Chat asks exactly one material fact per `ask_user` call and re-evaluates
after every answer. Outlook AutoPilot never calls `ask_user`; it sends necessary clarification questions
to the requester and resumes from the later thread reply.

## Research and analysis boundary

The engine does not research by default and does not perform preliminary/parallel substantive review.
Missing requester facts are clarified with the requester, not filled from the internet, a knowledge base
or general model knowledge. Attachments/workspace files may be read only to establish declared intake
facts unless the selected profile explicitly defines a broader dependency.

## User-facing result contract

The normal result is concise: plain-language outcome, decisive reason, configured next step, material
limitations and produced outputs. Do not show raw internal ids/enums/rule expressions unless the requester
asks for technical/audit detail.

## Validation checklist

Before enabling or synchronizing a package:

1. every registry profile path exists;
2. every profile-declared runtime file exists;
3. all JSON parses;
4. `assessment_id` is consistent;
5. every checklist fact exists in intake;
6. every emitted outcome exists in actions;
7. ids are unique;
8. conditional expressions use declared fields/values;
9. substantive executable rules are traceable to `requirements.md`;
10. `source_notes.md` does not contradict `requirements.md`;
11. maintainer-only comments are not copied into executable/user-facing fields;
12. interactive and AutoPilot clarification behavior is correct;
13. external research stays off unless explicitly configured;
14. `expert_review.md` is regenerated after substantive technical changes;
15. positive, negative, exception and missing-information regression paths are tested.

## Included reference case: `swiss-aml-berater`

The included package demonstrates a complete multi-step assessment with conditional intake fields,
criterion precedence, multilingual interaction policy, a fixed professional Word report whose user-facing language follows the requester and
outcome-specific actions.

It is provided as a **reference pattern**. Its hidden maintainer comments carry the distribution
disclaimer; that disclaimer is intentionally not part of the runtime interaction. Any organisation using
the pattern remains responsible for substantive/legal approval before reliance.

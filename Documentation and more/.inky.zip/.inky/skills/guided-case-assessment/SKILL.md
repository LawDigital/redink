---
name: guided-case-assessment
description: Runs configured case assessments/checklists, including the configured Swiss AML adviser assessment when present in this skill's registry. Use it when the requester asks to assess a case under a named or configured screening, triage, eligibility, compliance, onboarding, scope, policy or checklist workflow. Once chosen, follow the configured assessment before unrelated research: use only its declared case facts, rules and sources unless the selected profile explicitly enables external research. It asks only outcome-determinative follow-up questions, returns a concise user-facing result, and creates any mandatory configured compliance record output.
allowed-tools:
  - ask_user
  - text_read
  - workspace_get
  - workspace_search
  - workspace_extract_text
  - list_attachments
  - read_attachment
  - search_in_attachments
  - worddoc_extract_text
  - word_extract_text
  - word_apply_template
  - create_word_document
  - js_run
  - agent_shared_case_criterion_checker
model: agentdefaultmodel
---

# Guided Case Assessment

This skill is a domain-agnostic assessment engine. All substantive decision logic comes from the selected assessment package under `references/assessments/`.

### Reference-language and maintainer metadata

Reference-package logic must remain independent of display language. Stable fact ids, choice ids,
criterion ids and outcome ids carry semantics; never make a decision by testing whether the requester
used any particular localized wording such as `yes`, `no`, or another translated label.

If the selected profile declares a `language_policy`:
- follow its interaction-language rule for questions and concise user-facing results;
- faithfully translate configured labels/actions when allowed, without adding or changing substantive rules;
- honor any fixed output language declared for a report/template;
- never translate or alter technical ids/rule semantics.

HTML comments in supporting Markdown are maintainer/distribution metadata. Ignore them for runtime
decision-making and never quote, summarize or surface them in intake questions, results, actions,
reports or ordinary interaction unless the requester explicitly asks to inspect maintainer metadata.


## Binding execution boundary

When the requester asks for a workflow that matches this skill, this assessment flow is the FIRST substantive work. Do not perform any preliminary legal analysis, web search, knowledge-base lookup, general research, document review, alternative checklist, or model-based issue spotting before resolving the assessment. Do not run another tool merely to get background context.

Before an assessment is selected, use only the registry metadata needed for selection. After selection, use only the selected package and requester/source facts needed by its intake. Read attachments or workspace material only to establish declared intake facts; do not review them for additional issues outside the selected checklist.

Never supplement an assessment with general model knowledge, web research, legal research, a knowledge base, or another assessment unless the selected profile explicitly enables and defines that dependency. A request to perform separate research or a separate review is a distinct task and must not be silently merged into the assessment.

## 1. Resolve exactly one assessment

Read `<skill dir>\references\assessments.json` using the exact absolute skill directory supplied by `skill_use.resource_index`.

Select one enabled assessment in this order:

1. explicit `assessment_id` named by the requester;
2. exact title or alias match;
3. if exactly one assessment is enabled, select it;
4. one uniquely plausible match using only registry metadata (`title`, `aliases`, `description`, `match`);
5. otherwise ask the requester to choose among the plausible enabled assessments.

Do not research to decide which assessment the requester meant. Do not load multiple assessment packages "just in case".

Interactive Word / Outlook Local Chat: use one `ask_user` call for the selection question.

Outlook AutoPilot: never use `ask_user`; send the selection question to the requester and end blocked.

## 2. Load only the selected assessment package

Load the selected `profile.json`. Resolve files declared by the profile relative to the directory containing that profile, unless a path is explicitly rooted at `references/`.

A profile normally declares:
- `intake_file`;
- `checklist_file`;
- `actions_file`;
- optional supporting references;
- optional message or Word templates;
- optional external-research policy.

Do not read files belonging to unselected assessments.

If a required file is missing, unreadable, internally inconsistent or outside its declared validity, stop safely. Do not repair the package using model knowledge.

If the profile is marked `example_only`, `draft`, `expired` or equivalent, disclose that limitation before relying on its result.

## 3. Build a traceable case record

Use only fields declared in the selected `intake.json`.

For each field track one state:
- `stated` — supplied by the requester or permitted source material with a substantively determinate value;
- `derived` — deterministically derived from established facts and configured references;
- `missing` — not established;
- `conflict` — supplied sources disagree materially;
- `declined` — the requester explicitly refuses or declines to provide a fact that is still material.

Do not turn assumptions, defaults, examples, silence, an explicit refusal, or an `unknown`/equivalent non-determinate choice into established facts. A field remains unresolved whenever its value is not sufficient to evaluate the material checklist rule that depends on it.

Honor `required_for_decision`, `required_for_outputs` and conditional `when` rules. Any field whose active `when` condition is satisfied and whose `required_for_decision` is true remains material until it has a substantively determinate value, even if a checklist rule does not name that field directly. A conditionally irrelevant field must not be asked merely because it is empty.

### Completion invariant

An assessment is `completed` only when the configured outcome is determinable under the checklist and **no still-material outcome-determinative fact is unresolved**. `missing`, `conflict`, `declined`, and a configured unknown/non-determinate answer are unresolved.

Before treating any outcome as completed, validate the actual decision path against all configured exclusions, exceptions, thresholds, classifications, and alternative branches that must be resolved to reach that outcome. In particular, a positive/in-scope outcome must not be finalized merely because a positive trigger is present if a still-material configured exclusion or exception remains unresolved. Facts on branches that the configured logic has genuinely short-circuited are not material and need not be collected.

Read user-supplied source material only when needed for this assessment. Use targeted source tools rather than broad discovery.

## 4. Ask one material question at a time

Before each clarification, determine the first still-material criterion under checklist precedence and the single missing/conflicting fact needed to evaluate it.

If the requester explicitly says that they will not provide a still-material fact, mark that fact `declined`; do not reinterpret the refusal as `no`, `not_applicable`, or any other substantive value. Do not repeatedly ask the same declined fact in the current run unless the requester later volunteers a usable answer. This rule applies equally in interactive hosts and AutoPilot. Proceed only to the incomplete-assessment handling in sections 7–8.

### Interactive Word / Outlook Local Chat

Call `ask_user` for exactly one fact per invocation.

For `choice` fields:
- pass the configured choices as clickable options;
- `input_type=choice`;
- `multi_select=false`;
- set `allow_free_text=true` unless the assessment package explicitly requires a closed answer set.

For `multi_choice` fields:
- pass configured choices;
- `multi_select=true`;
- follow any package-specific free-text policy.

After every answer:
1. update the case record;
2. re-evaluate criterion/outcome precedence;
3. ask another question only if it is still outcome-determinative.

Never combine several intake questions into one `ask_user` call.

Cancellation or unusable input leaves the fact unresolved and the assessment blocked.

### Outlook AutoPilot

Never call `ask_user`.

If outcome-determinative facts are missing and have not been explicitly declined:
1. do not guess;
2. send only the currently necessary clarification questions;
3. ask the requester to reply;
4. end with a blocked task status.

If the current thread contains an explicit refusal to provide a still-material fact, do not ask for that fact again in the same run. Mark it `declined` and use the provisional incomplete-assessment handling in sections 7–8; do not create completion-only outputs.

On a later reply, rebuild the case from the current thread and new information. Do not depend on volatile in-memory state across mails.

## 5. Apply the configured checklist

Read only the selected `checklist.json` and its declared supporting references.

For each material criterion:
- use only established case facts and selected reference material;
- apply the configured rule exactly;
- use only configured status values;
- preserve declared evaluation order;
- apply outcome precedence exactly.

A missing, conflicted, declined, or otherwise non-determinate required fact produces `unknown` unless the checklist explicitly defines another behavior. A configured `unknown` answer is not evidence that the underlying substantive condition is absent.

After checklist evaluation, run the completion invariant from section 3. A syntactically matched outcome is not a completed assessment if reaching that outcome still depends on any unresolved material fact. In that case treat the assessment as incomplete / `NEEDS_MORE_INFORMATION` (or the package's equivalent non-final state), not as the matched final outcome.

`agent_shared_case_criterion_checker` is optional. If used, send exactly one criterion with only the relevant established facts and selected reference excerpts. The parent assessment remains authoritative.

## 6. External research and parallel-analysis policy

External research and parallel substantive analysis are off unless the selected profile explicitly enables them. This prohibition includes preliminary research or issue spotting before the checklist is applied. For example:

`"external_research": {"enabled": true, ...}`

When disabled, do not call web, legal, case-law, knowledge-base or doctrinal research tools to fill missing case facts or to "verify" the configured checklist.

A separate requester instruction to research the underlying law/policy is a separate task and must not silently alter the assessment result.

## 7. Produce configured actions and outputs

Only after checklist evaluation, read `actions.json`. Execute final-outcome actions only if the completion invariant is satisfied. An incomplete assessment may use only actions explicitly configured for the package's missing-information/non-final state; never execute actions that presuppose a completed final outcome.

Before creating an output, first verify that the assessment is completed, then satisfy any fields whose `required_for_outputs` includes that output/action id. `mandatory_when_assessment_completed` means exactly that: the output is mandatory only after completion and is forbidden while the assessment remains incomplete. Do not reopen already short-circuited checklist branches merely to fill a report: the report must distinguish established facts, derived findings, unresolved facts that were not outcome-determinative, and checklist questions that were not applicable/not reached.

If any still-material outcome-determinative fact is `missing`, `conflict`, `declined`, or otherwise non-determinate, do **not** create a Word compliance record or any other completion-only output, even if the currently established facts point strongly toward one result.

If the selected profile declares a mandatory Word compliance record output, create it **in addition to** the normal concise user-facing assessment result. Use `create_word_document` unless the profile explicitly specifies a different supported Word-creation tool. The document must be a real `.docx` produced by the successful tool call in the host-provided working/session location; use the actual returned path. A prose draft or proposed filename is not a substitute.

For a mandatory compliance record, build the document from the complete traceable case record and the configured assessment only. If the selected output declares a `content_spec_file`, that file is a binding output contract. Where it defines fixed headings, order, wording, typography, spacing, blank fields, filename rules or a no-discretion layout policy, follow those instructions exactly. Do not add optional sections, decorative elements, alternative layouts or inferred author/reviewer names. The profile-specific content specification overrides the generic minimum structure below.

At minimum include:
- document title and assessment type;
- assessment date using the current host/session date at the time of execution (do not ask the requester for today's date);
- case/matter reference or designation if supplied;
- all case facts established from the requester or permitted source material, with no invented facts;
- a clear indication of the source/state of material facts where useful (`stated`, `derived`, `conflict`, or not established);
- the checklist path actually applied, including the decisive question(s), any applicable exclusion/exception, and branches not reached because the configured logic short-circuited;
- the plain-language outcome;
- a self-contained, reasoned explanation connecting the established facts to the configured rules and outcome;
- configured next steps/escalation;
- the continuing-observation/reassessment reminder where configured;
- material limitations, unresolved but non-decisive facts, and profile warning/status where applicable.

The compliance record must be written as an archive-ready internal record, not as a chat transcript. Do not expose raw internal rule expressions, enum values or criterion ids unless needed for traceability; use readable headings and labels. Do not attribute the assessment to, or name, any specific law firm or organisation unless that name is supplied as a fact by the requester for the individual case and the selected package expressly requires it.

For Word templates use `word_apply_template` with the configured template path. Never modify a reference template in place.

If a mandatory file output fails or no real output path is returned, keep the assessment result but mark the file-producing portion as blocked/failed and state that the compliance record could not be created. Do not claim that a file was created, a message was sent or a third party was contacted unless the corresponding tool action actually succeeded.

## 8. Final response — user-facing, not diagnostic

The normal final response is a decision message, not an audit trail. Keep it short and easy to scan. Do NOT expose internal assessment ids, profile ids, raw outcome enums, criterion ids, rule expressions, evaluation-order details or a criterion-by-criterion table unless the requester explicitly asks for technical details or an audit.

For a completed assessment, use this structure:

1. **Result** — one plain-language outcome label. Prefer `actions.json` field `label`; otherwise convert the configured outcome to readable language.
2. **Why** — one to three short sentences containing only the decisive established fact(s) and the decisive configured rule. State explicitly when the checklist short-circuited and therefore no further facts were needed.
3. **Next step** — the configured action(s), phrased as practical user instructions.
4. **Limitation** — include only if materially relevant, for example `example_only`, unresolved factual uncertainty, expiry, or an output/action that could not be completed.
5. Mention outputs actually produced, if any.

Omit empty sections. Do not add a section describing which assessment was selected unless that information is needed to disambiguate the result. Do not repeat the user's facts in a long table. Do not narrate the internal workflow.

Example style:

`**Result: Out of scope.**`

`The configured entry criterion is outcome-determinative; additional transaction or threshold questions are not required for this result.`

`**Next step:** Document the outcome and decisive fact; reassess if outcome-determinative facts change.`

If clarification is still required and the requester has not refused the needed fact, do not provide a provisional result, technical checklist dump or unrelated research. Ask only for the next material fact and return blocked.

If the requester explicitly refuses to provide one or more still-material facts, stop the clarification loop and provide a concise **provisional / incomplete assessment based only on the established information so far**. It must:
- state prominently that the assessment is incomplete and is not a final configured outcome;
- summarize the currently established facts and what they presently indicate without converting uncertainty into a final positive or negative result;
- identify the declined/unresolved material fact(s) in user-facing terms and explain briefly how they could affect the result;
- state that completion-only actions have not been executed;
- state that no mandatory Word compliance record has been created because the assessment is not completed;
- invite the requester to provide the missing fact(s) later if they want the assessment completed.

Do not label such a response with a final outcome from `actions.json`, do not claim the assessment is completed, and do not create the configured Word document.

## Orchestrator compatibility

- Use `ask_user` only when it is actually advertised and the current run is interactive. Ask one material question per call where the workflow requires incremental clarification. In AutoPilot or any non-interactive run, do not call `ask_user`; return/send the minimum concrete clarification needed or mark the affected branch blocked instead of guessing.
- Do not assume `python_execute` exists. The Python helper is installation-dependent and is not a standard foundation capability. Use deterministic host tools or configured scripts that are actually advertised; never substitute model-estimated computation for a missing deterministic tool.
- The parent skill owns end-user interaction. Sub-agents must receive a bounded task and must not be expected to ask the user.
- Every `agent_<name>` call must include a stable opaque `subagent_task_id` for that logical delegated task and `expected_artifacts`. Use `expected_artifacts: []` for analysis-only workers. If a delegated file-producing task is expected, pass the complete opaque artifact contract required by the host before the run; do not invent or broaden artifact identities later.
- Treat an agent's missing optional host capability as a reason to adapt the bounded task or return a limitation, not as permission to bypass the selected workflow.

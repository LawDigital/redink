<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction, questions, results, reviews, or reports. -->
# Mandatory Word output — Swiss AML Adviser Assessment

## 1. Purpose and mandatory output

After every completed assessment, create exactly one Word document with `create_word_document` in addition to the concise user-facing result. The document is the filing-ready assessment record and must be based on the complete case record and only the configured rules.

**Hard gate:** do not call `create_word_document` unless the assessment satisfies the completion rule in `requirements.md` section 11. If any still-material outcome-determinative fact is missing, conflicted, answered only as `Not yet known`, or explicitly declined, the assessment is incomplete and this output contract must not be executed. A provisional assessment after requester refusal is chat-only until the missing material information is later resolved.

This file is the binding output contract. Layout, order, table structure, tool arguments, and filename construction are fixed. The model must not choose an alternative design.

The report's `Requirements-Version` must be read directly from `requirements.md` → `Document status` → `Requirements-Version`. No other version source is permitted.

The canonical contract below is English. Render user-facing headings, labels, findings, and actions in the requester's language where practical, while preserving the exact structure, semantic order, Requirements-Version, and stable decision meaning. Do not change logic based on translated wording.

## 2. Fixed `create_word_document` arguments

Use exactly these presentation parameters:

- `document_title`: localized equivalent of `Compliance Assessment — Swiss AML Adviser Rules`
- `base_font_name`: `Arial`
- `base_font_size`: `9.5`
- `page_orientation`: `portrait`
- `professional_layout`: `true`
- `style_preset`: `consulting`
- `accent_color`: `#17365D`
- `include_cover`: `false`
- `header_text`: omit/empty
- `footer_text`: omit/empty
- `show_page_numbers`: `false`
- `document_author`: omit/empty
- `design_name`: omit
- `visuals`: omit

Do not choose another preset, accent colour, cover, or decorative element. Use native Markdown tables; do not construct pseudo-tables or Unicode borders. Page margins are owned by the renderer when `professional_layout=true`; do not invent unsupported margin arguments.

## 3. Fixed filename rule

Pass this filename pattern to `create_word_document.file_name`:

`YYMMDD AML Adviser Assessment - {case_short_designation}`

`YYMMDD` is the host/session execution date and is not asked from the user.

Build `case_short_designation` deterministically:
1. use non-empty `case_designation`;
2. otherwise use `activity_description`;
3. otherwise use `Case Assessment`.

Then, in order: replace line breaks with spaces; collapse repeated spaces; trim whitespace and trailing punctuation; replace `\ / : * ? " < > |` with `-`; collapse repeated hyphens; limit to 60 characters at the last complete word within the limit; do not creatively rewrite, abbreviate, or supplement the text. Only a technically required collision suffix added by the tool is permitted.

## 4. Fixed appearance

- A4 portrait.
- Arial 9.5 pt through the tool arguments.
- Neutral dark-blue accent `#17365D`.
- No cover, logo, image, diagram, decorative graphic, header, footer, page number, or table of contents.
- Compact paragraphs; avoid long prose blocks.
- Tables are mandatory for metadata, case facts, and assessment path.
- No invented subtitles or extra sections.
- No internal technical IDs, enum values, or system/product names.
- Normally fit within 1–2 pages when the actual facts permit, without omitting content merely to save space.

## 5. Fixed document structure

Use the following elements in exactly this order. Translate the user-facing labels/headings to the report language if needed, but do not add, remove, merge, or reorder sections.

### Document title

Canonical heading: `# Compliance Assessment — Swiss AML Adviser Rules`

### Metadata table

| Assessment metadata | Value |
| --- | --- |
| Assessment date | `{current date in the report language's normal unambiguous date format}` |
| Requirements-Version | `{exact value from requirements.md → Document status → Requirements-Version}` |
| Reviewer | `____________________________` |
| Case / matter reference | `{case_reference or "—"}` |
| Case designation | `{case_designation, otherwise activity_description without filename sanitisation; otherwise "—"}` |
| Outcome | `**{exact localized user-facing outcome label corresponding to actions.json}**` |

The outcome is intentionally repeated later in section 4. `Reviewer` always remains the blank line; do not insert a person, system, product, organisation, or model name automatically.

## 6. Section 1 — Scope

Exactly one short paragraph of at most two sentences stating the concrete activity/mandate assessed and that the assessment determines whether it is an adviser mandate under the configured Swiss AML adviser rules. Do not repeat detailed facts or outcome reasoning here.

## 7. Section 2 — Case facts

Always use a two-column Markdown table:

| Case fact | Finding |
| --- | --- |
| `{localized human-readable label}` | `{established value}` |

Rules: include each actually established decision- or documentation-relevant fact once; follow `intake.json` order; do not repeat `case_reference` or `case_designation`; include `activity_description` first; localize choice values for the report language; include only established or safely derived facts; omit unasked/short-circuited facts; do not restate rules or outcome.

## 8. Section 3 — Assessment and reasoning

Always document the reached assessment path as a three-column Markdown table:

| Assessment step | Finding | Application |
| --- | --- | --- |
| `{localized short description of reached question}` | `{outcome-determinative established fact}` | `{concise application of configured rule and consequence}` |

Include only reached steps in `checklist.json` order. Explain an applied exclusion/exception completely in the same row. Do not add a generic law overview or legal analysis outside the configured rules. Do not output internal criterion IDs or rule expressions.

If a real short-circuit occurred, add one localized sentence directly below the table conveying: `Further assessment steps were unnecessary because the outcome had already been determined.` Otherwise omit it.

## 9. Section 4 — Outcome

First line: bold localized equivalent of `Outcome: {user-facing outcome label}`.

Then exactly one paragraph of at most three sentences connecting only the decisive facts to the outcome. For an adviser mandate, state the positive trigger and absence of a decisive exception. For a financial intermediary mandate, state that the adviser assessment yields to the financial-intermediary rules.

## 10. Section 5 — Follow-up actions

Use a compact Markdown list of the practical actions configured for the outcome in `actions.json`.

Always end the regular list with a localized equivalent of: `Reassess the mandate if outcome-determinative facts change.`

Only if a material filing-relevant uncertainty actually remains may one final bullet follow: bold localized equivalent of `Open point: ...`.

## 11. Redundancy rule

The outcome label is deliberately repeated in the metadata table and section 4. Otherwise keep master data in metadata, facts in section 2, rule application in section 3, conclusion in section 4, and actions in section 5. Repeat a fact in sections 3/4 only as needed for intelligible reasoning.

## 12. Tool-call contract

Call `create_word_document` with this parameter set; only `markdown_content`, `file_name`, and localized `document_title` contain case/language-dependent values:

```json
{
  "markdown_content": "<document exactly under this output contract>",
  "file_name": "<YYMMDD AML Adviser Assessment - case_short_designation>",
  "document_title": "<localized Compliance Assessment — Swiss AML Adviser Rules>",
  "base_font_name": "Arial",
  "base_font_size": 9.5,
  "page_orientation": "portrait",
  "professional_layout": true,
  "style_preset": "consulting",
  "accent_color": "#17365D",
  "include_cover": false,
  "show_page_numbers": false
}
```

Do not add other optional presentation arguments unless a later version of this output contract explicitly requires them.

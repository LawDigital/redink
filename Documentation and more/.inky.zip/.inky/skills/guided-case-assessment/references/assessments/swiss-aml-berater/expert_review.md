<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction, questions, results, reviews, or reports. -->
# Expert review — Swiss AML Adviser Assessment

**Requirements-Version represented:** read from `requirements.md` when this review is generated; this review is not an independent version source.

This file is a **non-normative reverse rendering** of the implemented assessment logic. Any substantive change must first be reflected in `requirements.md`; the technical JSON files and this review must then be regenerated/synchronized.

## Facts the assessment may require

Depending on the path already taken, the assessment may require: concrete mandate activity; proceedings connection; pure notarisation; testamentary foundation; state/court appointment; financial-intermediary mandate; domicile/registered office; organ function and entity type; real-estate transaction and configured exceptions; operating/non-operating status where material; relevant legal act and causal participation; configured Question 6 exceptions; and optional case reference/designation for documentation.

## Decision path

| Step | Core question | Consequence |
| --- | --- | --- |
| 1 | Does a configured exclusion apply? | Yes → no adviser mandate; otherwise continue. |
| 2 | Is this a financial intermediary mandate? | Yes → financial-intermediary rules prevail; otherwise continue. |
| 3 | Is a domicile or registered office provided? | Yes → adviser mandate; otherwise continue. |
| 4 | Is an organ function assumed? | Depending on entity type: no adviser mandate or adviser mandate; if no organ function, continue. |
| 5 | Is there a real-estate transaction and does an exception apply? | No exception → adviser mandate; exception/no real-estate transaction → continue. |
| 6 | Is there a relevant legal act with causal participation and no exception? | Yes → adviser mandate; otherwise no adviser mandate. |

## Possible outcomes

- **Adviser mandate** — handle under the approved AML adviser process and reassess if facts change.
- **No adviser mandate** — document the controlling exclusion/exception or absence of a relevant legal act and reassess if facts change.
- **Financial intermediary mandate** — inform the responsible AML specialist function and apply the relevant financial-intermediary rules.
- **More information required** — obtain only the next outcome-determinative fact.

A completed assessment also produces the configured Word assessment report.

## Expert approval checklist

- [ ] Entry exclusions and their order are correct and complete.
- [ ] Financial-intermediary treatment is correct.
- [ ] Domicile/registered-office rule is correct.
- [ ] Organ-function rule and operating/non-operating distinction are correct.
- [ ] Real-estate definition, threshold, and seven exceptions are correct.
- [ ] Relevant legal acts, causal participation, and Question 6 exceptions are correct.
- [ ] Outcome precedence and short-circuit logic are correct.
- [ ] Follow-up actions are correct.
- [ ] Language-neutral interaction/report policy is appropriate.
- [ ] Interpretation notes in `source_notes.md` are correct.
- [ ] The Requirements-Version in `requirements.md` matches the approved substantive state.

## Technical note

`intake.json`, `checklist.json`, `actions.json`, and `profile.json` are the technical implementation of the approved substantive logic. Stable IDs should be preserved across language-only changes. Substantive changes are made first in `requirements.md` and then synchronized into technical structures.

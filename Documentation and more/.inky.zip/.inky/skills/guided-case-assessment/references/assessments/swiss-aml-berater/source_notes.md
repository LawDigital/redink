<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction, questions, results, reviews, or reports. -->
# Source and interpretation notes — Swiss AML Adviser Assessment

## Role of this file

`requirements.md` is the single normative substantive rule source for this reference case. This file documents provenance, deliberate interpretation choices, known uncertainties, and maintenance notes. It must not create a competing decision logic.

## Deliberate interpretation and implementation points

1. The assessment follows six configured questions and short-circuits branches that can no longer affect the outcome.
2. Providing a domicile or registered office is treated as an adviser mandate without an additional minimum duration.
3. Organ functions distinguish operating entities, charitable foundations, operating associations with a Swiss registered office, and other/non-operating entities.
4. Operating/non-operating classification uses only the definitions and indicators in `requirements.md`.
5. Real-estate transactions use the definition and seven exceptions in `requirements.md`, including the combined "below CHF 5 million" plus Swiss bank/financial-intermediary condition.
6. For participation in financial transactions, only the configured legal acts trigger further testing. Causal participation is interpreted as described in `requirements.md`; purely abstract enquiries are excluded.
7. For the configured M&A test, a non-operating entity on the client side is relevant.
8. A change in outcome-determinative facts requires reassessment.

## Language rule

The canonical reference package is maintained in English. Decision logic is language-independent because it relies on stable ids and choice values rather than literal answer wording. Runtime interaction and report language may follow the requester. A translation must preserve the exact substantive meaning and must not branch or change rules based on literal translated wording.

Local-language aliases may exist in registry metadata solely to make discovery reliable. They are not a second substantive source.

## Maintenance

Missing outcome-determinative facts must be obtained from the requester when interactive clarification is available. External research is disabled for the assessment itself. Separate research into underlying law or internal policy must be treated as a separate task and must not silently modify the configured assessment logic.

## Versioning

The substantive Requirements-Version is maintained exclusively in `requirements.md` under `Document status`. `profile.json` contains only a technical pointer to that location. `expert_review.md` and the compliance report display the value read there and are not independent version sources.

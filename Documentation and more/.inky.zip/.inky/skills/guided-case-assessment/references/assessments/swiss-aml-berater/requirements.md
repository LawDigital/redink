<!-- SAMPLE DISCLAIMER: This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk. This comment is maintainer/distribution metadata and must not be surfaced during normal skill interaction, questions, results, reviews, or reports. -->
# Requirements — Swiss AML Adviser Assessment

## Document status

**Requirements-Version:** `0.2`

This version identifies only the substantive rule set in this `requirements.md`. It is the single normative source of the Requirements-Version. Derived JSON files, technical metadata, `expert_review.md`, and reports must not maintain an independent second version number.

## Governing basis and interpretation

These requirements are the authoritative substantive rules for the configured Swiss AML adviser assessment. During the assessment they take precedence over general model knowledge.

Apply the questions in the order below. Ask only for facts that can still affect the unresolved outcome. Do not add entry criteria, thresholds, exceptions, or legal rules that are not contained in this package.

## 1. Checklist — Question 1: activities excluded from an adviser mandate

Determine whether the activity:

1. relates to court, criminal, administrative, or arbitration proceedings; this includes not only representation but also advice concerning preparation or conduct of proceedings, fact finding, assessment of litigation risk, prevention of such proceedings, or enforcement of their outcome;
2. is pure notarisation without ancillary advisory work;
3. concerns the establishment of a testamentary foundation; or
4. concerns appointment as an organ or representative by FINMA or another public authority or court.

If at least one item is **Yes**, there is **no adviser mandate** under this checklist. If all are **No**, continue.

## 2. Checklist — Question 2: financial intermediary mandate

Determine whether the matter is a **financial intermediary mandate**.

- If yes: inform the responsible AML specialist function and apply the rules for financial intermediary mandates. Those rules are similar to, but not identical with, the adviser rules.
- If no: continue the assessment.

Do not replace this question with a generic test about receipt of or control over assets.

## 3. Checklist — Question 3: domicile or registered office

Determine whether the mandate includes providing a **domicile or registered office** for a company, a branch, or another legal entity.

If yes, this checklist always treats the mandate as an **adviser mandate**. No additional minimum duration applies in this assessment.

## 4. Checklist — Question 4: organ function

Determine whether a person assumes an **organ function** in connection with the mandate.

- If no: continue to Question 5.
- If yes: determine whether the entity is an **operating entity**, a **charitable foundation**, or an **operating association with its registered office in Switzerland**.
  - If yes: **no adviser mandate**.
  - If no: **adviser mandate**.

Under the interpretation configured for this assessment, the Swiss registered-office requirement applies only to the association.

## 5. Distinguishing operating and non-operating entities

Use only the following definitions and indicators.

**Non-operating entity**: legal persons, companies, institutions, foundations, trusts, fiduciary companies, and similar arrangements that are not established or maintained for operating or supporting the operating activity of an undertaking or group, including in particular domicile companies.

The classification of other non-operating entities is not exhaustively settled; the configured interpretation specifically identifies passive holding companies. Indicators include:
- a c/o address;
- no employees;
- pure aggregation of participations through an intermediate holding company.

Indicators of an **operating entity** include:
- operational business activity;
- employees;
- group management or another material group function, such as treasury;
- a start-up in a build-up phase with planned operational activity.

If classification is outcome-determinative and unclear, ask only for the minimum facts needed to apply these indicators.

## 6. Checklist — Question 5: real estate

Determine whether the mandate concerns a **real-estate transaction**. This can also apply to an M&A transaction where the affected company holds real estate.

For this checklist, real-estate transactions include:
- purchase and sale of land or real estate;
- legal transactions that have economically the same effect as purchase or sale in relation to control over real estate;
- creation for consideration of a usufruct or building right.

If no, continue to Question 6. If yes, test the exceptions below.

## 7. Checklist — Question 5: real-estate exceptions

A real-estate transaction does not by itself create an adviser mandate if at least one of the following exceptions is established:

1. connection with family law, marital law or matrimonial property law, inheritance, or gifts;
2. transaction between affiliated persons;
3. value of the real estate **below CHF 5 million** and payment and receipt of the purchase price **exclusively through a Swiss bank / Swiss financial intermediary**; processing payment through a notary as payment/escrow agent is disregarded;
4. owner-occupied residential property;
5. acquisition of residential property in Switzerland as replacement property within the meaning of Art. 12 para. 3 lit. e StHG;
6. transfer of agricultural businesses or land under the BGBB to persons intending to farm them themselves;
7. transfer of real estate in connection with land consolidation.

If at least one exception applies, continue to Question 6. If all exceptions are established as not applying, there is an **adviser mandate**.

## 8. Checklist — Question 6: participation in financial transactions

The catalogue of **relevant legal acts** in section 9 is decisive. Question 6 is pursued only if at least one of those legal acts exists.

The term **financial transaction** may be misleading and is deliberately interpreted broadly for this checklist.

**Participation** means advice that causally contributes to such a legal act. Examples include:
- advice preparing or implementing the legal act;
- advice on legal, tax, or accounting modalities;
- drafting legal acts or documents;
- opening a banking relationship;
- registration in a register.

Only **abstract enquiries/analysis** are clearly outside this concept.

## 9. Checklist — Question 6: relevant legal acts

Relevant legal acts are:

1. **formation of, or advice on management or administration of**, a company or other legal entity in Switzerland or abroad, if the entity is **non-operating**;
2. a **financing transaction for a non-operating entity**;
3. advice concerning **contributions to or distributions by a non-operating entity**;
4. an **M&A transaction** in which a non-operating entity acts as buyer or seller on the **client side**.

For item 4, the configured interpretation is that a non-operating entity on the client side is relevant, even though the underlying wording is not unambiguous; it is not limited to a non-operating entity on the counterparty side.

If all relevant legal-act questions are No, there is **no adviser mandate**. If at least one relevant legal act exists and there is causal participation, test the exceptions in section 10.

## 10. Checklist — Question 6: exceptions

Where Question 6 is otherwise applicable, there is **no adviser mandate** if at least one of the following exceptions is established:

1. transaction between affiliated persons or group companies;
2. connection with family law, marital law or matrimonial property law, inheritance, or gifts;
3. transfer of an entity with a value **below CHF 5 million** and payment and receipt of the purchase price **exclusively through a Swiss bank / Swiss financial intermediary**.

If no exception applies, there is an **adviser mandate**.

## 11. Ongoing monitoring

Cases must be monitored because facts may change and a mandate may later fall within the adviser rules. Examples:

- A litigation client asks additional questions from another legal area: open a new matter and reassess.
- Real estate is identified during M&A due diligence.
- A price initially below CHF 5 million increases or additional valuable consideration is added.
- Payment planned through a Swiss bank is changed to a foreign bank.
- During an M&A transaction the client decides to establish an intermediate holding company.

The final action must therefore always state that the assessment must be repeated if outcome-determinative facts change.

## 12. Mandatory compliance documentation as a Word file

For every completed assessment, create a filing-ready Word assessment report in addition to the short user-facing result. Generate the report as a real `.docx` with `create_word_document`; it does not replace the concise dialogue result.

The report format, filename, fixed layout, content order, tables, and `create_word_document` parameters are governed exclusively by `compliance_report.md`. The report must display the exact Requirements-Version read from this file under `Document status` and must not obtain that version from another source.

The canonical package text is English, but runtime interaction and the report may follow the requester's language. Translation must preserve the stable field/criterion/outcome semantics and must not alter the decision logic.

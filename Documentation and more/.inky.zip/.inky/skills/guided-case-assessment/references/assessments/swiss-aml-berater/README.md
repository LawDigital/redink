# Reference sample — Swiss AML Adviser Assessment

> **Sample notice:** This reference sample is provided for informational and demonstration purposes only. Each user must independently verify its professional, legal, and substantive correctness and suitability before use. Use is at the user's own risk.

This notice is intended for maintainers and distribution of the reference sample. `README.md` is deliberately **not** a runtime assessment reference and must not appear during ordinary skill interaction.

## Substantive expert review

- `requirements.md` — normative substantive master.
- `source_notes.md` — source, interpretation, and maintenance notes.
- `expert_review.md` — human-readable reverse rendering of the implemented logic.

## Technical derivation

- `intake.json` — facts/questions.
- `checklist.json` — decision logic.
- `actions.json` — outcomes/follow-up actions.
- `profile.json` — package wiring, policies, and outputs.
- `compliance_report.md` — fixed output contract for the Word assessment report.

Changes should normally be synchronized with `skill-author` from an expert-approved Word or Markdown source. Subject-matter experts should not need to maintain JSON manually.

## Completion contract

The assessment is complete only when every still-material decision fact on the reached path is substantively resolved. `Not yet known`, missing/conflicting information, and an explicit refusal do not resolve a material fact. A positive adviser-mandate result must not be finalized while a configured exclusion or exception that could still defeat it remains unresolved.

If the requester explicitly refuses material information, runtime behavior is provisional only: summarize the assessment on the established facts, identify the unresolved decision point, and do not create the Word compliance report or execute any other completion-only action.

## Versioning

The subject-matter expert maintains the substantive version only in `requirements.md`, e.g. `Requirements-Version: 0.2`. The Word report must display exactly that value. Technical files must not maintain an independently editable second version number.

Example instruction to Red Ink / `skill-author`:

> "Here is the expert-approved revision for `swiss-aml-berater`. Update `requirements.md`, set the approved Requirements-Version there to `0.3`, synchronize the derived JSON files and `expert_review.md`, and verify that the compliance report reads and displays that Requirements-Version."

Excel design folder for this design set. No Excel carrier is currently configured.
The active design-set selector applies to Excel exactly as it does to Word and PowerPoint.
Place approved .xltx carriers here or reference them through this set's designs.json.

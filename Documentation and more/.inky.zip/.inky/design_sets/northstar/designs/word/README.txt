WORD DESIGNS — QUICK REFERENCE
==============================

1. CARRIER
Use a working .docx in designs/word/. DOCX is recommended for new designs. Structured DOCX designs
are cloned and filled directly as OOXML; Word/COM is not started. Legacy non-slot carriers may still
use the Word/COM compatibility path. Generic creation with no carrier is OOXML-only.

2. CATALOG (designs/designs.json)
A catalog entry has a stable top-level id/name/aliases/description/enabled and a "word" object.
Word fields currently used by routing/rendering are:

    "template_file": "word/My_Memo.docx"        required when a carrier is used
    "guidance_file": "word/My_Memo.md"          optional; explicit companion path
    "style_policy_file": "word/MY_STYLES.md"    optional; shared style/rendering policy
    "use_template_styles": true                  preserve native carrier styles
    "document_type": "memo"                     routing metadata (free descriptive value)
    "language": "en"                            routing metadata; evaluated after document_type; use "any" when unrestricted
    "organization": "Example Org"               optional routing metadata
    "default_for": "memo"                       optional category default
    "is_default": true                           optional single global Word default

Paths are relative to designs/. Example: word/My_Memo.docx. Do not put absolute paths in the catalog.

Selection order: an explicitly user-requested design_name; otherwise document_type FIRST; then language and organization within that type; then applicable default_for; then the single is_default Word design only when no document type is known. A generic/blank design must not beat a matching memo/letter merely because language=any. Interactive mode asks only if the format is genuinely unclear
and no default resolves it. AutoPilot does not wait for a clarification.

Retry rule: once the host has resolved an effective design (including an implicit default), that design
remains binding for a retry after failure. A retry may not silently switch to another design or neutral
format.

3. FILE LOADING / FALLBACKS
The normal control plane is designs.json. After one design is selected, only its referenced Word files
are used:

    template_file      binary DOCX carrier
    guidance_file      design-specific slots/behavior
    style_policy_file  shared styles/rendering rules

If guidance_file is omitted, a selected carrier may use a same-basename .md for compatibility.
style_policy_file has no filename-guessing fallback: reference it explicitly in designs.json.
Standalone Office carriers can still be discovered as legacy loose designs; an explicit catalog entry
with the same id wins. Local repository entries override central entries with the same stable id.

A configured structured design that is invalid is a hard error. It must not silently fall back to a
neutral document. Presentation-only parameters such as include_cover do not invalidate a structured
design: when the carrier owns document structure, include_cover is ignored and logged.

4. STRUCTURED SLOTS
Put speaking markers directly in the DOCX:

    [[RI:Recipient]]
    [[RI:Text]]

The marker name is only a locator. Meaning is declared in the design companion under the exact heading:

    ## Word template slots

    - placeholder: [[RI:Recipient]]
      purpose: Recipient shown in the address field.
      source: template_fields.recipient
      required: yes

    - placeholder: [[RI:Text]]
      purpose: Main substantive body at this exact location.
      source: markdown_content
      required: yes

Slot properties:
- placeholder: exact [[RI:...]] marker; [[ and ]] are required.
- purpose: model-facing meaning of the location.
- source: markdown_content or template_fields.<key>.
- required: yes/no (true/false and required/optional are accepted compatibility values).
- content: optional; text or markdown. If omitted, markdown_content => markdown and
  template_fields.<key> => text.

Bare values are canonical. Backticks, straight quotes and typographic quotes are compatibility input,
not required syntax. A markdown slot must occur exactly once in word/document.xml and be the only
visible content of its paragraph. Plain-text slots may occur in supported Word stories. Unresolved
[[RI:...]] markers reject the output.

5. SHARED STYLE POLICY
If several carriers share styles, put them once in a shared policy and point every catalog entry to it
with style_policy_file. Do not repeat identical mappings in every design companion.

Renderer-active mappings use the exact heading:

    ## Word body styles

    - paragraph: Exact Body Style
    - heading1: Exact Heading 1 Style
    - heading2: Exact Heading 2 Style
    - bullet1: Exact Bullet Style
    - numbered1: Exact Numbered Style

Supported semantic keys:
- paragraph
- heading1 .. heading6
- bullet1 .. bullet9
- numbered1 .. numbered9

Only declared structural levels are allowed. Missing heading/list levels are rejected rather than
silently substituted.

An optional validated inventory uses:

    ## Word native styles

    - normal0: Exact Native Style Name
    - hanging0: Exact Native Style Name

Native-style keys are descriptive ids; values are exact Word paragraph-style names. This inventory is
validated but does not by itself map Markdown semantics.

6. RENDERING RULES
Machine-readable rendering switches use the exact heading:

    ## Word rendering rules

Currently supported switch:

    - heading_numbering: native

Values:
- native: Word heading styles own visible numbering. Markdown headings should contain title text only;
  the host also removes a leading manual numbering prefix defensively.
- preserve: keep numbering written in Markdown heading text.

Only explicit "- key: value" lines inside this section are configuration. Explanatory prose and code
examples are ignored by the parser. A design companion may override a shared heading_numbering rule
when that one carrier genuinely differs. A companion should normally not repeat shared body/native mappings. It may, however, redeclare one
body-style semantic as an explicit carrier-specific override (for example `- paragraph: Normal 0` for a
letter whose body must differ from the shared family default). The merged contract uses the companion
value for that semantic. Rendering-rule switches such as heading_numbering may likewise be overridden
locally.

7. TABLE AND VISUAL POSITIONING
Tables inherit the horizontal text start of the most recent generated paragraph. The OOXML renderer
resolves that paragraph's effective native style/numbering indent and writes the matching table indent.
This applies to both structured designs and generic OOXML documents. Visuals do not automatically
inherit the previous paragraph indent; they retain their own visual positioning/size rules.

Native visuals remain compatible with templates and style policies. Put one exact `[[visual:ID]]` marker
in markdown_content and supply the matching `visuals` definition. The OOXML renderer replaces the
marker with the native DrawingML/chart/image object without starting Word.

8. MARKDOWN WHITESPACE
Markdig can emit formatting whitespace text nodes around HTML blocks. Red Ink normalizes block-boundary
whitespace centrally before Word insertion/rendering. Internal spaces between inline runs are preserved.
This applies to OOXML Word rendering and to the legacy shared Markdown-to-Word insertion path.

9. DESIGN-SET SWITCHING
A complete alternative repository can live under `.inky/design_sets/<set>/designs/`. The optional
`.inky/design_sets/active.json` selects one set. Example:

    {
      "schema_version": 1,
      "active_set": "example_a",
      "sets": {
        "example_a": "example_a/designs",
        "example_b": "example_b/designs"
      }
    }

Change only `active_set` to switch the repository Red Ink exposes. Each selected tree is resolved exactly
like the normal `.inky/designs` directory. If the selector is absent, invalid or points outside
`design_sets`, Red Ink falls back to `.inky/designs`.

10. AUTHORING CHECK
- open the DOCX in Word and confirm it edits normally before installing it;
- place slots exactly where content belongs;
- copy WORD_DESIGN_GUIDANCE_TEMPLATE.md for a new companion;
- copy WORD_STYLE_POLICY_TEMPLATE.md for a shared style family;
- register filenames/routing in designs.json;
- verify every declared slot/style exists in every referenced carrier;
- test one representative document before deployment.

Runtime routing hints for create_word_document:
- document_type: primary routing hint (for example memo, letter, note, generic).
- document_language: secondary routing hint (for example de or en).
- design_name: use when the user explicitly named a particular design.

Ordered Markdown lists:
- Declare numbered1, numbered2, ... in Word body styles when ordered lists are allowed.
- The renderer writes the visible decimal marker deterministically and applies the declared native paragraph style for indentation.
- A design may override numbered styles locally, just like paragraph or heading mappings.

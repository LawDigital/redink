# NORTHSTAR Word style policy

This shared policy applies to all configured NORTHSTAR Word designs. Individual template companion files
should describe only their document-specific slots and usage. Do not duplicate these mappings in every
NORTHSTAR companion file.

The exact Word style names below were verified against the configured NORTHSTAR DOCX carriers. The
renderer uses the native styles rather than recreating their font, spacing, numbering or indentation.

## Word body styles

- paragraph: Randziffern
- heading1: heading 1
- heading2: heading 2
- heading3: heading 3
- heading4: heading 4
- heading5: heading 5
- bullet1: Punktiert 1
- bullet2: Punktiert 2
- bullet3: Punktiert 3
- numbered1: Hängend 1
- numbered2: Hängend 2
- numbered3: Hängend 3

## Word native styles

- normal0: Normal 0
- normal1: Normal 1
- normal2: Normal 2
- normal3: Normal 3
- hanging0: Hängend 0
- hanging1: Hängend 1
- hanging2: Hängend 2
- hanging3: Hängend 3
- bullet0: Punktiert 0
- bullet1: Punktiert 1
- bullet2: Punktiert 2
- bullet3: Punktiert 3
- marginalnumbers: Randziffern
- heading1: heading 1
- heading2: heading 2
- heading3: heading 3
- heading4: heading 4
- heading5: heading 5


## Word rendering rules

- heading_numbering: native

`native` means that the Word heading styles own the visible numbering. The model must write only the
heading text (for example `## Contractual Liability`, not `## 1. Contractual Liability`). The host also
removes a leading manual numbering prefix defensively before applying a numbered native heading style.
A design-specific companion may override this with `heading_numbering: preserve` when its heading styles
do not supply numbering.

## Style behavior

- Ordinary generated body paragraphs use Randziffern.
- Markdown heading levels 1 through 5 use heading 1 through heading 5.
- Heading levels 6 through 8 must not be used for NORTHSTAR documents. The strict body-style contract
  rejects an undeclared heading level rather than silently substituting another style.
- Native heading numbering is authoritative. Markdown heading text must not contain manual prefixes
  such as I., A., 1., a), (i), 1.1 or 2.3. The renderer also removes a leading manual numbering prefix
  from a heading before applying a numbered native heading style, so model variance does not produce
  duplicated numbering.
- A first-level bullet list that follows a Randziffern paragraph is subordinate to that paragraph.
  Therefore Markdown bullet level 1 maps to Punktiert 1, not Punktiert 0. The native numbering data in
  the carrier places Punktiert 1 one indentation step deeper than the Randziffern text start.
- Markdown bullet levels 2 and 3 map to Punktiert 2 and Punktiert 3. A fourth Markdown bullet nesting
  level is not declared and is rejected.
- Punktiert 0 remains an available native NORTHSTAR style for content that intentionally starts at the
  root bullet position, but ordinary generated Markdown lists do not use it automatically.
- Normal 0 through Normal 3 and Hängend 0 through Hängend 3 are validated as available native NORTHSTAR
  styles and may be used by future explicit semantic mappings without changing shared runtime code.
- Ordered Markdown list levels 1 through 3 map to Hängend 1 through Hängend 3. The host adds the visible decimal list marker deterministically; the native Hängend style owns the hanging indentation. A fourth ordered-list nesting level is rejected.

# Shared Word style policy

Reference this file from one or more Word entries in `designs.json` with `style_policy_file`.
Use exact native Word paragraph-style names from the DOCX carrier. Keep common mappings here once;
do not copy them into every design companion.

## Word body styles

- paragraph: Normal
- heading1: Heading 1
- heading2: Heading 2
- bullet1: List Bullet

Supported keys: `paragraph`, `heading1..heading6`, `bullet1..bullet9`, `numbered1..numbered9`.
Undeclared structural levels are rejected.

## Word rendering rules

- heading_numbering: preserve

`heading_numbering` accepts only:
- `native` — Word styles supply visible heading numbering; Markdown title text must not carry it.
- `preserve` — keep any numbering present in Markdown heading text.

Only explicit `- key: value` lines in this section are machine-readable; prose is ignored.

## Word native styles

- normal: Normal
- heading1: Heading 1
- heading2: Heading 2
- bullet1: List Bullet

This section is an optional validated inventory. Its keys are descriptive; it does not map Markdown
unless the same semantic is also declared under `## Word body styles`.

Ordered Markdown lists are enabled only for declared `numbered1`, `numbered2`, ... semantics. The host adds the visible decimal marker deterministically and applies the declared native paragraph style for indentation.

# NORTHSTAR Memo German — usage guidance

Formal German-language NORTHSTAR memorandum template with German front matter. Use this design when the requested artifact is a memo/memorandum and German is the requested or clearly implied document language. The native memo structure and automatic date field remain part of the carrier.

Shared formatting and heading-numbering behavior are defined once in NORTHSTAR_STYLE_POLICY.md through the design catalog. Do not copy the shared mappings into this companion.

## Word template slots

- placeholder: [[RI:To]]
  purpose: Empfänger oder Adressat des Memos im Feld An.
  source: template_fields.to
  required: yes

- placeholder: [[RI:From]]
  purpose: Verfasser oder Absender des Memos im Feld Von.
  source: template_fields.from
  required: yes

- placeholder: [[RI:Subject]]
  purpose: Betreff oder Gegenstand des Memos. Diesen Wert nicht nochmals als erste Überschrift im Text wiederholen, ausser der Inhalt benötigt tatsächlich eine separate Überschrift.
  source: template_fields.subject
  required: yes

- placeholder: [[RI:Text]]
  purpose: Hauptinhalt des Memos unterhalb des festen Memo-Kopfes. An, Von, Datum und Betreff nicht nochmals in diesen Inhalt aufnehmen.
  source: markdown_content
  required: yes

## Template behavior

- Use the DOCX carrier directly.
- Preserve the native memo title, An/Von/Datum/Betreff structure, page setup, headers/footers and fields.
- Keep the native automatic date field; do not replace it with a Red Ink slot.
- Insert the substantive body only at [[RI:Text]].
- The shared NORTHSTAR style policy controls paragraphs, headings, bullets and ordered lists.

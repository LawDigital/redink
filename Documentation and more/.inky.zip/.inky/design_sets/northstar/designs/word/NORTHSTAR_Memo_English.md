# NORTHSTAR Memo English — usage guidance

Formal NORTHSTAR memorandum template with English front matter. Use this design when the requested
artifact is a memo/memorandum and English is the requested or clearly implied document language.
The native memo structure and automatic date field remain part of the carrier.

Shared formatting and heading-numbering behavior are defined once in NORTHSTAR_STYLE_POLICY.md through the design catalog. Do not copy the shared mappings into this companion.

## Word template slots

- placeholder: [[RI:To]]
  purpose: Memo recipient or addressee shown in the To field.
  source: template_fields.to
  required: yes

- placeholder: [[RI:From]]
  purpose: Memo author or sender shown in the From field.
  source: template_fields.from
  required: yes

- placeholder: [[RI:Subject]]
  purpose: Memo subject or matter shown in the Re field. Do not duplicate this value as the first body heading unless the requested content genuinely needs a separate heading.
  source: template_fields.subject
  required: yes

- placeholder: [[RI:Text]]
  purpose: Main substantive memo body beginning below the fixed memo header and separator line. Do not include To, From, Date or Re front matter in this content.
  source: markdown_content
  required: yes

## Template behavior

- Use the DOCX carrier directly; DOCX is the recommended Red Ink Word design carrier.
- Preserve the native memo title, To/From/Date/Re structure, page setup, headers/footers and fields.
- Keep the native automatic date field; do not replace it with a Red Ink slot.
- Insert the substantive body only at [[RI:Text]].
- The shared NORTHSTAR style policy controls paragraphs, headings and bullets.

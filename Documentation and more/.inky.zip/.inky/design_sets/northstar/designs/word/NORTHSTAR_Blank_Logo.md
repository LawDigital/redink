# NORTHSTAR Blank Logo — usage guidance

Generic NORTHSTAR Word carrier with NORTHSTAR branding/logo. Use this design for a NORTHSTAR document when
the requested document is neither a letter nor a memo and no more specific NORTHSTAR design applies.
Language is unrestricted and follows the user's requested language.

Shared formatting is defined once in NORTHSTAR_STYLE_POLICY.md through the design catalog.

## Word template slots

- placeholder: [[RI:Text]]
  purpose: Entire generated document body for a generic NORTHSTAR document. The carrier supplies the NORTHSTAR branding; do not add letter or memo front matter unless the user explicitly asks for it as ordinary content.
  source: markdown_content
  required: yes

## Template behavior

- Use the DOCX carrier directly.
- Preserve the native NORTHSTAR logo/branding, page setup, headers/footers and fields.
- The shared NORTHSTAR style policy controls generated paragraphs, headings and bullets.

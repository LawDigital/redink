# Word design usage guidance

Use this as the companion for one structured DOCX carrier. DOCX is recommended for new designs.
Register the carrier and this file in `designs/designs.json`; paths there are relative to `designs/`.
If several carriers share styles, reference one shared `style_policy_file` instead of duplicating styles.

## Word template slots

- placeholder: [[RI:Recipient]]
  purpose: Explain exactly what value belongs at this location.
  source: template_fields.recipient
  required: yes

- placeholder: [[RI:Text]]
  purpose: Main substantive body inserted at this exact location.
  source: markdown_content
  required: yes

Optional slot property: `content: text` or `content: markdown`. If omitted, it is inferred from source.
Bare property values are preferred; quotes/backticks are not required.

## Template-specific behavior

- Preserve the carrier's native structure, page setup, headers/footers, fields and styles.
- Keep front matter out of markdown_content when it has its own slots.
- The placeholder id is only a locator; purpose/source define its meaning.
- Deploy the carrier and companion together when slots change.

## Optional rendering rules

Normally keep common rules in the shared style policy. Put only a genuine carrier override here.

- heading_numbering: preserve

Values are `native` or `preserve`; see README.txt. Only explicit list-property lines are parsed.

## Optional local body styles

Normally omit this when the catalog references a shared style_policy_file. Use only for a genuinely
unique style family.

- paragraph: Normal
- heading1: Heading 1
- heading2: Heading 2
- bullet1: List Bullet

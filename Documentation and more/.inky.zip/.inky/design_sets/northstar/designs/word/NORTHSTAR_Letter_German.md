# NORTHSTAR Letter German — usage guidance

Formal German-language NORTHSTAR letter template. Use this design when the requested artifact is a
letter and German is the requested or clearly implied document language.

DeliveryForm is the small delivery-method line immediately above the postal/electronic address,
for example: Per E-Mail an peter.muster@firma.ch. DeliveryAddress is the complete recipient address.
Text is the complete letter body including salutation, substantive text, closing/signature wording and
any attachment/enclosure notice that belongs in the letter body.

Shared formatting is defined once in NORTHSTAR_STYLE_POLICY.md through the design catalog. This letter has explicit local exceptions: ordinary generated body paragraphs use Normal 0 instead of the shared paragraph style, and ordered lists use Hängend 0 through Hängend 2 so their first marker starts at the letter text margin.

## Word body styles

- paragraph: Normal 0
- numbered1: Hängend 0
- numbered2: Hängend 1
- numbered3: Hängend 2

## Word template slots

- placeholder: [[RI:DeliveryForm]]
  purpose: Small delivery-method line above the recipient address, for example "Per E-Mail an peter.muster@firma.ch". Leave empty when no separate delivery-method line is appropriate.
  source: template_fields.delivery_form
  required: no

- placeholder: [[RI:DeliveryAddress]]
  purpose: Complete recipient delivery address exactly as it should appear in the address block. Preserve intended line breaks.
  source: template_fields.delivery_address
  required: yes

- placeholder: [[RI:Text]]
  purpose: Complete German letter body, including salutation, substantive letter text, closing/greeting formula and any enclosure or attachment notice that belongs in the letter.
  source: markdown_content
  required: yes

## Template behavior

- Use the DOCX carrier directly.
- Preserve logo, sender/address blocks, date field, page setup, headers/footers and native Word structure.
- Do not repeat the delivery address or delivery form inside markdown_content.
- The shared NORTHSTAR style policy controls generated paragraphs, headings and bullets.

# NORTHSTAR Blank — usage guidance

Clean generic Word carrier without a NORTHSTAR logo. This is the configured global default Word design
when the request does not resolve to a more specific document format. Language is unrestricted and
follows the user's requested language.

Shared formatting is defined once in NORTHSTAR_STYLE_POLICY.md through the design catalog.

## Word template slots

- placeholder: [[RI:Text]]
  purpose: Entire generated document body for a generic document when no more specific configured Word format applies.
  source: markdown_content
  required: yes

## Template behavior

- Use the DOCX carrier directly.
- Preserve the carrier's page setup, headers/footers and native Word styles.
- The shared NORTHSTAR style policy controls generated paragraphs, headings and bullets.

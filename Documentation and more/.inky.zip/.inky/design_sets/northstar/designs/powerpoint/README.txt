POWERPOINT DESIGN REPOSITORY

Each PowerPoint design consists of a .pptx/.potx carrier and, when useful, a same-basename .md guidance file.

Keep the mechanism simple:
1. The PowerPoint carrier owns the real theme, master/layouts, placeholder geometry, fonts, colours and sample visual language.
2. The same-basename Markdown explains how semantic Red Ink layouts map to that carrier and states only design-specific invariants that cannot be inferred safely from geometry alone.
3. DESIGN_GUIDANCE_TEMPLATE.md is a copy/edit starter for adding a new design. Do not duplicate this README in every design guide.

DESIGN GUIDE PRIORITIES
- Map every common semantic type that has a known safe carrier: title, bullets, two_column, cards, process, structure, timeline, comparison, matrix, KPI, chart and closing. A rich semantic may map to a neutral Content/Visual Canvas; it does not need a similarly named native layout.
- State typography invariants explicitly. Native body hierarchy should normally be stable; indentation must not trigger dramatic font shrinking unless the approved template itself defines that hierarchy.
- Treat subtitle/strapline size as a first-class invariant too. A subtitle should not silently collapse to caption-sized typography.
- Validate the carrier with REAL generated/replaced placeholder text, not only the placeholder prompt text visible while authoring the template. PowerPoint may re-apply master/theme text formatting when placeholder content is replaced.
- Therefore make cover/closing contrast robust even when runtime text inherits the theme's normal dark/light text colour; do not depend on fragile prompt-only formatting for legibility.
- Explain which sample slides demonstrate useful visual language. Samples are evidence/examples, not mandatory slides to clone.
- Prefer native editable PowerPoint visuals. SVG/JS is fallback-only when native editability cannot be preserved robustly.
- If a mapping is known, encode it directly. Do not force an LLM template-interpretation call merely to rediscover a deterministic design-owner decision.
- If content does not fit at readable size, shorten/split/restructure it rather than shrinking the whole slide.

# <Design name> — PowerPoint design guidance

Use this file only for **design-specific** rules. The paired PowerPoint carrier remains authoritative for actual masters, layouts, geometry, fonts, colours and artwork.

## Design intent
- Visual character:
- Primary/secondary accents:
- What should remain visually consistent across the deck:
- Cover/closing contrast rule (must remain readable when runtime text inherits theme/master formatting):

## Typography invariants
- Cover title:
- Cover subtitle:
- Content title:
- Content subtitle / strapline:
- Body level 1:
- Body level 2:
- Body level 3:
- Minimum readable native narrative size:
- Rule when content does not fit: shorten / split / restructure; do not arbitrarily shrink.

## Direct mappings

| Red Ink content type | PowerPoint layout | PowerPoint master (optional) |
| --- | --- | --- |
| `title` |  | |
| `bullets` |  | |
| `two_column` |  | |
| `cards` |  | |
| `process` |  | |
| `structure` |  | |
| `timeline` |  | |
| `comparison` |  | |
| `matrix` |  | |
| `kpi` |  | |
| `chart` |  | |
| `closing` |  | |

A rich semantic may map to a neutral content/visual canvas. Do not require a similarly named layout. Fill known mappings so Red Ink does not need an LLM interpretation call for deterministic cases.

## Layout notes
### <layout name>
- Intended use:
- Important placeholder/geometry constraints:
- Subtitle/strapline behaviour:

## Visual language
- Cards:
- Process:
- Timeline / phase roadmap:
- Structure:
- Comparison:
- KPI/chart/matrix:
- Preferred amount of visual vs narrative slides:

## Rich-render settings (optional)
Use only generic `rich.*` settings when the carrier needs them. Prefer palette/tint/gap/canvas settings in the design guide over design-specific renderer code.

## Sample slides
Describe which sample slides demonstrate approved visual patterns. Samples are examples, not mandatory clones.

## Runtime visual QA
- Replace prompt text with realistic generated text and verify title/subtitle contrast and size.
- Render at least cover, narrative, two-column, visual canvas and closing layouts.
- Check that level 2/3 text remains readable and that visual slides use the intended palette.

## Fallback rule
State which safe carrier should be used when a semantic visual has no dedicated layout, and what to do when content is too dense.

# Northstar Advisory Sample — design guidance

`Northstar_Advisory_Sample.pptx` is a fictional, neutral strategy-consulting carrier. It demonstrates the design mechanism only.

## Design intent

- Refined blue/white executive consulting look: light high-contrast cover, deep navy, cobalt blue, restrained cyan and cool blue-grey analytical surfaces. Prefer hairlines, quiet tonal blocks and asymmetric whitespace over thick bars or decorative furniture.
- Strong message titles, disciplined grid, generous whitespace and editable exhibits. Aim for roughly **35–45% visual whitespace** on analytical slides. Avoid ornamental illustrations that do not carry information.
- Use colour to structure the page: one dominant blue plus at most one secondary accent on a slide. Avoid green/yellow traffic-light styling unless the content genuinely requires semantic status colours.
- A normal analytical deck must not look like a sequence of Word pages. Prefer native editable exhibits when the argument is naturally visual. Conversely, do not fill every available box merely because space exists.
- The carrier uses a light cover deliberately: generated placeholder text may inherit the theme's dark text colour at runtime, so the design remains readable without relying on a fragile white-text override.

## Typography — hard invariant

- Use the template's native **Arial** typography.
- Cover title: **42 pt**, dark navy on the native light cover. Never shrink it to solve density.
- Cover subtitle: **19–20 pt**, slate blue-grey.
- Content title: **26–28 pt**, dark navy.
- Content subtitle / explanatory strapline: **17 pt**. It must remain clearly readable and should not become caption-sized.
- Standard body level 1: **19 pt**.
- Standard body level 2: **18 pt** — only a tiny reduction; indentation is the main hierarchy signal.
- Level 3: **17.5 pt** and rare.
- Two-column body level 1: **18 pt**; level 2: **17 pt**.
- Ordinary body sizes must be stable across the deck. Do not invent a smaller font because a single slide is dense.
- Never shrink ordinary narrative text below **17 pt** to rescue a slide. Shorten, split, restructure, or use an editable visual.


## Density — hard invariant

- One slide = one decision message. Prefer **3–4 primary points**, not 6–8.
- Ordinary bullet slides: maximum **5 level-1 bullets**, normally 3–4; each should usually fit on one line or one short wrapped line.
- Use level 2 only for genuinely subordinate evidence. Normally no more than **one short level-2 line per parent**. Avoid level 3 unless the user explicitly needs technical detail.
- If a slide needs several paragraphs, split it. Do not solve density by shrinking type or by filling the full canvas edge-to-edge.
- Visual slides: normally **3–4 cards/nodes/steps**. Five is acceptable only when labels are short. Keep detail to **1–2 concise lines per visual item**.
- Subtitles/straplines should add a single framing thought, not repeat the title or become a second paragraph.
- Prefer a sparse exhibit plus a short takeaway over a dense exhibit plus explanatory prose.

## Direct mappings

| Red Ink content type | PowerPoint layout | PowerPoint master (optional) |
| --- | --- | --- |
| `title` | `Northstar Cover` | |
| `bullets` | `Northstar Content` | |
| `two_column` | `Northstar Two Column` | |
| `cards` | `Northstar Visual Canvas` | |
| `process` | `Northstar Visual Canvas` | |
| `structure` | `Northstar Visual Canvas` | |
| `timeline` | `Northstar Visual Canvas` | |
| `matrix` | `Northstar Visual Canvas` | |
| `kpi` | `Northstar Visual Canvas` | |
| `chart` | `Northstar Visual Canvas` | |
| `comparison` | `Northstar Visual Canvas` | |
| `closing` | `Northstar Closing` | |

These mappings are deterministic. Do not invoke template interpretation merely to rediscover them.

## Layout use

### `Northstar Cover`
Opening only. One concise title and one short subtitle. Preserve the light contrast-safe field and the right-hand navy/cobalt geometry. The geometry is structural, not decorative artwork.

### `Northstar Content`
Default narrative slide. Use one large body region. Prefer 3–4 concise points and leave visible whitespace below or beside the narrative rather than filling the entire placeholder. Preserve the native 19/18/17.5 pt hierarchy and the 17 pt subtitle. If the story is a sequence, comparison, structure or set of parallel themes, do not default to bullets merely because bullets would fit.

### `Northstar Two Column`
Use for two genuinely parallel arguments with substantial text. Keep both columns structurally comparable. Use this instead of a rich comparison only when each side needs several long legal/technical statements.

### `Northstar Visual Canvas`
Primary carrier for **editable native PowerPoint visuals**. The pale blue analytical stage is intentionally large and neutral.

Use it for:
- `cards`: normally 3–4 parallel themes, drivers, risks or decision criteria. Each card should have a short heading and at most 1–2 short detail lines;
- `comparison`: two concise alternatives with normally 2–4 short points each;
- `process`: operational workflow/actions where one step causes the next;
- `timeline`: milestone/phase roadmaps. Dates are welcome but not mandatory; phase labels such as Q1/Q2, Phase 1/2 or Prepare/Execute/Scale are sufficient. Use 3–5 milestones, short phase titles, and no more than two concise detail lines per milestone;
- `structure`: ownership/entity/reporting relationships;
- `matrix`, `kpi`, `chart` where the semantics genuinely fit.

For a normal 6–8 content-slide executive deck, aim for roughly **3–4 meaningful visual slides** when the content supports them. Normally avoid more than two consecutive bullet-only content slides. The objective is not visual quantity but a varied analytical rhythm: narrative → exhibit → implication → exhibit.

Visuals remain native/editable. Do not replace a feasible native timeline/process/comparison with SVG solely for styling.

### `Northstar Closing`
One recommendation plus one concrete next step. Preserve the light recommendation field and right-hand navy/cobalt geometry. No analysis wall and no ornamental artwork.

## Rich-render settings

| setting | value |
| --- | --- |
| `rich.canvas_inset_pct` | `0.5` |
| `rich.min_label_font_pt` | `13.0` |
| `rich.min_detail_font_pt` | `11.5` |
| `rich.cards_height_pct` | `94` |
| `rich.comparison_height_pct` | `96` |
| `rich.process_height_pct` | `92` |
| `rich.timeline_height_pct` | `92` |
| `rich.cards_max_items` | `4` |
| `rich.process_max_items` | `5` |
| `rich.palette_slots` | `accent1,accent2,accent3,accent5` |
| `rich.fill_tint_pct` | `94` |
| `rich.alt_fill_tint_pct` | `97` |
| `rich.line_tint_pct` | `58` |
| `rich.gap_pct` | `2.8` |
| `rich.zone_inset_pct` | `1.0` |

These are visual-label floors and styling preferences, not permission to shrink native narrative text.

## Sample slides

The PPTX contains editable examples of stable bullet hierarchy, two-column analysis, process cards, recommendation cards and a **native editable timeline**. These sample slides are examples only; generated decks create the same visual language from typed `visual` payloads without copying the sample slide.

## Fallback rule

Stay inside the Northstar design. If a rich visual is too text-heavy, first shorten its labels/details or split the slide. If the evidence really needs prose, switch to `Northstar Two Column` or `Northstar Content`. Do not solve overflow by arbitrary font shrinking and do not silently fall back to a generic Blank slide.

# Office design sets

`design_sets/active.json` selects one complete Office design root for Word, PowerPoint and Excel.

- `"active_set": "vischer"` -> use only `vischer/designs`
- `"active_set": "northstar"` -> use only `northstar/designs`
- `"active_set": "none"` -> use the neutral `.inky/designs` fallback; no named design set is active

If only one branded set is to be distributed, keep only that set in `sets`, select it as `active_set`, and delete the other set directory. The neutral `.inky/designs` directory may remain as a safe fallback.

Do not use an invented value such as `XXX`: unknown values are treated as an invalid selector and fall back to `.inky/designs`; `none` is the explicit supported opt-out.

Word routing inside the active set is document-type-first. Language only selects among variants of the same document type.

﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo.
echo RED INK - Office Dump-Analyse (Outlook, Word, Excel)
echo =================================================
echo.
echo Die DMP-Datei muss im selben Ordner wie diese Batchdatei liegen.
echo Keine Administratorrechte erforderlich, sofern die IT-Richtlinien es erlauben.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-DumpAnalyse.ps1"
if errorlevel 1 (
  echo.
  echo Die Analyse konnte nicht vollstaendig ausgefuehrt werden.
  echo Bitte Anleitung.txt lesen oder die IT kontaktieren.
)
echo.
pause
endlocal

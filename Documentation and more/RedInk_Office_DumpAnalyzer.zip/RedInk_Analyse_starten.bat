@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo.
echo RED INK - Office Dump-Analyse (Outlook, Word, Excel)
echo =================================================
echo.
echo Die DMP-Datei muss im selben Ordner wie diese Batchdatei liegen.
echo Keine Administratorrechte erforderlich, sofern die IT-Richtlinien es erlauben.
echo.
if not exist "%~dp0Start-DumpAnalyse.ps1" (
    echo FEHLER: Start-DumpAnalyse.ps1 wurde nicht gefunden.
    goto :failed
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-DumpAnalyse.ps1"
set "AnalysisExitCode=%ERRORLEVEL%"
if not "%AnalysisExitCode%"=="0" goto :failed
echo.
echo Die Analyse wurde abgeschlossen.
goto :finish
:failed
echo.
echo Die Analyse konnte nicht vollstaendig ausgefuehrt werden.
echo Bitte die Fehlermeldungen und Anleitung.txt pruefen.
:finish
echo.
pause
endlocal

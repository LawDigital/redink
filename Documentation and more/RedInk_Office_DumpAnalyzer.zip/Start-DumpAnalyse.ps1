﻿#Requires -Version 5.1
# Input validation and process-local execution; no permanent policy changes.
$ErrorActionPreference = 'Stop'
try {
    $folder = $PSScriptRoot
    Write-Host 'Dateien mit Endung .dmp in diesem Ordner:'
    $files = @(Get-ChildItem -LiteralPath $folder -File -Filter '*.dmp' -ErrorAction Stop)
    if ($files.Count -eq 0) { throw 'Keine .dmp-Datei gefunden. Bitte in den Ordner dieser Batchdatei kopieren.' }
    foreach ($f in $files) { Write-Host ('  ' + $f.Name) }
    $name = (Read-Host 'Bitte den genauen Dateinamen mit .dmp eingeben').Trim().Trim('"')
    if ([string]::IsNullOrWhiteSpace($name)) { throw 'Kein Dateiname angegeben.' }
    if ($name -ne [System.IO.Path]::GetFileName($name) -or $name -notmatch '(?i)^[^\/:*?"<>|]+\.dmp$') {
        throw 'Nur einen Dateinamen mit .dmp eingeben, keinen Pfad.'
    }
    $file = Join-Path $folder $name
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Datei nicht gefunden: ' + $name) }
    $script = Join-Path $folder 'Analyze-OfficeDump.ps1'
    if (-not (Test-Path -LiteralPath $script -PathType Leaf)) { throw 'Analyse-Skript fehlt.' }
    Write-Host ('Analyse gestartet: ' + $name)
    Write-Host 'Das kann beim ersten Mal 10-20 Minuten oder laenger dauern.'
    & $script -DumpPath $file -Mode Auto
    if (-not $?) { throw 'Die Analyse meldete einen Fehler.' }
    Write-Host 'Fertig. RedInk_Support_Diagnose.zip entpacken, alle Textdateien pruefen und erst danach an support@redink.ai senden.'
} catch {
    Write-Host ('FEHLER: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}

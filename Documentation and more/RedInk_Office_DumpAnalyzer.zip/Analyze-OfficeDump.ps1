﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Read-only post-mortem Office dump analysis (Outlook, Word, Excel).
.EXAMPLE
  .\Analyze-OfficeDump.ps1 -DumpPath 'C:\Dumps\OUTLOOK.DMP' -Mode Auto
.EXAMPLE
  .\Analyze-OfficeDump.ps1 -DumpPath 'C:\Dumps\OUTLOOK.DMP' -Mode Hang -CdbPath 'C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\cdb.exe'
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })][string]$DumpPath,
    [ValidateSet('Auto','Crash','Hang')][string]$Mode='Auto',
    [string]$CdbPath,
    [string]$OutputDirectory,
    [ValidateRange(30,3600)][int]$TimeoutSeconds=600,
    [switch]$SkipManaged,
    [string]$SymbolCache = "$env:LOCALAPPDATA\RedInkDumpAnalyzer\Symbols"
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Find-Cdb([string]$Requested) {
    if ($Requested) {
        if (-not (Test-Path -LiteralPath $Requested -PathType Leaf)) { throw "CDB nicht gefunden: $Requested" }
        return (Resolve-Path -LiteralPath $Requested).Path
    }
    $candidates = @()
    foreach ($root in @("${env:ProgramFiles(x86)}\Windows Kits\10\Debuggers", "$env:ProgramFiles\Windows Kits\10\Debuggers", "${env:ProgramFiles(x86)}\Windows Kits\11\Debuggers")) {
        if ($root) { foreach ($arch in @('x64','x86')) { $candidates += (Join-Path (Join-Path $root $arch) 'cdb.exe') } }
    }
    foreach ($candidate in $candidates) { if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate } }
    $cmd = Get-Command cdb.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw 'cdb.exe nicht gefunden. Debugging Tools for Windows installieren oder -CdbPath angeben.'
}
function Run-Debugger([string]$Label,[string]$Commands) {
    $log = Join-Path $OutputDirectory "$Label.debugger.txt"
        $p = New-Object System.Diagnostics.Process
    $p.StartInfo = New-Object System.Diagnostics.ProcessStartInfo
    $p.StartInfo.FileName = $script:Debugger
    # cdb -z and -logo interpret quoted paths; ensure embedded quotes are rejected
    $p.StartInfo.Arguments = '-z "{0}" -y "{1}" -logo "{2}" -c "{3}"' -f $script:Dump, $script:Symbols, $log, $Commands
    $p.StartInfo.UseShellExecute = $false
    $p.StartInfo.CreateNoWindow = $true
    $p.StartInfo.RedirectStandardOutput = $false
    $p.StartInfo.RedirectStandardError = $false
    # All debugger output is logged by -logo; stdout/stderr redirection avoided to prevent pipe deadlock.
    $started = $p.Start()
    if (-not $started) { throw "Debugger konnte nicht gestartet werden ($Label)." }
    if (-not $p.WaitForExit($TimeoutSeconds*1000)) {
        try { $p.Kill() } catch { }
        throw "Debugger-Zeitlimit ($TimeoutSeconds s) bei $Label. Teilprotokoll: $log"
    }
    return [pscustomobject]@{ Label=$Label; ExitCode=$p.ExitCode; Log=$log }
}
function Read-Log([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return '' }
    return [System.IO.File]::ReadAllText($Path)
}
function Extract-Lines([string]$Data,[string]$Pattern,[int]$Max=50) {
    $lines = $Data -split '\r?\n'
    return @($lines | Where-Object { $_ -match $Pattern } | Select-Object -First $Max)
}
$script:Dump = (Resolve-Path -LiteralPath $DumpPath).Path
if ($script:Dump.Contains('"')) { throw 'Anführungszeichen im Dump-Pfad werden nicht unterstützt.' }
$script:Debugger = Find-Cdb $CdbPath
if (-not $OutputDirectory) { $OutputDirectory = Join-Path (Split-Path -Parent $script:Dump) (([System.IO.Path]::GetFileNameWithoutExtension($script:Dump)) + '_RedInk_Analyse_' + (Get-Date -Format 'yyyyMMdd_HHmmss')) }
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
New-Item -ItemType Directory -Path $SymbolCache -Force | Out-Null
$script:Symbols = "srv*$SymbolCache*https://msdl.microsoft.com/download/symbols"
if ($script:Dump.Contains('"') -or $script:Symbols.Contains('"') -or $OutputDirectory.Contains('"')) { throw 'Anführungszeichen in Pfaden sind nicht unterstützt.' }
$meta = [ordered]@{
    Dump=$script:Dump; Mode=$Mode; Created=(Get-Date).ToString('o'); Debugger=$script:Debugger
    TargetApplications='Outlook, Word, Excel'; Symbols=$script:Symbols
    Disclaimer='Stack-Indizien sind keine automatische Kausalitaetsfeststellung.'
}
$meta | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $OutputDirectory 'Metadaten.json') -Encoding UTF8
# Only debugger commands, no mutation or execution in the debuggee.
# .ecxr/!analyze can be inconclusive on hang dumps; capture all native stacks in every mode.
# Keep the original native evidence; add thread identity and critical-section ownership.
$nativeCmd = '.reload; vertarget; |; !analyze -v; .exr -1; .ecxr; kv 80; ~; ~* kv 80; !locks; !cs -l; lmv; q'
$results = New-Object System.Collections.Generic.List[object]
$problems = New-Object System.Collections.Generic.List[string]
try { $results.Add((Run-Debugger '01_Nativ' $nativeCmd)) }
catch { $problems.Add($_.Exception.Message) }
if (-not $SkipManaged) {
    # SOS load may fail on minidumps lacking CLR state; errors remain in evidence log.
    # !eestack examines available managed threads without nested debugger thread commands.
    # !eestack captures cross-thread managed evidence; !clrstack focuses debugger thread 0.
    # Never nest ~*e with SOS stack walkers: this caused recursive-thread errors/timeouts.
    $managedCmd = '.reload; .loadby sos clr; !eeversion; !threads; !syncblk; !eestack; ~0s; !clrstack; q'
    try { $results.Add((Run-Debugger '02_Managed_SOS' $managedCmd)) }
    catch { $problems.Add($_.Exception.Message) }
}
$nativeFile = Join-Path $OutputDirectory '01_Nativ.debugger.txt'
$managedFile = Join-Path $OutputDirectory '02_Managed_SOS.debugger.txt'
$native = Read-Log $nativeFile
$managed = Read-Log $managedFile
$all = $native + "`r`n" + $managed
# Process identity is taken only from debugger output; the dump filename is arbitrary.
$application = 'Unbekannt'
if ($native -match '(?im)^\s*PROCESS_NAME:\s*(OUTLOOK|WINWORD|EXCEL)\.EXE\s*$') {
    switch ($Matches[1].ToUpperInvariant()) {
        'OUTLOOK' { $application = 'Outlook' }
        'WINWORD' { $application = 'Word' }
        'EXCEL' { $application = 'Excel' }
    }
} elseif ($native -match '(?im)^\s*\.\s*\d+\s+Id:.*name:\s*.*\\(OUTLOOK|WINWORD|EXCEL)\.EXE\s*$') {
    switch ($Matches[1].ToUpperInvariant()) {
        'OUTLOOK' { $application = 'Outlook' }
        'WINWORD' { $application = 'Word' }
        'EXCEL' { $application = 'Excel' }
    }
}
# Explicit assembly and source namespace markers plus project-specific execution terms.
$ident = '(?i)Red[_ ]Ink[_ ]for[_ ]Outlook|Red_Ink_for_Outlook|RedInk|SharedLibrary'
$relevant = '(?i)ThisAddIn|DelayedStartupTasks|startupFallbackTimer|startupReconcileFallbackTimer|_uiContext|_uiScheduler|SynchronizationContext|Control\.Invoke|Control\.BeginInvoke|Task\.Wait|GetResult|WaitOne|WaitForSingleObject|CoWaitForMultipleHandles|SendMessage|combase|ole32|VSTO|Nito\.AsyncEx|AutoPilot|ToolExecution|AgentHost'
$crash = '(?im)^\s*(EXCEPTION_CODE|FAULTING_MODULE|FAULTING_IP|IMAGE_NAME|MODULE_NAME|SYMBOL_NAME|FAILURE_BUCKET_ID|PROCESS_NAME|ERROR_CODE|ExceptionCode|BUGCHECK_STR|STACK_TEXT)\s*[:=].*$'
$report = New-Object System.Collections.Generic.List[string]
$report.Add('RED INK / OFFICE – DUMP-ANALYSE')
$report.Add(('=' * 72))
$report.Add("Dump: $script:Dump")
$report.Add("Modus (Auswertungsfokus): $Mode")
$report.Add("Erkannte Anwendung: $application")
$report.Add("Projekt: Red Ink for Outlook | Red_Ink_for_Outlook | .NET Framework 4.8 (VSTO)")
$report.Add('Hinweis: Nur belastbare Stack-Kontexte koennen eine Beteiligung zeigen. Keine automatische Schuldzuweisung.')
$report.Add('')
$report.Add('[Debugger-Ausfuehrung]')
foreach ($r in $results) { $report.Add("$($r.Label): ExitCode=$($r.ExitCode), $($r.Log)") }
foreach ($p in $problems) { $report.Add("FEHLER: $p") }
if ($native -match '(?i)WARNING.*symbol|symbols could not be loaded|symbol file could not be found') { $report.Add('WARNUNG: Symbolprobleme erkannt; Stack-Deutung eingeschraenkt.') }
if ($managed -match '(?i)Failed to load|Unable to load|No export|not a valid extension|Failed to find runtime') { $report.Add('WARNUNG: SOS/.NET konnte moeglicherweise nicht vollstaendig ausgefuehrt werden.') }
$report.Add('')
$report.Add('[Crash-Indikatoren aus dem Debugger]')
$matches = Extract-Lines $native $crash 75
if ($matches.Count -eq 0) { $report.Add('Keine eindeutigen Crash-Indikatoren gefunden; bei Hang-Dumps normal.') } else { foreach ($line in $matches) { $report.Add($line) } }
$report.Add('')
$report.Add('[Red-Ink-/SharedLibrary-Treffer (Kontext; SharedLibrary allein beweist Red Ink NICHT)]')
$lines = $all -split '\r?\n'
$hits = @(for ($i=0; $i -lt $lines.Length; $i++) { if ($lines[$i] -match $ident) { $i } })
if ($hits.Count -eq 0) { $report.Add('Keine Red-Ink-Marker in auslesbaren Stacks gefunden. Dies schliesst Red Ink NICHT aus (optimierter Code, fehlende Symbole, Minidump).') }
else {
    foreach ($idx in ($hits | Select-Object -First 90)) {
        $start = [Math]::Max(0,$idx-3); $end = [Math]::Min($lines.Length-1,$idx+4)
        $report.Add("--- Treffer im kombinierten Debuggerlog Zeile $($idx+1) ---")
        for($j=$start;$j -le $end;$j++){ $report.Add(('{0,6}: {1}' -f ($j+1),$lines[$j])) }
    }
}
$report.Add('')
$report.Add('[Weitere relevante Thread-/Interop-/Warte-Indizien; ohne automatische Ursachenzuschreibung]')
foreach ($line in (Extract-Lines $all $relevant 120)) { $report.Add($line) }
$report.Add('')
# Identify the faulting module from the exception analysis, not just from a loaded DLL list.
# This is evidence of where the fault surfaced, not necessarily which caller caused it.
$moduleCandidates = @(Extract-Lines $native '(?i)^\s*(IMAGE_NAME|MODULE_NAME|FAULTING_MODULE|SYMBOL_NAME|FAILURE_BUCKET_ID|EXCEPTION_CODE|PROCESS_NAME)\s*[:=]' 100)
$moduleNames = @()
foreach ($entry in $moduleCandidates) {
    if ($entry -match '(?i)^\s*(IMAGE_NAME|MODULE_NAME|FAULTING_MODULE)\s*[:=]\s*(\S+)') {
        $moduleNames += $matches[2].Trim()
    }
}
$moduleNames = @($moduleNames | Select-Object -Unique)
$redInkPattern = '(?i)red[ _]?ink|red_ink_for_outlook'
$winOrOfficePattern = '(?i)^(ntdll|kernelbase|kernel32|ucrtbase|vcruntime\d*|msvcp\d*|combase|ole32|rpcrt4|user32|gdi32|clr|mscorwks|mscoree|outlook|mso|olmapi32|wwlib|officeclicktorun|windows\.storage|shel[l]32)(\.dll|\.exe)?$'
$otherModuleNames = @($moduleNames | Where-Object { ($_ -notmatch $redInkPattern) -and ($_ -notmatch $winOrOfficePattern) })
$redInkModuleNames = @($moduleNames | Where-Object { $_ -match $redInkPattern })
$report.Add('')
$report.Add('[ALTERNATIVE URSACHEN / ENTlastende INDIZIEN]')
$report.Add('ACHTUNG: Ein fehlerhaftes Modul ist nicht immer der Ausloeser. Die Aufrufkette muss geprueft werden.')
if ($moduleNames.Count -gt 0) {
    $report.Add('Vom Debugger benannte Fehler-/Kontextmodule: ' + ($moduleNames -join ', '))
} else {
    $report.Add('Kein Fehler-Modul eindeutig benannt. Bei Hang-Dumps oder kleinen Minidumps ist dies normal.')
}
if ($otherModuleNames.Count -gt 0) {
    $report.Add('FREMDE FEHLERMODULE (aus den expliziten Exception-Feldern): ' + ($otherModuleNames -join ', '))
    $report.Add('BEWERTUNG: Konkreter alternativer Untersuchungsansatz; kein automatischer Ausschluss von Red Ink.')
} elseif ($moduleNames.Count -gt 0 -and $redInkModuleNames.Count -eq 0) {
    $report.Add('Fehler-Modul liegt nicht explizit in Red Ink. System-/Office-Runtime als Absturzort ist kein Ursachenbeweis.')
} else {
    $report.Add('Kein eindeutig entlastendes fremdes Fehlermodul identifiziert.')
}
$report.Add('')
$report.Add('[Fremdsoftware-/System- / COM- / I/O-Hinweise in Stacks]')
$alternativePatterns = [ordered]@{
 'AV / Security / Hooks (nur Suchbegriffe)'='(?i)avp|aswhook|edr|sentinel|crowdstrike|symantec|sophos|defender|antivirus|security|hook'
 'Drittanbieter-Addin / Connector (heuristisch)'='(?i)addin|plugin|connector|teams|zoom|adobe|salesforce|webex|onedrive|citrix'
 'COM / RPC / DCOM / OLE'='(?i)combase!|ole32!|rpcrt4!|CoWaitForMultipleHandles|CoGet|RPC_|STA|marshal'
 'UI-Warte- oder Message-Loop'='(?i)SendMessage|GetMessage|DispatchMessage|WaitForSingleObject|WaitForMultipleObjects|MsgWaitForMultipleObjects'
 'Netzwerk / Dateizugriff / MAPI'='(?i)winhttp|wininet|ws2_32|mswsock|ntfs|CreateFile|ReadFile|mapi|olmapi|pst|ost|exchange'
 'Speicherfehler / Heap'='(?i)heap_corruption|0xc0000374|0xc0000005|access.violation|invalid_pointer|out.of.memory|0x8007000e'
}
foreach ($entry in $alternativePatterns.GetEnumerator()) {
    $found = @(Extract-Lines $all $entry.Value 12)
    $report.Add('--- ' + $entry.Key + ' (' + $found.Count + ' angezeigte Treffer; keine Schuldzuweisung) ---')
    if ($found.Count -eq 0) { $report.Add('Kein Hinweis in lesbaren Debug-Ausgaben.') }
    else { foreach ($line in $found) { $report.Add($line) } }
}
$report.Add('')
$report.Add('[Pruefung der Entlastbarkeit]')
if ($native.Length -eq 0) {
    $report.Add('NICHT BEURTEILBAR: Kein nativer Debugger-Log. Keine Aussage zur Verursachung.')
} elseif ($otherModuleNames.Count -gt 0) {
    $report.Add('ALTERNATIVE HYPOTHESE: Fremdmodul in Exception-Metadaten. Pruefen, ob der Exception-Stack Red Ink enthaelt und ob das Fremdmodul einen eigenen Fehler ausloest.')
} elseif ($native -match '(?i)EXCEPTION_CODE|FAULTING_IP|FAILURE_BUCKET_ID') {
    $report.Add('ABSTURZKONTEXT VORHANDEN: Entscheidend ist der .ecxr-Stack, nicht die Liste aller geladenen Module.')
} else {
    $report.Add('KEIN EINDEUTIGER ABSTURZKONTEXT: Bei Hang-Dumps alle Thread-Stacks und ggf. mehrere zeitlich versetzte Dumps vergleichen.')
}
$report.Add('AUSSAGEGRENZE: Weder Red-Ink-Treffer noch das Fehlen solcher Treffer belegen allein Ursache oder Unschuld.')
$report.Add('BEWEISSTRATEGIE: Fremdfehler mit Exception-/Thread-Kontext und unabhaengigen Reproduktionsschritten belegen.')
$report.Add('')
$report.Add('[Interpretation / Beweisgrad]')
$report.Add('NUR GELADEN: Eine geladene DLL alleine ist kein Ursachenbeleg.')
$report.Add('BETEILIGT: Red-Ink-Frame im betroffenen Exception-/UI-Stack ist ein staerkerer Hinweis. SharedLibrary allein ist NICHT Red Ink zuzurechnen.')
$report.Add('URSACHE: Erfordert Exception-Kontext bzw. nachvollziehbare Wait-Chain und ggf. mehrere Dumps/Logs.')
$report.Add('HANG: Bei mehreren zeitlich getrennten Dumps vergleichen, ob derselbe Thread/Stack unveraendert bleibt.')
$report.Add('MANAGED: Fehlendes !clrstack kann am Dump-Typ oder einer inkompatiblen SOS-Version liegen.')
$report.Add('')
# Structured hang evidence: retain thread boundaries and show full stacks, not isolated keyword lines.
$report.Add('[HANG: Thread-Korrelation und Wartezustaende]')
$report.Add('Die folgenden Thread-Zuordnungen beruhen auf Debugger-Thread-Headern. Ein Wait beweist keinen Deadlock.')
$nativeThreads = New-Object System.Collections.Generic.List[object]
$currentThread = $null
$inStack = $false
$stackSectionSeen = $false
$nativeLines = $native -split '\r?\n'
# IMPORTANT: `~` prints a thread listing with the same Id: headers as `~* kv`.
# A stack starts ONLY when the header is followed by Child-SP/RetAddr.
# Do not count the listing as stacks; tolerate optional dot/hash/current markers.
for ($i = 0; $i -lt $nativeLines.Length; $i++) {
    $line = $nativeLines[$i]
    if ($line -match '^\s*[.#*]?\s*(\d+)\s+Id:\s*[0-9a-fA-F]+\.([0-9a-fA-F]+)\s+Suspend:') {
        $threadIndex = [int]$Matches[1]
        $threadOsTid = $Matches[2]
        $nextIsStack = ($i + 1 -lt $nativeLines.Length -and $nativeLines[$i+1] -match '^\s*Child-SP\s+RetAddr')
        if ($null -ne $currentThread) {
            $nativeThreads.Add($currentThread)
            $currentThread = $null
        }
        $inStack = $nextIsStack
        if ($nextIsStack) {
            $stackSectionSeen = $true
            $currentThread = [pscustomobject]@{ Index=$threadIndex; OsTid=$threadOsTid; Lines=(New-Object System.Collections.Generic.List[string]) }
        }
        continue
    }
    if ($inStack -and $null -ne $currentThread) {
        if ($line -match '^\s*[0-9a-fA-F`]{8,18}\s+[0-9a-fA-F`]{8,18}\s+:') {
            $currentThread.Lines.Add($line)
        } elseif ($line -match '^\s*(?:\d+:\d+>|[a-zA-Z][^:]{0,30}:|start\s+end\s+module|Unloaded modules:)') {
            $nativeThreads.Add($currentThread)
            $currentThread = $null
            $inStack = $false
        }
    }
}
if ($null -ne $currentThread) { $nativeThreads.Add($currentThread) }
$waitPattern = '(?i)WaitForSingleObject|WaitForMultipleObjects|MsgWaitForMultipleObjects|NtWaitFor|NtUserMsgWait|CoWaitForMultipleHandles|Control\.MarshaledInvoke|Control\.WaitForWaitHandle|WindowsFormsSynchronizationContext\.Send|SendMessage|Task\.Wait|Monitor\.Enter|RtlEnterCriticalSection|WaitHandleNative|DoAppropriateWait'
$eventPattern = '(?i)SystemEvents|UserPreferenceChanged|Control\.Invoke|Control\.MarshaledInvoke|WindowsFormsSynchronizationContext|Red[_ ]?Ink|SharedLibrary|iManage'
$ranked = @($nativeThreads | ForEach-Object {
    $stackText = $_.Lines -join "`n"
    $score = 0
    if ($stackText -match $waitPattern) { $score += 1 }
    if ($stackText -match $eventPattern) { $score += 3 }
    [pscustomobject]@{ Thread=$_; Score=$score; Wait=($stackText -match $waitPattern); Event=($stackText -match $eventPattern) }
} | Sort-Object -Property Score -Descending)
$report.Add('Erkannte native Thread-Stacks: ' + $nativeThreads.Count)
$report.Add('Thread-Stacks mit Warte-Indizien: ' + @($ranked | Where-Object { $_.Wait }).Count)
$report.Add('Thread-Stacks mit UI-/Add-in-Indizien: ' + @($ranked | Where-Object { $_.Event }).Count)
foreach ($entry in ($ranked | Where-Object { $_.Score -gt 0 } | Select-Object -First 40)) {
    $t = $entry.Thread
    $report.Add(('--- Debugger-Thread {0}, OS-TID 0x{1}; Wait={2}; UI/Add-in={3} ---' -f $t.Index,$t.OsTid,$entry.Wait,$entry.Event))
    foreach ($frame in ($t.Lines | Select-Object -First 100)) { $report.Add($frame) }
}
if (-not $stackSectionSeen -or $nativeThreads.Count -eq 0) {
    $report.Add('FEHLER: Keine nativen Thread-Stacks erkannt; Klassifizierung UNGUELTIG (nicht 0 Wartefaelle).')
} elseif (@($nativeThreads | Where-Object { $_.Lines.Count -eq 0 }).Count -gt 0) {
    $report.Add('WARNUNG: Mindestens ein nativer Thread hat keine auswertbaren Frames.')
}
$report.Add('Managed-Hinweise (alle Threads aus !eestack; Zielthread nicht automatisch bestimmbar):')
foreach ($line in @(Extract-Lines $managed '(?i)SystemEvents\.OnUserPreferenceChanged|WindowsFormsSynchronizationContext\.Send|Control\.MarshaledInvoke|Control\.WaitForWaitHandle|WaitHandle\.WaitOne' 25)) { $report.Add($line) }
$report.Add('WICHTIG: Zielthread von Control.Invoke und dessen Gegenabhaengigkeit sind aus Stacknamen allein nicht beweisbar.')
$report.Add('!syncblk und !cs -l sind Indizien zu Locks, keine vollstaendige COM-/WinForms-Wait-Chain.')
$report.Add('Wenn kein Zielthread nachweisbar ist: Befund UNGEKLAERT, nicht automatisch Red Ink oder iManage zuordnen.')
$report.Add('')
$report.Add('[QUALITAETSPRUEFUNG DER ERFASSUNG]')
if ($native.Length -eq 0) { $report.Add('FEHLER: Nativer Stack-Log fehlt.') }
if (-not $SkipManaged -and $managed.Length -eq 0) { $report.Add('FEHLER: Managed/SOS-Log fehlt.') }
if (-not $SkipManaged -and $managed -notmatch '(?i)OS Thread Id|Thread Id:|System\.Windows\.Forms|System\.Threading') {
    $report.Add('WARNUNG: Kein auswertbarer Managed-Stack nachgewiesen; SOS-Version/Dump-Typ pruefen.')
}
if ($managed -match '(?i)Ignoring recursive thread command|Failed to start stack walk') { $report.Add('WARNUNG: SOS Stack-Walk-Fehler; Managed-Threaddaten moeglicherweise unvollstaendig.') }
if ($native -match '(?i)Mini Dump|MiniDump') { $report.Add('HINWEIS: Minidump kann Heap-/Objekt- und Lock-Zuordnungen verhindern.') }
foreach ($r in $results) { if ($r.ExitCode -ne 0) { $report.Add("WARNUNG: $($r.Label) beendete sich mit ExitCode $($r.ExitCode).") } }
$report.Add('')
$report.Add('[Originaldateien]')
$report.Add($nativeFile)
if (-not $SkipManaged) { $report.Add($managedFile) }
$reportPath = Join-Path $OutputDirectory 'RedInk_Analyse.txt'
$report | Set-Content -LiteralPath $reportPath -Encoding UTF8
if ($problems.Count -gt 0 -or $results.Count -eq 0) { Write-Warning 'Debugger-Aufrufe teilweise fehlgeschlagen. Siehe Bericht und Debugger-Protokolle.' }
Write-Host "Analyse erstellt: $reportPath"
Write-Host 'WICHTIG: Minidumps liefern u.U. keine vollstaendigen Managed Stacks.'



# Support bundle: complete diagnostic evidence, but NEVER the original dump.
# The recipient must review the extracted TEXT files before sending.
$bundle = Join-Path $OutputDirectory 'RedInk_Support_Diagnose.zip'
$files = New-Object System.Collections.Generic.List[string]
foreach ($f in @($reportPath,$nativeFile,$managedFile,(Join-Path $OutputDirectory 'Metadaten.json'))) {
    if (Test-Path -LiteralPath $f -PathType Leaf) { $files.Add($f) }
}
$readme = Join-Path $OutputDirectory 'VOR_DEM_VERSAND_LESEN.txt'
@'
RED INK SUPPORT - VOLLSTAENDIGE TEXTDIAGNOSE
============================================
Diese ZIP enthaelt den Analysebericht, native Debugger-Stacks,
.NET/SOS-Debugger-Ausgabe (falls verfuegbar) und Metadaten.
Die originale DMP-Datei wird NICHT beigefuegt.

ACHTUNG: Auch Textlogs koennen persoenliche oder vertrauliche Daten
enthalten, insbesondere Pfade, Benutzernamen, Dateinamen, E-Mail-Adressen,
Speicheradressen, Stack-Argumente und in Einzelfaellen Inhaltsfragmente.
Vor dem Versand die TEXTDATEIEN pruefen und bei Bedarf bereinigen.
Vorsicht: Aenderungen an Stacks koennen die Diagnose beeintraechtigen.
Keine Garantie, dass ausschliesslich Payload sensibel ist.

An: support@redink.ai
Bitte Anwendung, Zeitpunkt, Crash/Hang und Reproduktionsschritte nennen.
Falls die Diagnose unvollstaendig ist, auch den Timeout/Fehler mitteilen.
'@ | Set-Content -LiteralPath $readme -Encoding UTF8
$files.Add($readme)
if (Test-Path -LiteralPath $bundle) { Remove-Item -LiteralPath $bundle -Force }
Compress-Archive -LiteralPath $files.ToArray() -DestinationPath $bundle -CompressionLevel Optimal
Write-Host "Supportpaket mit vollstaendigen Textdiagnosen: $bundle"
Write-Host 'Vor Versand ZIP entpacken, Textdateien auf vertrauliche Inhalte pruefen.'
Write-Host 'DMP-Datei NICHT versenden. Empfaenger: support@redink.ai'
